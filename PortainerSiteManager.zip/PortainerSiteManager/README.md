# THTech Web Studio - Instalação no Portainer

Este repositório contém os arquivos necessários para implantar o THTech Web Studio em sua VPS usando o Portainer.

## Pré-requisitos

1. Uma VPS com Docker e Portainer instalados
2. Traefik configurado como proxy reverso (já deve estar em execução)
3. Rede Docker "minha_rede" criada no servidor (importante!)
4. Domínios configurados para apontar para seu servidor:
   - `painel.thtech.com.br` (ou outro domínio de sua escolha para o painel)
   - `db.thtech.com.br` (ou outro domínio para acessar o pgAdmin)

## Variáveis de Ambiente Necessárias

Configure as seguintes variáveis de ambiente no Portainer antes de implantar a stack:

- `POSTGRES_PASSWORD`: Senha para o banco de dados PostgreSQL
- `MONETIZZE_API_KEY`: Sua chave API do Monetizze para integração com a plataforma
- `SESSION_SECRET`: String aleatória para criptografar as sessões (ex: gere usando `openssl rand -hex 32`)
- `PGADMIN_EMAIL`: Email para login no pgAdmin
- `PGADMIN_PASSWORD`: Senha para login no pgAdmin

## Criação da Rede Personalizada

Antes de implantar a stack no Portainer, é necessário criar a rede Docker personalizada. 
Execute o seguinte comando no seu servidor (via SSH ou terminal Docker do Portainer):

```bash
docker network create minha_rede
```

## Como Implantar no Portainer

1. No Portainer, navegue até "Stacks" e clique em "Add stack"
2. Dê um nome à stack, como "thtech-web-studio"
3. Na seção "Build method", selecione "Web editor"
4. Cole o conteúdo do arquivo `docker-compose.yml` no editor
5. Na seção "Environment variables", adicione as variáveis de ambiente listadas acima
6. Clique em "Deploy the stack"

## Configuração Inicial

Após a implantação, acesse o pgAdmin pelo endereço `https://db.thtech.com.br` (ou o domínio que você configurou) e registre um servidor:

1. Nome: THTech
2. Host: postgres
3. Port: 5432
4. Database: thtech
5. Username: postgres
6. Password: (a senha que você definiu em POSTGRES_PASSWORD)

## Acesso ao Painel

Após a implantação estar completa, você pode acessar o painel administrativo do THTech Web Studio em `https://painel.thtech.com.br` (ou o domínio que você configurou).

## Sistema de Backup

A stack inclui um serviço de backup automatizado que:

- Cria backups diários do banco de dados
- Mantém apenas os 5 backups mais recentes para economizar espaço
- Armazena os backups em um volume Docker para persistência

## Customização

Se desejar alterar os domínios usados para acessar os serviços, edite as regras Traefik nos labels dos serviços correspondentes no arquivo `docker-compose.yml`.