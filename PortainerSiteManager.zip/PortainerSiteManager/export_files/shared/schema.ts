import { pgTable, text, serial, integer, boolean, timestamp, jsonb, index, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Usuários
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  fullName: text("full_name"),
  avatar: text("avatar"),
  role: text("role").default("user").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Website/Sites
export const websites = pgTable("websites", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  domain: text("domain"),
  status: text("status").default("draft").notNull(), // "draft", "published", "archived"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  thumbnail: text("thumbnail"),
  views: integer("views").default(0),
  content: jsonb("content"), // Store the website content as JSON
  userId: integer("user_id").references(() => users.id),
  templateId: integer("template_id").references(() => templates.id),
  dockerConfig: jsonb("docker_config"), // Docker configuration for deployment
  traefik: boolean("traefik").default(false), // Flag for using Traefik
});

// Modelos/Templates
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category"),
  thumbnail: text("thumbnail"),
  content: jsonb("content"), // Store the template content as JSON
  isCustom: boolean("is_custom").default(false),
  premium: boolean("premium").default(false),
  price: integer("price"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Componentes
export const components = pgTable("components", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // "basic", "layout", "components"
  type: text("type").notNull(), // Specific component type
  content: jsonb("content"), // Store the component content as JSON
  icon: text("icon"),
});

// DNS Records
export const dnsRecords = pgTable("dns_records", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id).notNull(),
  domain: text("domain").notNull(),
  recordType: text("record_type").notNull(), // "A", "CNAME", "MX", "TXT"
  status: text("status").default("pending").notNull(), // "pending", "verified", "error"
  lastChecked: timestamp("last_checked"),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  sslEnabled: boolean("ssl_enabled").default(false),
  sslCertExpiry: timestamp("ssl_cert_expiry"),
  errorMessage: text("error_message"),
  settings: jsonb("settings"), // Additional settings like redirects, etc.
  traefikConfig: jsonb("traefik_config"), // Configuration for Traefik
});

// Atividades/Logs
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // "deploy", "update", "create", etc.
  description: text("description").notNull(),
  entityId: integer("entity_id"), // ID of the related entity (website, template, etc.)
  entityType: text("entity_type"), // Type of the related entity
  userId: integer("user_id").references(() => users.id),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  icon: text("icon"),
});

// Backup
export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id).notNull(),
  path: text("path").notNull(),
  size: integer("size"),
  status: text("status").default("completed").notNull(), // "pending", "completed", "failed"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  type: text("type").default("manual").notNull(), // "auto", "manual"
  expiresAt: timestamp("expires_at"),
});

// Marketplace/Produtos
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  price: integer("price").notNull(), // Price in cents
  type: text("type").notNull(), // "template", "plugin", "service"
  externalId: text("external_id"), // ID na Monetizze
  thumbnail: text("thumbnail"),
  details: jsonb("details"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Transações/Compras
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  amount: integer("amount").notNull(), // Amount in cents
  status: text("status").default("pending").notNull(), // "pending", "completed", "failed"
  paymentMethod: text("payment_method"),
  externalId: text("external_id"), // ID da transação na Monetizze
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  details: jsonb("details"),
});

// Configurações do sistema
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
  type: text("type").default("string").notNull(), // "string", "number", "boolean", "json"
  category: text("category"),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Estatísticas
export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id).notNull(),
  date: timestamp("date").defaultNow().notNull(),
  views: integer("views").default(0),
  uniqueVisitors: integer("unique_visitors").default(0),
  data: jsonb("data"), // Additional stats data
});

// Docker Services
export const dockerServices = pgTable("docker_services", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id).notNull(),
  serviceId: text("service_id").notNull(), // ID do serviço no Docker Swarm
  name: text("name").notNull(),
  status: text("status").default("running").notNull(), // "running", "stopped", "error"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  config: jsonb("config"), // Configuration settings
  metrics: jsonb("metrics"), // Performance metrics
});

// Docker Volumes
export const dockerVolumes = pgTable("docker_volumes", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id),
  name: text("name").notNull(),
  mountPath: text("mount_path"),
  size: integer("size"), // Size in bytes
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Website Component Instances
export const websiteComponents = pgTable("website_components", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id).notNull(),
  componentId: integer("component_id").references(() => components.id).notNull(),
  settings: jsonb("settings"),
  position: integer("position").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Definição de relações
export const usersRelations = relations(users, ({ many }) => ({
  websites: many(websites),
  activities: many(activities),
  transactions: many(transactions),
}));

export const websitesRelations = relations(websites, ({ one, many }) => ({
  user: one(users, {
    fields: [websites.userId],
    references: [users.id],
  }),
  template: one(templates, {
    fields: [websites.templateId],
    references: [templates.id],
  }),
  dnsRecords: many(dnsRecords),
  backups: many(backups),
  statistics: many(statistics),
  dockerServices: many(dockerServices),
  dockerVolumes: many(dockerVolumes),
  components: many(websiteComponents),
}));

export const templatesRelations = relations(templates, ({ many }) => ({
  websites: many(websites),
}));

export const componentsRelations = relations(components, ({ many }) => ({
  websites: many(websiteComponents),
}));

export const dnsRecordsRelations = relations(dnsRecords, ({ one }) => ({
  website: one(websites, {
    fields: [dnsRecords.websiteId],
    references: [websites.id],
  }),
}));

export const activitiesRelations = relations(activities, ({ one }) => ({
  user: one(users, {
    fields: [activities.userId],
    references: [users.id],
  }),
}));

export const backupsRelations = relations(backups, ({ one }) => ({
  website: one(websites, {
    fields: [backups.websiteId],
    references: [websites.id],
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
  product: one(products, {
    fields: [transactions.productId],
    references: [products.id],
  }),
}));

export const statisticsRelations = relations(statistics, ({ one }) => ({
  website: one(websites, {
    fields: [statistics.websiteId],
    references: [websites.id],
  }),
}));

export const dockerServicesRelations = relations(dockerServices, ({ one }) => ({
  website: one(websites, {
    fields: [dockerServices.websiteId],
    references: [websites.id],
  }),
}));

export const dockerVolumesRelations = relations(dockerVolumes, ({ one }) => ({
  website: one(websites, {
    fields: [dockerVolumes.websiteId],
    references: [websites.id],
  }),
}));

export const websiteComponentsRelations = relations(websiteComponents, ({ one }) => ({
  website: one(websites, {
    fields: [websiteComponents.websiteId],
    references: [websites.id],
  }),
  component: one(components, {
    fields: [websiteComponents.componentId],
    references: [components.id],
  }),
}));

// Create Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertWebsiteSchema = createInsertSchema(websites).omit({ id: true, createdAt: true, updatedAt: true, views: true });
export const insertTemplateSchema = createInsertSchema(templates).omit({ id: true, createdAt: true });
export const insertComponentSchema = createInsertSchema(components).omit({ id: true });
export const insertActivitySchema = createInsertSchema(activities).omit({ id: true, timestamp: true });
export const insertDnsRecordSchema = createInsertSchema(dnsRecords).omit({ 
  id: true, 
  createdAt: true, 
  lastChecked: true, 
  verifiedAt: true, 
  sslCertExpiry: true
});
export const insertBackupSchema = createInsertSchema(backups).omit({ id: true, createdAt: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertSettingSchema = createInsertSchema(settings).omit({ id: true, updatedAt: true });
export const insertStatisticSchema = createInsertSchema(statistics).omit({ id: true });
export const insertDockerServiceSchema = createInsertSchema(dockerServices).omit({ id: true, createdAt: true, updatedAt: true });
export const insertDockerVolumeSchema = createInsertSchema(dockerVolumes).omit({ id: true, createdAt: true });
export const insertWebsiteComponentSchema = createInsertSchema(websiteComponents).omit({ id: true, createdAt: true });

// Export Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Website = typeof websites.$inferSelect;
export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;

export type Component = typeof components.$inferSelect;
export type InsertComponent = z.infer<typeof insertComponentSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type DnsRecord = typeof dnsRecords.$inferSelect;
export type InsertDnsRecord = z.infer<typeof insertDnsRecordSchema>;

export type Backup = typeof backups.$inferSelect;
export type InsertBackup = z.infer<typeof insertBackupSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;

export type Statistic = typeof statistics.$inferSelect;
export type InsertStatistic = z.infer<typeof insertStatisticSchema>;

export type DockerService = typeof dockerServices.$inferSelect;
export type InsertDockerService = z.infer<typeof insertDockerServiceSchema>;

export type DockerVolume = typeof dockerVolumes.$inferSelect;
export type InsertDockerVolume = z.infer<typeof insertDockerVolumeSchema>;

export type WebsiteComponent = typeof websiteComponents.$inferSelect;
export type InsertWebsiteComponent = z.infer<typeof insertWebsiteComponentSchema>;
