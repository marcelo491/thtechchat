/**
 * Módulo para integração com a API da Monetizze
 * Documentation: https://api.monetizze.com.br/2.1/apidoc/
 */

import axios from 'axios';

const API_BASE_URL = 'https://api.monetizze.com.br/2.1';

class MonetizzeAPI {
  private apiKey: string;
  
  constructor() {
    // A chave API será definida posteriormente via painel de configuração
    this.apiKey = process.env.MONETIZZE_API_KEY || '';
  }
  
  /**
   * Configura a chave API da Monetizze
   */
  setApiKey(apiKey: string) {
    this.apiKey = apiKey;
  }
  
  /**
   * Verifica se a API key está configurada
   */
  isConfigured(): boolean {
    return !!this.apiKey && this.apiKey.trim() !== '';
  }
  
  /**
   * Obtém o cabeçalho de autenticação para as requisições
   */
  private getAuthHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.apiKey}`
    };
  }
  
  /**
   * Busca produtos disponíveis na Monetizze
   */
  async getProducts() {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'API da Monetizze não configurada. Configure a chave API nas configurações.'
      };
    }
    
    try {
      const response = await axios.get(`${API_BASE_URL}/product`, {
        headers: this.getAuthHeaders()
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('Erro ao buscar produtos da Monetizze:', error.response?.data || error.message);
      
      return {
        success: false,
        error: 'Erro ao buscar produtos. Verifique a chave API ou tente novamente mais tarde.'
      };
    }
  }
  
  /**
   * Cria uma nova transação de compra
   */
  async createTransaction(transactionData: any) {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'API da Monetizze não configurada. Configure a chave API nas configurações.'
      };
    }
    
    try {
      const response = await axios.post(`${API_BASE_URL}/transactions`, transactionData, {
        headers: this.getAuthHeaders()
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('Erro ao criar transação na Monetizze:', error.response?.data || error.message);
      
      return {
        success: false,
        error: 'Erro ao processar transação. Verifique os dados ou tente novamente mais tarde.'
      };
    }
  }
  
  /**
   * Consulta o status de uma transação
   */
  async getTransactionStatus(transactionId: string) {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'API da Monetizze não configurada. Configure a chave API nas configurações.'
      };
    }
    
    try {
      const response = await axios.get(`${API_BASE_URL}/transactions/${transactionId}`, {
        headers: this.getAuthHeaders()
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('Erro ao consultar transação na Monetizze:', error.response?.data || error.message);
      
      return {
        success: false,
        error: 'Erro ao consultar status da transação.'
      };
    }
  }
}

// Exporta uma instância única para uso em toda a aplicação
export const monetizzeAPI = new MonetizzeAPI();