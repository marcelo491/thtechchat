import { storage } from "./storage";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { db } from "./db";
import { users } from "@shared/schema";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export async function seedDatabase() {
  console.log("Verificando se é necessário inicializar o banco de dados...");
  
  // Verifica se já existe algum usuário no sistema
  const usersExist = await db.execute(
    `SELECT COUNT(*) as count FROM users`
  );
  
  if (Number(usersExist.rows[0].count) > 0) {
    console.log("O banco de dados já está inicializado.");
    return;
  }
  
  console.log("Inicializando banco de dados com dados iniciais...");
  
  // Cria usuário administrador
  const adminUser = await storage.createUser({
    username: "admin",
    password: await hashPassword("admin123"),
    email: "admin@thtechweb.com",
    fullName: "Administrador",
    role: "admin"
  });
  
  console.log(`Usuário administrador criado com ID: ${adminUser.id}`);
  
  // Cria alguns componentes básicos
  const basicComponents = [
    { name: "Texto", category: "basic", type: "text", icon: "ri-text", content: {} },
    { name: "Imagem", category: "basic", type: "image", icon: "ri-image-line", content: {} },
    { name: "Botão", category: "basic", type: "button", icon: "ri-link", content: {} },
    { name: "Separador", category: "basic", type: "divider", icon: "ri-layout-row-line", content: {} },
    { name: "Lista", category: "basic", type: "list", icon: "ri-list-check", content: {} }
  ];
  
  const layoutComponents = [
    { name: "Container", category: "layout", type: "container", icon: "ri-layout-grid-line", content: {} },
    { name: "Linha / Coluna", category: "layout", type: "row-column", icon: "ri-layout-column-line", content: {} },
    { name: "Grid", category: "layout", type: "grid", icon: "ri-layout-masonry-line", content: {} },
    { name: "Barra Lateral", category: "layout", type: "sidebar", icon: "ri-layout-right-line", content: {} }
  ];
  
  const advancedComponents = [
    { name: "Navegação", category: "components", type: "navigation", icon: "ri-navigation-line", content: {} },
    { name: "Hero Section", category: "components", type: "hero", icon: "ri-layout-top-line", content: {} },
    { name: "Galeria", category: "components", type: "gallery", icon: "ri-gallery-line", content: {} },
    { name: "Depoimento", category: "components", type: "testimonial", icon: "ri-user-line", content: {} },
    { name: "Formulário de Contato", category: "components", type: "contact-form", icon: "ri-mail-line", content: {} },
    { name: "Card", category: "components", type: "card", icon: "ri-article-line", content: {} },
    { name: "Rodapé", category: "components", type: "footer", icon: "ri-layout-bottom-line", content: {} }
  ];
  
  // Cria os componentes
  for (const componentData of [...basicComponents, ...layoutComponents, ...advancedComponents]) {
    const component = await storage.createComponent(componentData);
    console.log(`Componente criado: ${component.name}`);
  }
  
  // Cria alguns templates básicos
  const templates = [
    { 
      name: "Site Empresarial", 
      category: "business", 
      isCustom: false, 
      premium: false, 
      content: {}, 
      thumbnail: "https://via.placeholder.com/300x200.png?text=Business+Template" 
    },
    { 
      name: "Portfólio", 
      category: "portfolio", 
      isCustom: false, 
      premium: false, 
      content: {}, 
      thumbnail: "https://via.placeholder.com/300x200.png?text=Portfolio+Template" 
    },
    { 
      name: "E-Commerce", 
      category: "ecommerce", 
      isCustom: false, 
      premium: true, 
      price: 9900, // R$ 99,00
      content: {}, 
      thumbnail: "https://via.placeholder.com/300x200.png?text=E-Commerce+Template" 
    },
    { 
      name: "Blog", 
      category: "blog", 
      isCustom: false, 
      premium: false, 
      content: {}, 
      thumbnail: "https://via.placeholder.com/300x200.png?text=Blog+Template" 
    },
    { 
      name: "Landing Page", 
      category: "landing", 
      isCustom: false, 
      premium: false, 
      content: {}, 
      thumbnail: "https://via.placeholder.com/300x200.png?text=Landing+Template" 
    }
  ];
  
  // Cria os templates
  for (const templateData of templates) {
    const template = await storage.createTemplate(templateData);
    console.log(`Template criado: ${template.name}`);
  }
  
  // Cria site de exemplo
  const website = await storage.createWebsite({
    name: "Site da Empresa",
    domain: "empresa.thtechweb.com",
    status: "published",
    userId: adminUser.id,
    templateId: 1, // Usa o primeiro template criado
    content: {},
    thumbnail: "https://via.placeholder.com/300x200.png?text=Site+da+Empresa"
  });
  
  console.log(`Site de exemplo criado: ${website.name}`);
  
  // Cria registro DNS para o site de exemplo
  const domainName = typeof website.domain === 'string' && website.domain 
    ? website.domain 
    : "empresa.thtechweb.com";
    
  const dnsRecord = await storage.createDnsRecord({
    domain: domainName,
    websiteId: website.id,
    recordType: "A"
  });
  
  console.log(`Registro DNS criado para: ${dnsRecord.domain}`);
  
  // Cria algumas atividades
  await storage.createActivity({
    type: "create",
    description: "Criado site inicial da empresa",
    entityId: website.id,
    entityType: "website",
    userId: adminUser.id,
    icon: "ri-global-line"
  });
  
  await storage.createActivity({
    type: "deploy",
    description: "Site da empresa publicado com sucesso",
    entityId: website.id,
    entityType: "website",
    userId: adminUser.id,
    icon: "ri-rocket-line"
  });
  
  console.log("Inicialização do banco de dados concluída com sucesso!");
}