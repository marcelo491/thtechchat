import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { monetizzeAPI } from "./monetizze";
import { z } from "zod";
import { setupAuth } from "./auth";
import { 
  insertWebsiteSchema,
  insertTemplateSchema,
  insertComponentSchema,
  insertActivitySchema,
  insertDnsRecordSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configurar autenticação
  setupAuth(app);
  
  // Middleware para verificar autenticação em rotas protegidas
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Não autorizado. Por favor, faça login." });
    }
    next();
  };
  
  // Middleware para verificar se o usuário é administrador
  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(403).json({ message: "Acesso negado. Permissão de administrador necessária." });
    }
    next();
  };
  // Website routes - protegidos por autenticação
  app.get("/api/websites", requireAuth, async (_req, res) => {
    try {
      const websites = await storage.getWebsites();
      res.json(websites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch websites" });
    }
  });
  
  app.get("/api/websites/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const website = await storage.getWebsite(id);
      if (!website) {
        return res.status(404).json({ message: "Website not found" });
      }
      res.json(website);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch website" });
    }
  });
  
  app.post("/api/websites", requireAuth, async (req, res) => {
    try {
      const validatedData = insertWebsiteSchema.parse(req.body);
      const website = await storage.createWebsite(validatedData);
      res.status(201).json(website);
    } catch (error) {
      res.status(400).json({ message: "Invalid website data", error });
    }
  });
  
  app.put("/api/websites/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertWebsiteSchema.partial().parse(req.body);
      const updatedWebsite = await storage.updateWebsite(id, validatedData);
      
      if (!updatedWebsite) {
        return res.status(404).json({ message: "Website not found" });
      }
      
      res.json(updatedWebsite);
    } catch (error) {
      res.status(400).json({ message: "Invalid website data", error });
    }
  });
  
  app.delete("/api/websites/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteWebsite(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Website not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete website" });
    }
  });
  
  // Template routes - protegidos por autenticação
  app.get("/api/templates", requireAuth, async (_req, res) => {
    try {
      const templates = await storage.getTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });
  
  app.get("/api/templates/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const template = await storage.getTemplate(id);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch template" });
    }
  });
  
  app.post("/api/templates", requireAuth, async (req, res) => {
    try {
      const validatedData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(validatedData);
      res.status(201).json(template);
    } catch (error) {
      res.status(400).json({ message: "Invalid template data", error });
    }
  });
  
  app.put("/api/templates/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertTemplateSchema.partial().parse(req.body);
      const updatedTemplate = await storage.updateTemplate(id, validatedData);
      
      if (!updatedTemplate) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(updatedTemplate);
    } catch (error) {
      res.status(400).json({ message: "Invalid template data", error });
    }
  });
  
  app.delete("/api/templates/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTemplate(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete template" });
    }
  });
  
  // Component routes - protegidos por autenticação
  app.get("/api/components", requireAuth, async (req, res) => {
    try {
      const category = req.query.category as string;
      let components;
      
      if (category) {
        components = await storage.getComponentsByCategory(category);
      } else {
        components = await storage.getComponents();
      }
      
      res.json(components);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch components" });
    }
  });
  
  app.get("/api/components/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const component = await storage.getComponent(id);
      
      if (!component) {
        return res.status(404).json({ message: "Component not found" });
      }
      
      res.json(component);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch component" });
    }
  });
  
  app.post("/api/components", requireAuth, async (req, res) => {
    try {
      const validatedData = insertComponentSchema.parse(req.body);
      const component = await storage.createComponent(validatedData);
      res.status(201).json(component);
    } catch (error) {
      res.status(400).json({ message: "Invalid component data", error });
    }
  });
  
  // Activity routes - protegidos por autenticação
  app.get("/api/activities", requireAuth, async (req, res) => {
    try {
      const limitParam = req.query.limit as string;
      let activities;
      
      if (limitParam) {
        const limit = parseInt(limitParam);
        activities = await storage.getRecentActivities(limit);
      } else {
        activities = await storage.getActivities();
      }
      
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });
  
  app.post("/api/activities", requireAuth, async (req, res) => {
    try {
      const validatedData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(validatedData);
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid activity data", error });
    }
  });
  
  // Stats route - protegido por autenticação
  app.get("/api/stats", requireAuth, async (_req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Monetizze API routes - protegidos por autenticação
  app.get("/api/monetizze/products", requireAuth, async (_req, res) => {
    try {
      const result = await monetizzeAPI.getProducts();
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        error: "Falha ao buscar produtos da Monetizze" 
      });
    }
  });

  app.post("/api/monetizze/transaction", requireAuth, async (req, res) => {
    try {
      const result = await monetizzeAPI.createTransaction(req.body);
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        error: "Falha ao processar transação na Monetizze"
      });
    }
  });

  app.get("/api/monetizze/transaction/:id", requireAuth, async (req, res) => {
    try {
      const transactionId = req.params.id;
      const result = await monetizzeAPI.getTransactionStatus(transactionId);
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        error: "Falha ao buscar status da transação na Monetizze" 
      });
    }
  });

  // API Key Management - protegido por autenticação
  app.post("/api/monetizze/config", requireAuth, async (req, res) => {
    try {
      const { apiKey } = req.body;
      if (!apiKey) {
        return res.status(400).json({ 
          success: false, 
          error: "Chave API é obrigatória" 
        });
      }
      
      monetizzeAPI.setApiKey(apiKey);
      // Em um sistema real, a chave seria armazenada em um banco de dados ou variável de ambiente
      
      res.json({ 
        success: true, 
        message: "Configuração da API Monetizze atualizada com sucesso" 
      });
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        error: "Falha ao configurar API Monetizze" 
      });
    }
  });

  app.get("/api/monetizze/config/status", requireAuth, async (_req, res) => {
    res.json({ 
      success: true, 
      configured: monetizzeAPI.isConfigured() 
    });
  });
  
  // DNS Record routes - protegidos por autenticação
  app.get("/api/dns-records", requireAuth, async (req, res) => {
    try {
      const websiteId = req.query.websiteId ? parseInt(req.query.websiteId as string) : undefined;
      
      if (!websiteId) {
        return res.status(400).json({ message: "Website ID is required" });
      }
      
      const dnsRecords = await storage.getDnsRecords(websiteId);
      res.json(dnsRecords);
    } catch (error) {
      res.status(500).json({ message: "Falha ao buscar registros DNS" });
    }
  });
  
  app.get("/api/dns-records/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const dnsRecord = await storage.getDnsRecord(id);
      
      if (!dnsRecord) {
        return res.status(404).json({ message: "Registro DNS não encontrado" });
      }
      
      res.json(dnsRecord);
    } catch (error) {
      res.status(500).json({ message: "Falha ao buscar registro DNS" });
    }
  });
  
  app.post("/api/dns-records", requireAuth, async (req, res) => {
    try {
      const validatedData = insertDnsRecordSchema.parse(req.body);
      
      // Check if domain already exists
      const existingRecord = await storage.getDnsRecordByDomain(validatedData.domain);
      if (existingRecord) {
        return res.status(400).json({ 
          message: "Domínio já está em uso. Por favor, escolha outro domínio." 
        });
      }
      
      // Set default values
      const dnsRecord = await storage.createDnsRecord({
        ...validatedData,
        status: "pending"
      });
      
      res.status(201).json(dnsRecord);
    } catch (error) {
      res.status(400).json({ message: "Dados de registro DNS inválidos", error });
    }
  });
  
  app.put("/api/dns-records/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertDnsRecordSchema.partial().parse(req.body);
      
      // If domain is being updated, check if new domain already exists
      if (validatedData.domain) {
        const dnsRecord = await storage.getDnsRecord(id);
        if (!dnsRecord) {
          return res.status(404).json({ message: "Registro DNS não encontrado" });
        }
        
        if (dnsRecord.domain !== validatedData.domain) {
          const existingRecord = await storage.getDnsRecordByDomain(validatedData.domain);
          if (existingRecord && existingRecord.id !== id) {
            return res.status(400).json({ 
              message: "Domínio já está em uso. Por favor, escolha outro domínio." 
            });
          }
        }
      }
      
      const updatedDnsRecord = await storage.updateDnsRecord(id, validatedData);
      
      if (!updatedDnsRecord) {
        return res.status(404).json({ message: "Registro DNS não encontrado" });
      }
      
      res.json(updatedDnsRecord);
    } catch (error) {
      res.status(400).json({ message: "Dados de registro DNS inválidos", error });
    }
  });
  
  app.delete("/api/dns-records/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDnsRecord(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Registro DNS não encontrado" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Falha ao excluir registro DNS" });
    }
  });
  
  app.post("/api/dns-records/:id/verify", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const dnsRecord = await storage.getDnsRecord(id);
      
      if (!dnsRecord) {
        return res.status(404).json({ message: "Registro DNS não encontrado" });
      }
      
      const verifiedRecord = await storage.verifyDnsRecord(id);
      res.json(verifiedRecord);
    } catch (error) {
      res.status(500).json({ message: "Falha ao verificar registro DNS" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
