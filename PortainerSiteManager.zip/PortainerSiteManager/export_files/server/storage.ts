import {
  users, User, InsertUser,
  websites, Website, InsertWebsite,
  templates, Template, InsertTemplate,
  components, Component, InsertComponent,
  activities, Activity, InsertActivity,
  dnsRecords, DnsRecord, InsertDnsRecord,
  backups, Backup, InsertBackup,
  products, Product, InsertProduct, 
  transactions, Transaction, InsertTransaction,
  settings, Setting, InsertSetting,
  statistics, Statistic, InsertStatistic,
  dockerServices, DockerService, InsertDockerService,
  dockerVolumes, DockerVolume, InsertDockerVolume,
  websiteComponents, WebsiteComponent, InsertWebsiteComponent
} from "@shared/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import { db, pool } from "./db";
import connectPg from "connect-pg-simple";
import session from "express-session";
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Session store
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Website operations
  getWebsites(): Promise<Website[]>;
  getWebsite(id: number): Promise<Website | undefined>;
  getWebsiteByDomain(domain: string): Promise<Website | undefined>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: number, website: Partial<InsertWebsite>): Promise<Website | undefined>;
  deleteWebsite(id: number): Promise<boolean>;
  incrementWebsiteViews(id: number): Promise<Website | undefined>;
  
  // Template operations
  getTemplates(): Promise<Template[]>;
  getTemplate(id: number): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined>;
  deleteTemplate(id: number): Promise<boolean>;
  
  // Component operations
  getComponents(): Promise<Component[]>;
  getComponentsByCategory(category: string): Promise<Component[]>;
  getComponent(id: number): Promise<Component | undefined>;
  createComponent(component: InsertComponent): Promise<Component>;
  
  // Activity operations
  getActivities(): Promise<Activity[]>;
  getRecentActivities(limit: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Stats operations
  getStats(): Promise<any>;
  
  // DNS operations
  getDnsRecords(websiteId: number): Promise<DnsRecord[]>;
  getDnsRecord(id: number): Promise<DnsRecord | undefined>;
  getDnsRecordByDomain(domain: string): Promise<DnsRecord | undefined>;
  createDnsRecord(dnsRecord: InsertDnsRecord): Promise<DnsRecord>;
  updateDnsRecord(id: number, dnsRecord: Partial<InsertDnsRecord>): Promise<DnsRecord | undefined>;
  deleteDnsRecord(id: number): Promise<boolean>;
  verifyDnsRecord(id: number): Promise<DnsRecord | undefined>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: "session" 
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Website operations
  async getWebsites(): Promise<Website[]> {
    return await db.select().from(websites).orderBy(desc(websites.updatedAt));
  }

  async getWebsite(id: number): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    return website;
  }

  async getWebsiteByDomain(domain: string): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.domain, domain));
    return website;
  }

  async createWebsite(insertWebsite: InsertWebsite): Promise<Website> {
    const [website] = await db.insert(websites)
      .values({
        ...insertWebsite,
        views: 0,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();

    // Criar uma atividade
    await this.createActivity({
      type: "create",
      description: `Criado novo site: ${website.name}`,
      entityId: website.id,
      entityType: "website",
      userId: website.userId,
      icon: "ri-global-line"
    });

    return website;
  }

  async updateWebsite(id: number, updateData: Partial<InsertWebsite>): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    if (!website) return undefined;

    const [updatedWebsite] = await db.update(websites)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(websites.id, id))
      .returning();

    // Criar uma atividade
    await this.createActivity({
      type: "update",
      description: `Atualizado site: ${updatedWebsite.name}`,
      entityId: updatedWebsite.id,
      entityType: "website",
      userId: updatedWebsite.userId,
      icon: "ri-edit-line"
    });

    return updatedWebsite;
  }

  async deleteWebsite(id: number): Promise<boolean> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    if (!website) return false;

    await db.delete(websites).where(eq(websites.id, id));

    // Criar uma atividade
    await this.createActivity({
      type: "delete",
      description: `Excluído site: ${website.name}`,
      entityId: website.id,
      entityType: "website",
      userId: website.userId,
      icon: "ri-delete-bin-line"
    });

    return true;
  }

  async incrementWebsiteViews(id: number): Promise<Website | undefined> {
    const [updatedWebsite] = await db.update(websites)
      .set({
        views: sql`${websites.views} + 1`
      })
      .where(eq(websites.id, id))
      .returning();

    return updatedWebsite;
  }

  // Template operations
  async getTemplates(): Promise<Template[]> {
    return await db.select().from(templates);
  }

  async getTemplate(id: number): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    return template;
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const [template] = await db.insert(templates)
      .values({
        ...insertTemplate,
        createdAt: new Date()
      })
      .returning();

    return template;
  }

  async updateTemplate(id: number, updateData: Partial<InsertTemplate>): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    if (!template) return undefined;

    const [updatedTemplate] = await db.update(templates)
      .set(updateData)
      .where(eq(templates.id, id))
      .returning();

    return updatedTemplate;
  }

  async deleteTemplate(id: number): Promise<boolean> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    if (!template) return false;

    await db.delete(templates).where(eq(templates.id, id));
    return true;
  }

  // Component operations
  async getComponents(): Promise<Component[]> {
    return await db.select().from(components);
  }

  async getComponentsByCategory(category: string): Promise<Component[]> {
    return await db.select().from(components).where(eq(components.category, category));
  }

  async getComponent(id: number): Promise<Component | undefined> {
    const [component] = await db.select().from(components).where(eq(components.id, id));
    return component;
  }

  async createComponent(insertComponent: InsertComponent): Promise<Component> {
    const [component] = await db.insert(components)
      .values(insertComponent)
      .returning();

    return component;
  }

  // Activity operations
  async getActivities(): Promise<Activity[]> {
    return await db.select().from(activities).orderBy(desc(activities.timestamp));
  }

  async getRecentActivities(limit: number): Promise<Activity[]> {
    return await db.select().from(activities)
      .orderBy(desc(activities.timestamp))
      .limit(limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db.insert(activities)
      .values({
        ...insertActivity,
        timestamp: new Date()
      })
      .returning();

    return activity;
  }

  // Stats operations
  async getStats(): Promise<any> {
    // Contar sites ativos (publicados)
    const [activeSitesResult] = await db
      .select({ count: sql`count(*)`.mapWith(Number) })
      .from(websites)
      .where(eq(websites.status, "published"));
    
    // Soma total de visualizações
    const [totalViewsResult] = await db
      .select({ sum: sql`sum(${websites.views})`.mapWith(Number) })
      .from(websites);
    
    // Contar número de deployments (atividades do tipo deploy)
    const [deploymentsResult] = await db
      .select({ count: sql`count(*)`.mapWith(Number) })
      .from(activities)
      .where(eq(activities.type, "deploy"));
    
    // Contar número de templates
    const [totalTemplatesResult] = await db
      .select({ count: sql`count(*)`.mapWith(Number) })
      .from(templates);
    
    // Contar número de templates customizados
    const [customTemplatesResult] = await db
      .select({ count: sql`count(*)`.mapWith(Number) })
      .from(templates)
      .where(eq(templates.isCustom, true));
    
    return {
      activeSites: activeSitesResult?.count || 0,
      totalViews: totalViewsResult?.sum || 0,
      deployments: deploymentsResult?.count || 0,
      totalTemplates: totalTemplatesResult?.count || 0,
      customTemplates: customTemplatesResult?.count || 0
    };
  }

  // DNS operations
  async getDnsRecords(websiteId: number): Promise<DnsRecord[]> {
    return await db.select().from(dnsRecords)
      .where(eq(dnsRecords.websiteId, websiteId));
  }

  async getDnsRecord(id: number): Promise<DnsRecord | undefined> {
    const [record] = await db.select().from(dnsRecords).where(eq(dnsRecords.id, id));
    return record;
  }

  async getDnsRecordByDomain(domain: string): Promise<DnsRecord | undefined> {
    const [record] = await db.select().from(dnsRecords).where(eq(dnsRecords.domain, domain));
    return record;
  }

  async createDnsRecord(insertDnsRecord: InsertDnsRecord): Promise<DnsRecord> {
    const [record] = await db.insert(dnsRecords)
      .values({
        ...insertDnsRecord,
        status: "pending",
        createdAt: new Date()
      })
      .returning();

    return record;
  }

  async updateDnsRecord(id: number, updateData: Partial<InsertDnsRecord>): Promise<DnsRecord | undefined> {
    const [record] = await db.select().from(dnsRecords).where(eq(dnsRecords.id, id));
    if (!record) return undefined;

    const [updatedRecord] = await db.update(dnsRecords)
      .set(updateData)
      .where(eq(dnsRecords.id, id))
      .returning();

    return updatedRecord;
  }

  async deleteDnsRecord(id: number): Promise<boolean> {
    const [record] = await db.select().from(dnsRecords).where(eq(dnsRecords.id, id));
    if (!record) return false;

    await db.delete(dnsRecords).where(eq(dnsRecords.id, id));
    return true;
  }

  async verifyDnsRecord(id: number): Promise<DnsRecord | undefined> {
    const [record] = await db.select().from(dnsRecords).where(eq(dnsRecords.id, id));
    if (!record) return undefined;

    const [updatedRecord] = await db.update(dnsRecords)
      .set({
        status: "verified",
        verifiedAt: new Date(),
        lastChecked: new Date()
      })
      .where(eq(dnsRecords.id, id))
      .returning();

    return updatedRecord;
  }
}

export const storage = new DatabaseStorage();