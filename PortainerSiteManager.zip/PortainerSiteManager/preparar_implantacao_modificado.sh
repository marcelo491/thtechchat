#!/bin/bash
# Script para preparação da implantação do THTech Web Studio
set -e

echo "=== Preparando ambiente para implantação ==="

# Verificar se estamos no diretório certo
if [ ! -f "thtech-web-studio-portainer.tar.gz" ]; then
  echo "ERRO: Arquivo thtech-web-studio-portainer.tar.gz não encontrado!"
  echo "Certifique-se de estar no diretório correto."
  exit 1
fi

# Criar diretório temporário para extração
mkdir -p temp_extract
echo "Extraindo arquivos..."
tar -xzf thtech-web-studio-portainer.tar.gz -C temp_extract

# Mover os arquivos para o diretório atual
echo "Copiando arquivos..."
cp -r temp_extract/* .

# Remover diretório temporário
rm -rf temp_extract

# Verificar redes Docker e criar se necessário
echo "=== Verificando e criando redes Docker ==="
# Verificar e criar a rede traefik-public se não existir
if ! docker network ls | grep -q traefik-public; then
  echo "Criando rede traefik-public..."
  docker network create --driver overlay traefik-public || echo "Erro ao criar rede, continuando mesmo assim..."
fi

# Verificar e criar a rede minha_rede se não existir
if ! docker network ls | grep -q minha_rede; then
  echo "Criando rede minha_rede..."
  docker network create minha_rede || echo "Erro ao criar rede, continuando mesmo assim..."
fi

# Como estamos usando apenas o arquivo portainer, vamos pular a verificação
# dos diretórios client/server/shared e ir direto para a implantação

echo "=== Construindo imagem Docker ==="
docker build -t thtech-web-studio:latest .

echo "=== Implantando com Docker Swarm ==="
docker stack deploy -c docker-compose.yml thtech

echo "=== Implantação concluída! ==="
echo "A aplicação estará disponível em: painel.thtech.com.br"
echo "O painel de administração do banco de dados estará disponível em: db.thtech.com.br"