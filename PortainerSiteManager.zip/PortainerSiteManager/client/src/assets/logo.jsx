import React from 'react';

export const THLogo = ({ className = '', width = 80, height = 80, fill = '#1e2a34' }) => {
  return (
    <svg 
      width={width} 
      height={height} 
      viewBox="0 0 120 120" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <rect x="0" y="0" width="120" height="120" rx="10" fill={fill} />
      <circle cx="20" cy="20" r="5" fill="white" />
      <circle cx="40" cy="20" r="5" fill="white" />
      <circle cx="60" cy="20" r="5" fill="white" />
      <path d="M30 60 L20 70 L30 80" stroke="white" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M60 45 L70 70 L60 95" stroke="white" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M90 60 L100 70 L90 80" stroke="white" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};