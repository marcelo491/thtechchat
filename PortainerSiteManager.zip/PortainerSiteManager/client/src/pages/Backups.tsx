import { useState } from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Backup {
  id: string;
  name: string;
  size: string;
  type: 'full' | 'incremental' | 'differential';
  status: 'completed' | 'in-progress' | 'failed';
  date: string;
  website: string;
}

export default function Backups() {
  const [backups, setBackups] = useState<Backup[]>([
    {
      id: 'b1',
      name: 'Full Backup - Weekly',
      size: '1.2 GB',
      type: 'full',
      status: 'completed',
      date: '2023-01-15T10:30:00',
      website: 'Company Homepage'
    },
    {
      id: 'b2',
      name: 'Incremental Backup - Daily',
      size: '256 MB',
      type: 'incremental',
      status: 'completed',
      date: '2023-01-16T02:00:00',
      website: 'Company Homepage'
    },
    {
      id: 'b3',
      name: 'Full Backup - Weekly',
      size: '3.5 GB',
      type: 'full',
      status: 'completed',
      date: '2023-01-15T11:15:00',
      website: 'E-commerce Store'
    },
    {
      id: 'b4',
      name: 'Differential Backup - Daily',
      size: '890 MB',
      type: 'differential',
      status: 'in-progress',
      date: '2023-01-16T03:30:00',
      website: 'E-commerce Store'
    },
    {
      id: 'b5',
      name: 'Full Backup - Monthly',
      size: '4.7 GB',
      type: 'full',
      status: 'failed',
      date: '2023-01-01T00:15:00',
      website: 'Blog Site'
    }
  ]);
  
  const [schedules, setSchedules] = useState([
    {
      id: 's1',
      name: 'Weekly Full Backup',
      website: 'Company Homepage',
      type: 'full',
      frequency: 'weekly',
      day: 'Sunday',
      time: '02:00',
      retention: '4 weeks'
    },
    {
      id: 's2',
      name: 'Daily Incremental Backup',
      website: 'Company Homepage',
      type: 'incremental',
      frequency: 'daily',
      day: '-',
      time: '02:00',
      retention: '7 days'
    },
    {
      id: 's3',
      name: 'Weekly Full Backup',
      website: 'E-commerce Store',
      type: 'full',
      frequency: 'weekly',
      day: 'Sunday',
      time: '03:00',
      retention: '4 weeks'
    },
    {
      id: 's4',
      name: 'Daily Differential Backup',
      website: 'E-commerce Store',
      type: 'differential',
      frequency: 'daily',
      day: '-',
      time: '03:30',
      retention: '7 days'
    },
    {
      id: 's5',
      name: 'Monthly Full Backup',
      website: 'Blog Site',
      type: 'full',
      frequency: 'monthly',
      day: '1',
      time: '00:15',
      retention: '12 months'
    }
  ]);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Concluído</Badge>;
      case 'in-progress':
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Em Andamento</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Falhou</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200">Desconhecido</Badge>;
    }
  };
  
  const getTypeBadge = (type: string) => {
    switch(type) {
      case 'full':
        return <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">Completo</Badge>;
      case 'incremental':
        return <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">Incremental</Badge>;
      case 'differential':
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Diferencial</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200">Desconhecido</Badge>;
    }
  };
  
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<Backup | null>(null);
  const [restoreProgress, setRestoreProgress] = useState(0);
  const [isRestoring, setIsRestoring] = useState(false);
  
  // Estados para o backup rápido
  const [quickBackupSite, setQuickBackupSite] = useState("company-homepage");
  const [quickBackupType, setQuickBackupType] = useState("full");
  const [quickBackupName, setQuickBackupName] = useState("");
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [backupDialogOpen, setBackupDialogOpen] = useState(false);
  
  const handleRestoreBackup = (backup: Backup) => {
    setSelectedBackup(backup);
    setRestoreDialogOpen(true);
    setRestoreProgress(0);
    setIsRestoring(false);
  };
  
  // Função para criar um novo backup com remoção do anterior
  const createNewBackup = () => {
    // Validar campos
    if (!quickBackupName.trim()) {
      alert("Por favor, informe um nome para o backup.");
      return;
    }
    
    setBackupDialogOpen(true);
    setBackupProgress(0);
    setIsCreatingBackup(true);
    
    // Encontrar o site real com base no valor selecionado
    let siteName = "Página da Empresa";
    if (quickBackupSite === "e-commerce-store") siteName = "E-commerce Store";
    if (quickBackupSite === "blog-site") siteName = "Blog Site";
    
    // Simular o processo de backup
    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setBackupProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        
        // Gerar um novo ID único
        const newId = `b${Date.now()}`;
        
        // Remover backups anteriores do mesmo tipo e site
        const filteredBackups = backups.filter(backup => 
          !(backup.type === quickBackupType && backup.website === siteName)
        );
        
        // Adicionar o novo backup
        const newBackup: Backup = {
          id: newId,
          name: quickBackupName,
          size: `${Math.floor(Math.random() * 10) / 10 + 0.5} GB`,
          type: quickBackupType as 'full' | 'incremental' | 'differential',
          status: 'completed',
          date: new Date().toISOString(),
          website: siteName
        };
        
        // Atualizar a lista de backups
        setBackups([...filteredBackups, newBackup]);
        
        // Limpar o formulário
        setQuickBackupName("");
        
        // Fechar o diálogo
        setTimeout(() => {
          setIsCreatingBackup(false);
          setBackupDialogOpen(false);
        }, 1000);
      }
    }, 200);
  };
  
  const startRestore = () => {
    setIsRestoring(true);
    
    // Simulação do progresso de restauração
    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setRestoreProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsRestoring(false);
          setRestoreDialogOpen(false);
        }, 1000);
      }
    }, 300);
  };

  return (
    <>
      {/* Diálogo de progresso de backup */}
      <Dialog open={backupDialogOpen} onOpenChange={setBackupDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Criando Backup</DialogTitle>
            <DialogDescription>
              {isCreatingBackup 
                ? 'O backup está sendo criado. Por favor, aguarde.' 
                : 'Backup criado com sucesso!'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {backupProgress < 100 ? 'Progresso:' : 'Concluído!'}
                </span>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {backupProgress}%
                </span>
              </div>
              <Progress value={backupProgress} className="w-full" />
            </div>
            
            <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
              {backupProgress < 100 
                ? 'Backups anteriores do mesmo tipo e site serão excluídos automaticamente.' 
                : 'Backups anteriores do mesmo tipo e site foram excluídos automaticamente.'}
            </div>
          </div>
          
          {backupProgress >= 100 && (
            <DialogFooter>
              <Button 
                type="button" 
                onClick={() => setBackupDialogOpen(false)}
              >
                Fechar
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>

      <Header 
        title="Backups" 
        actions={
          <div className="flex space-x-2">
            <Button 
              size="sm"
              className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
            >
              <i className="ri-add-line mr-1.5"></i>
              Novo Backup
            </Button>
            <Button 
              size="sm"
              variant="outline"
            >
              <i className="ri-settings-4-line mr-1.5"></i>
              Configurações
            </Button>
          </div>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="backups" className="space-y-8">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="backups">Backups</TabsTrigger>
            <TabsTrigger value="schedule">Agendamentos</TabsTrigger>
            <TabsTrigger value="storage">Armazenamento</TabsTrigger>
          </TabsList>
          
          <TabsContent value="backups">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Backups Recentes</CardTitle>
                <CardDescription>Histórico de backups realizados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Nome</th>
                        <th scope="col" className="px-6 py-3">Site</th>
                        <th scope="col" className="px-6 py-3">Tipo</th>
                        <th scope="col" className="px-6 py-3">Tamanho</th>
                        <th scope="col" className="px-6 py-3">Status</th>
                        <th scope="col" className="px-6 py-3">Data</th>
                        <th scope="col" className="px-6 py-3">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {backups.map((backup) => (
                        <tr key={backup.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                          <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                            {backup.name}
                          </td>
                          <td className="px-6 py-4">
                            {backup.website}
                          </td>
                          <td className="px-6 py-4">
                            {getTypeBadge(backup.type)}
                          </td>
                          <td className="px-6 py-4">
                            {backup.size}
                          </td>
                          <td className="px-6 py-4">
                            {getStatusBadge(backup.status)}
                          </td>
                          <td className="px-6 py-4">
                            {formatDate(backup.date)}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleRestoreBackup(backup)}
                                disabled={backup.status !== 'completed'}
                              >
                                Restaurar
                              </Button>
                              <Button variant="outline" size="sm">
                                <i className="ri-download-line"></i>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Status de Armazenamento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Espaço Utilizado</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">42% (21GB / 50GB)</p>
                      </div>
                      <Progress value={42} className="w-full" />
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Backups Completos</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">15.2 GB</div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Backups Incrementais</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">3.8 GB</div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Backups Diferenciais</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">2.0 GB</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Status Atual</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                        <i className="ri-timer-line text-blue-600 dark:text-blue-300"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Próximo Backup Agendado</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">E-commerce Store - Differential - Hoje às 23:30</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                        <i className="ri-check-line text-green-600 dark:text-green-300"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Último Backup Concluído</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Company Homepage - Incremental - Hoje às 02:00</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center">
                        <i className="ri-error-warning-line text-red-600 dark:text-red-300"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Último Erro</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Blog Site - Full - 01/01/2023 00:15 - Espaço Insuficiente</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Backup Rápido</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="quick-backup-site">Site</Label>
                      <Select 
                        value={quickBackupSite} 
                        onValueChange={setQuickBackupSite}
                      >
                        <SelectTrigger id="quick-backup-site">
                          <SelectValue placeholder="Selecione um site" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="company-homepage">Página da Empresa</SelectItem>
                          <SelectItem value="e-commerce-store">Loja E-commerce</SelectItem>
                          <SelectItem value="blog-site">Blog</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="quick-backup-type">Tipo de Backup</Label>
                      <Select 
                        value={quickBackupType} 
                        onValueChange={setQuickBackupType}
                      >
                        <SelectTrigger id="quick-backup-type">
                          <SelectValue placeholder="Selecione um tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="full">Completo</SelectItem>
                          <SelectItem value="incremental">Incremental</SelectItem>
                          <SelectItem value="differential">Diferencial</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs italic text-amber-600 dark:text-amber-400">
                        Nota: Ao criar um novo backup, qualquer backup anterior do mesmo tipo e site será automaticamente excluído.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="quick-backup-name">Nome do Backup</Label>
                      <Input 
                        id="quick-backup-name" 
                        placeholder="Ex: Backup Manual - Janeiro 2023" 
                        value={quickBackupName}
                        onChange={(e) => setQuickBackupName(e.target.value)}
                      />
                    </div>
                    
                    <Button 
                      className="w-full"
                      onClick={createNewBackup}
                      disabled={isCreatingBackup}
                    >
                      {isCreatingBackup ? 'Criando...' : 'Iniciar Backup'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="schedule">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Agendamentos de Backups</CardTitle>
                <CardDescription>Configurações de backups automatizados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Nome</th>
                        <th scope="col" className="px-6 py-3">Site</th>
                        <th scope="col" className="px-6 py-3">Tipo</th>
                        <th scope="col" className="px-6 py-3">Frequência</th>
                        <th scope="col" className="px-6 py-3">Dia</th>
                        <th scope="col" className="px-6 py-3">Hora</th>
                        <th scope="col" className="px-6 py-3">Retenção</th>
                        <th scope="col" className="px-6 py-3">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {schedules.map((schedule) => (
                        <tr key={schedule.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                          <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                            {schedule.name}
                          </td>
                          <td className="px-6 py-4">
                            {schedule.website}
                          </td>
                          <td className="px-6 py-4">
                            {getTypeBadge(schedule.type)}
                          </td>
                          <td className="px-6 py-4 capitalize">
                            {schedule.frequency === 'daily' ? 'Diário' : 
                             schedule.frequency === 'weekly' ? 'Semanal' :
                             schedule.frequency === 'monthly' ? 'Mensal' : schedule.frequency}
                          </td>
                          <td className="px-6 py-4">
                            {schedule.day === 'Sunday' ? 'Domingo' :
                             schedule.day === 'Monday' ? 'Segunda' :
                             schedule.day === 'Tuesday' ? 'Terça' :
                             schedule.day === 'Wednesday' ? 'Quarta' :
                             schedule.day === 'Thursday' ? 'Quinta' :
                             schedule.day === 'Friday' ? 'Sexta' :
                             schedule.day === 'Saturday' ? 'Sábado' : schedule.day}
                          </td>
                          <td className="px-6 py-4">
                            {schedule.time}
                          </td>
                          <td className="px-6 py-4">
                            {schedule.retention === '7 days' ? '7 dias' :
                             schedule.retention === '4 weeks' ? '4 semanas' :
                             schedule.retention === '12 months' ? '12 meses' : schedule.retention}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                              >
                                <i className="ri-edit-line"></i>
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                              >
                                <i className="ri-delete-bin-line"></i>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Novo Agendamento</CardTitle>
                <CardDescription>Configurar um novo backup automatizado</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="schedule-name">Nome do Agendamento</Label>
                      <Input id="schedule-name" placeholder="Ex: Backup Semanal Completo" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="schedule-site">Site</Label>
                      <Select>
                        <SelectTrigger id="schedule-site">
                          <SelectValue placeholder="Selecione um site" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="company-homepage">Página da Empresa</SelectItem>
                          <SelectItem value="e-commerce-store">Loja E-commerce</SelectItem>
                          <SelectItem value="blog-site">Blog</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="schedule-type">Tipo de Backup</Label>
                      <Select>
                        <SelectTrigger id="schedule-type">
                          <SelectValue placeholder="Selecione um tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="full">Completo</SelectItem>
                          <SelectItem value="incremental">Incremental</SelectItem>
                          <SelectItem value="differential">Diferencial</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="schedule-frequency">Frequência</Label>
                      <Select>
                        <SelectTrigger id="schedule-frequency">
                          <SelectValue placeholder="Selecione uma frequência" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Diário</SelectItem>
                          <SelectItem value="weekly">Semanal</SelectItem>
                          <SelectItem value="monthly">Mensal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="schedule-day">Dia da Semana</Label>
                      <Select>
                        <SelectTrigger id="schedule-day">
                          <SelectValue placeholder="Selecione um dia" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Sunday">Domingo</SelectItem>
                          <SelectItem value="Monday">Segunda-feira</SelectItem>
                          <SelectItem value="Tuesday">Terça-feira</SelectItem>
                          <SelectItem value="Wednesday">Quarta-feira</SelectItem>
                          <SelectItem value="Thursday">Quinta-feira</SelectItem>
                          <SelectItem value="Friday">Sexta-feira</SelectItem>
                          <SelectItem value="Saturday">Sábado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="schedule-time">Hora</Label>
                      <Input id="schedule-time" type="time" defaultValue="02:00" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="schedule-retention">Política de Retenção</Label>
                      <Select defaultValue="keep_latest">
                        <SelectTrigger id="schedule-retention">
                          <SelectValue placeholder="Selecione uma política" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="keep_latest">Manter apenas o mais recente</SelectItem>
                          <SelectItem value="7_days">7 dias</SelectItem>
                          <SelectItem value="2_weeks">2 semanas</SelectItem>
                          <SelectItem value="1_month">1 mês</SelectItem>
                          <SelectItem value="3_months">3 meses</SelectItem>
                          <SelectItem value="6_months">6 meses</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        A opção "Manter apenas o mais recente" excluirá automaticamente o backup anterior quando um novo for criado.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end">
                  <Button>Salvar Agendamento</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="storage">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Uso de Armazenamento</CardTitle>
                  <CardDescription>Visão detalhada do espaço de armazenamento</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Espaço Total Utilizado</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">21GB / 50GB</p>
                      </div>
                      <Progress value={42} className="w-full" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Página da Empresa</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">5.8GB</p>
                      </div>
                      <Progress value={(5.8/50)*100} className="w-full" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Loja E-commerce</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">12.2GB</p>
                      </div>
                      <Progress value={(12.2/50)*100} className="w-full" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Blog</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">3.0GB</p>
                      </div>
                      <Progress value={(3/50)*100} className="w-full" />
                    </div>
                    
                    <div className="mt-4">
                      <Button variant="outline" className="w-full">
                        Gerenciar Armazenamento
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Armazenamento</CardTitle>
                  <CardDescription>Opções de armazenamento de backup</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="storage-location">Local de Armazenamento</Label>
                      <Select defaultValue="local">
                        <SelectTrigger id="storage-location">
                          <SelectValue placeholder="Selecione um local" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="local">Armazenamento Local</SelectItem>
                          <SelectItem value="s3">Amazon S3</SelectItem>
                          <SelectItem value="gcs">Google Cloud Storage</SelectItem>
                          <SelectItem value="azure">Azure Blob Storage</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="storage-compression">Compressão</Label>
                      <Select defaultValue="medium">
                        <SelectTrigger id="storage-compression">
                          <SelectValue placeholder="Selecione um nível" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Sem Compressão</SelectItem>
                          <SelectItem value="low">Baixa</SelectItem>
                          <SelectItem value="medium">Média</SelectItem>
                          <SelectItem value="high">Alta</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="storage-encryption">Criptografia</Label>
                      <Select defaultValue="aes256">
                        <SelectTrigger id="storage-encryption">
                          <SelectValue placeholder="Selecione um método" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Sem Criptografia</SelectItem>
                          <SelectItem value="aes128">AES-128</SelectItem>
                          <SelectItem value="aes256">AES-256</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="storage-quota">Cota de Espaço (GB)</Label>
                      <Input id="storage-quota" type="number" defaultValue="50" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="storage-cleanup">Limpeza Automática</Label>
                      <Select defaultValue="latest_only">
                        <SelectTrigger id="storage-cleanup">
                          <SelectValue placeholder="Selecione uma opção" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="latest_only">Manter Apenas o Mais Recente</SelectItem>
                          <SelectItem value="auto">Baseada em Cota</SelectItem>
                          <SelectItem value="age">Baseada em Idade</SelectItem>
                          <SelectItem value="none">Desativada</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        A opção "Manter Apenas o Mais Recente" é a recomendada e excluirá automaticamente backups antigos quando novos forem criados.
                      </p>
                    </div>
                    
                    <div className="mt-4">
                      <Button className="w-full">
                        Salvar Configurações
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      
      <Dialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restaurar Backup</DialogTitle>
            <DialogDescription>
              Você está prestes a restaurar o backup: {selectedBackup?.name}.
              {selectedBackup && (
                <div className="mt-2">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Site: {selectedBackup.website}<br />
                    Data: {formatDate(selectedBackup.date)}<br />
                    Tamanho: {selectedBackup.size}
                  </p>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          
          {isRestoring ? (
            <div className="space-y-4 py-4">
              <p className="text-sm text-gray-700 dark:text-gray-300">Restaurando backup...</p>
              <Progress value={restoreProgress} className="w-full" />
              <p className="text-xs text-gray-500 dark:text-gray-400">{restoreProgress}% concluído</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="restore-destination">Destino da Restauração</Label>
                  <Select defaultValue="original">
                    <SelectTrigger id="restore-destination">
                      <SelectValue placeholder="Selecione um destino" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="original">Site Original</SelectItem>
                      <SelectItem value="new">Novo Site</SelectItem>
                      <SelectItem value="staging">Ambiente de Teste</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setRestoreDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button onClick={startRestore}>
                  Iniciar Restauração
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}