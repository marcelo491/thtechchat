import Header from "@/components/Header";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Template } from "@shared/schema";
import { PlusIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Templates() {
  const { data: templates, isLoading } = useQuery({
    queryKey: ['/api/templates'],
  });

  return (
    <>
      <Header 
        title="Modelos" 
        actions={
          <Button 
            size="sm"
            className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
          >
            <PlusIcon className="h-4 w-4 mr-1.5" />
            Novo Modelo
          </Button>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <div className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-5 w-12" />
                  </div>
                  <Skeleton className="h-4 w-48 mb-4" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            templates?.map((template: Template) => (
              <Card key={template.id} className="overflow-hidden group">
                <div className="relative h-40 bg-gray-200 dark:bg-gray-700">
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <Button variant="secondary" size="icon" className="mr-2">
                      <i className="ri-eye-line"></i>
                    </Button>
                    <Button variant="secondary" size="icon" className="mr-2">
                      <i className="ri-edit-line"></i>
                    </Button>
                    <Button variant="secondary" size="icon">
                      <i className="ri-delete-bin-line"></i>
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-gray-900 dark:text-white">{template.name}</h3>
                    {template.isCustom && (
                      <Badge variant="outline" className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200 border-purple-200 dark:border-purple-800">
                        Personalizado
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 capitalize">{template.category}</p>
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {new Date(template.createdAt).toLocaleDateString()}
                    </div>
                    <Button variant="outline" size="sm">
                      Usar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </>
  );
}
