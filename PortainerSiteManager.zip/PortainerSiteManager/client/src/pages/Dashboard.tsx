import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import SiteCard from "@/components/SiteCard";
import ActivityItem from "@/components/ActivityItem";
import QuickAction from "@/components/QuickAction";
import { useStats } from "@/hooks/useStats";
import { useSites } from "@/hooks/useSites";
import { useActivities } from "@/hooks/useActivities";
import { Skeleton } from "@/components/ui/skeleton";
import logoIconSvg from "@/assets/thtech-logo-icon.svg";

export default function Dashboard() {
  const { stats, isLoading: statsLoading } = useStats();
  const { sites, isLoading: sitesLoading } = useSites();
  const { activities, isLoading: activitiesLoading } = useActivities(4);

  return (
    <>
      <Header title="Painel" />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="bg-primary-100 rounded-lg p-2">
              <svg width="80" height="80" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="0" y="0" width="120" height="120" rx="10" fill="#1e2a34" />
                <circle cx="20" cy="20" r="5" fill="white" />
                <circle cx="40" cy="20" r="5" fill="white" />
                <circle cx="60" cy="20" r="5" fill="white" />
                <path d="M30 60 L20 70 L30 80" stroke="white" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M60 45 L70 70 L60 95" stroke="white" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M90 60 L100 70 L90 80" stroke="white" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div className="text-center md:text-left">
              <h1 className="text-2xl md:text-3xl font-bold mb-2 text-gray-900">Bem-vindo ao THTech Web Studio</h1>
              <p className="text-base md:text-lg text-gray-700">Gerencie e implante seus sites com eficiência usando nossa plataforma Docker integrada.</p>
            </div>
          </div>
        </div>
        
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsLoading ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                <Skeleton className="h-10 w-10 rounded-full mb-4" />
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-8 w-16 mb-4" />
                <Skeleton className="h-4 w-32" />
              </div>
            ))
          ) : (
            <>
              <StatCard 
                title="Sites Ativos"
                value={stats?.activeSites}
                icon="ri-global-line"
                iconColor="blue"
                change={12}
                changeText="desde o mês passado"
              />
              <StatCard 
                title="Visualizações"
                value={`${((stats?.totalViews || 0) / 1000).toFixed(1)}k`}
                icon="ri-eye-line"
                iconColor="green"
                change={8.2}
                changeText="desde a semana passada"
              />
              <StatCard 
                title="Implantações"
                value={stats?.deployments}
                icon="ri-rocket-line"
                iconColor="amber"
                change={3.1}
                changeText="desde ontem"
              />
              <StatCard 
                title="Modelos"
                value={stats?.totalTemplates}
                icon="ri-file-list-3-line"
                iconColor="purple"
                text={`${stats?.customTemplates} modelos personalizados`}
              />
            </>
          )}
        </div>

        {/* Recent Sites */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">Sites Recentes</h2>
            <a href="/websites" className="text-primary-600 hover:text-primary-700 dark:text-primary-400 text-sm font-medium flex items-center">
              Ver todos
              <i className="ri-arrow-right-line ml-1"></i>
            </a>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sitesLoading ? (
              Array(3).fill(0).map((_, i) => (
                <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                  <Skeleton className="h-40 w-full" />
                  <div className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-5 w-12" />
                    </div>
                    <Skeleton className="h-4 w-48 mb-4" />
                    <div className="flex justify-between items-center">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  </div>
                </div>
              ))
            ) : (
              sites?.slice(0, 3).map((site) => (
                <SiteCard 
                  key={site.id}
                  site={site} 
                />
              ))
            )}
          </div>
        </div>

        {/* Recent Activities & Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Activities */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Atividades Recentes</h2>
            
            <div className="space-y-6">
              {activitiesLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <div key={i} className="flex">
                    <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-20" />
                      </div>
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </div>
                ))
              ) : (
                activities?.map((activity) => (
                  <ActivityItem key={activity.id} activity={activity} />
                ))
              )}
            </div>
            
            <div className="mt-6">
              <a href="/activities" className="text-primary-600 hover:text-primary-700 dark:text-primary-400 text-sm font-medium">
                Ver todas as atividades
              </a>
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Ações Rápidas</h2>
            
            <div className="space-y-4">
              <QuickAction 
                title="Criar Novo Site"
                description="Comece do zero ou use um modelo"
                icon="ri-add-line"
                iconColor="primary"
                href="/websites/new"
              />
              <QuickAction 
                title="Importar Site"
                description="Importar de fonte externa"
                icon="ri-upload-cloud-line"
                iconColor="green"
                href="/websites/import"
              />
              <QuickAction 
                title="Explorar Modelos"
                description="Encontre o ponto de partida perfeito"
                icon="ri-file-list-3-line"
                iconColor="purple"
                href="/templates"
              />
              <QuickAction 
                title="Configurar Sistema"
                description="Gerencie suas preferências de conta"
                icon="ri-settings-line"
                iconColor="amber"
                href="/settings"
              />
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
