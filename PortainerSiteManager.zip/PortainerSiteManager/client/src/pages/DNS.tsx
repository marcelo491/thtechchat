import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient, getQueryFn } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InsertDnsRecord, DnsRecord, Website } from "@shared/schema";
import Header from "@/components/Header";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2, X, Check, AlertTriangle, Database, Copy, RefreshCw, ExternalLink, Lock, AlarmClock, Network, Server } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useSites } from "@/hooks/useSites";
import TraefikConfig from "@/components/TraefikConfig";

// DNS Record Form Schema
const dnsRecordSchema = z.object({
  domain: z.string().min(3, "O domínio deve ter no mínimo 3 caracteres"),
  websiteId: z.number({
    required_error: "Selecione um site para associar este domínio",
  }),
  recordType: z.string({
    required_error: "Selecione um tipo de registro",
  }),
  sslEnabled: z.boolean().optional(),
});

type DnsRecordFormValues = z.infer<typeof dnsRecordSchema>;

export default function DNS() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isTraefikConfigOpen, setIsTraefikConfigOpen] = useState(false);
  const [selectedDnsRecord, setSelectedDnsRecord] = useState<DnsRecord | null>(null);
  const [formValues, setFormValues] = useState<Partial<DnsRecordFormValues>>({
    recordType: "A",
    sslEnabled: true,
  });
  const [selectedWebsiteId, setSelectedWebsiteId] = useState<number | null>(null);
  const [verifyingDomainId, setVerifyingDomainId] = useState<number | null>(null);

  // Query for loading websites
  const { sites: websites, isLoading: isLoadingWebsites } = useSites();

  // Query for loading DNS records
  const { data: dnsRecords, isLoading: isLoadingDnsRecords } = useQuery<DnsRecord[]>({
    queryKey: ["/api/dns-records", selectedWebsiteId],
    queryFn: getQueryFn({on401: "throw"}),
    enabled: !!selectedWebsiteId,
  });

  // Mutation for adding a new DNS record
  const createDnsRecordMutation = useMutation({
    mutationFn: async (data: InsertDnsRecord) => {
      const res = await apiRequest("POST", "/api/dns-records", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Registro DNS adicionado",
        description: "O novo domínio foi configurado com sucesso.",
      });
      setIsAddDialogOpen(false);
      setFormValues({
        recordType: "A",
        sslEnabled: true,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dns-records", selectedWebsiteId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao adicionar registro DNS",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation for verifying a DNS record
  const verifyDnsRecordMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/dns-records/${id}/verify`);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: data.status === "verified" 
          ? "Domínio verificado com sucesso" 
          : "Falha na verificação do domínio",
        description: data.status === "verified"
          ? "O domínio foi verificado e está pronto para uso."
          : data.errorMessage || "Verifique suas configurações DNS e tente novamente.",
        variant: data.status === "verified" ? "default" : "destructive",
      });
      setVerifyingDomainId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/dns-records", selectedWebsiteId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao verificar domínio",
        description: error.message,
        variant: "destructive",
      });
      setVerifyingDomainId(null);
    },
  });

  // Mutation for deleting a DNS record
  const deleteDnsRecordMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/dns-records/${id}`);
      return res.ok;
    },
    onSuccess: () => {
      toast({
        title: "Domínio removido",
        description: "O domínio foi removido com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dns-records", selectedWebsiteId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao remover domínio",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Mutation for updating DNS record with Traefik configuration
  const updateTraefikConfigMutation = useMutation({
    mutationFn: async ({id, config}: {id: number, config: any}) => {
      const res = await apiRequest("PATCH", `/api/dns-records/${id}`, {
        settings: {
          traefik: config
        }
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Configuração Traefik Salva",
        description: "As configurações do Traefik foram salvas com sucesso.",
      });
      setIsTraefikConfigOpen(false);
      setSelectedDnsRecord(null);
      queryClient.invalidateQueries({ queryKey: ["/api/dns-records", selectedWebsiteId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao salvar configurações",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const handleAddDnsRecord = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const validatedData = dnsRecordSchema.parse(formValues);
      createDnsRecordMutation.mutate(validatedData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const errorMessage = error.errors.map(err => `${err.message}`).join(", ");
        toast({
          title: "Formulário inválido",
          description: errorMessage,
          variant: "destructive",
        });
      }
    }
  };

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({ ...prev, [name]: value }));
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormValues(prev => ({ ...prev, [name]: name === "websiteId" ? parseInt(value) : value }));
  };

  // Handle switch changes
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormValues(prev => ({ ...prev, [name]: checked }));
  };

  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return "N/A";
    const dateObj = date instanceof Date ? date : new Date(date);
    return dateObj.toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getStatusBadge = (status: string) => {
    if (status === "verified") {
      return (
        <Badge className="bg-green-600">
          <Check className="w-3 h-3 mr-1" /> Verificado
        </Badge>
      );
    } else if (status === "pending") {
      return (
        <Badge variant="outline" className="text-amber-500 border-amber-500">
          <AlarmClock className="w-3 h-3 mr-1" /> Pendente
        </Badge>
      );
    } else {
      return (
        <Badge variant="destructive">
          <AlertTriangle className="w-3 h-3 mr-1" /> Erro
        </Badge>
      );
    }
  };

  const getInstructions = (record: DnsRecord) => {
    let instructions = "";
    
    if (record.recordType === "A") {
      instructions = `Configure um registro A no seu provedor DNS para apontar ${record.domain} para o IP 64.27.18.219`;
    } else if (record.recordType === "CNAME") {
      instructions = `Configure um registro CNAME no seu provedor DNS para apontar ${record.domain} para platform-example.com`;
    }
    
    return instructions;
  };

  return (
    <div className="flex flex-col min-h-screen p-6 space-y-6">
      <Header title="Gerenciamento de DNS" />

      <div className="grid grid-cols-1 gap-6">
        <div className="flex items-center justify-between bg-card p-4 rounded-lg shadow">
          <div className="flex items-center gap-4">
            <Database className="w-5 h-5 text-primary" />
            <Select
              value={selectedWebsiteId?.toString() || ""}
              onValueChange={(value) => setSelectedWebsiteId(Number(value))}
            >
              <SelectTrigger className="w-[280px]">
                <SelectValue placeholder="Selecione um site para gerenciar domínios" />
              </SelectTrigger>
              <SelectContent>
                {isLoadingWebsites ? (
                  <div className="flex items-center justify-center py-2">
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Carregando...
                  </div>
                ) : (
                  websites?.map((site: Website) => (
                    <SelectItem key={site.id} value={site.id.toString()}>
                      {site.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                disabled={!selectedWebsiteId} 
                variant="default"
              >
                Adicionar Domínio
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Adicionar Novo Domínio</DialogTitle>
                <DialogDescription>
                  Configure um novo domínio personalizado para o seu site.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAddDnsRecord} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="domain">Nome de Domínio</Label>
                  <Input
                    id="domain"
                    name="domain"
                    placeholder="exemplo.com.br ou blog.exemplo.com.br"
                    value={formValues.domain || ""}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="website">Site Associado</Label>
                  <Select
                    value={formValues.websiteId?.toString() || ""}
                    onValueChange={(value) => handleSelectChange("websiteId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um site" />
                    </SelectTrigger>
                    <SelectContent>
                      {websites?.map((site: Website) => (
                        <SelectItem key={site.id} value={site.id.toString()}>
                          {site.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="recordType">Tipo de Registro</Label>
                  <Select
                    value={formValues.recordType || "A"}
                    onValueChange={(value) => handleSelectChange("recordType", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo de registro" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">Registro A (Recomendado)</SelectItem>
                      <SelectItem value="CNAME">Registro CNAME</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sslEnabled">Habilitar SSL</Label>
                    <p className="text-sm text-muted-foreground">
                      Usar HTTPS com certificado gratuito Let's Encrypt
                    </p>
                  </div>
                  <Switch
                    id="sslEnabled"
                    checked={formValues.sslEnabled}
                    onCheckedChange={(checked) => handleSwitchChange("sslEnabled", checked)}
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createDnsRecordMutation.isPending}
                  >
                    {createDnsRecordMutation.isPending && (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    )}
                    Adicionar Domínio
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Domínios Configurados</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingDnsRecords || !selectedWebsiteId ? (
              <div className="flex flex-col items-center justify-center py-10">
                {!selectedWebsiteId ? (
                  <p className="text-muted-foreground">
                    Selecione um site para visualizar seus domínios
                  </p>
                ) : (
                  <>
                    <Loader2 className="w-8 h-8 animate-spin mb-2 text-primary" />
                    <p className="text-muted-foreground">Carregando registros DNS...</p>
                  </>
                )}
              </div>
            ) : (dnsRecords && dnsRecords.length > 0) ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableCaption>
                    Lista de domínios configurados para este site
                  </TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Domínio</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>SSL</TableHead>
                      <TableHead>Última Verificação</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dnsRecords && dnsRecords.map((record: DnsRecord) => (
                      <TableRow key={record.id}>
                        <TableCell className="font-medium">{record.domain}</TableCell>
                        <TableCell>{record.recordType}</TableCell>
                        <TableCell>{getStatusBadge(record.status)}</TableCell>
                        <TableCell>
                          {record.sslEnabled ? (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger>
                                  <div className="flex items-center text-green-600">
                                    <Lock className="w-4 h-4 mr-1" />
                                    <span>Ativo</span>
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Certificado SSL ativo</p>
                                  {record.sslCertExpiry && (
                                    <p>Expira em: {formatDate(record.sslCertExpiry)}</p>
                                  )}
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          ) : (
                            <span className="text-muted-foreground">Inativo</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {formatDate(record.lastChecked)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    size="icon" 
                                    variant="ghost"
                                    onClick={() => {
                                      navigator.clipboard.writeText(getInstructions(record));
                                      toast({
                                        title: "Instruções copiadas",
                                        description: "As instruções foram copiadas para a área de transferência.",
                                      });
                                    }}
                                  >
                                    <Copy className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Copiar instruções de configuração</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>

                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    size="icon" 
                                    variant="ghost"
                                    disabled={verifyingDomainId === record.id}
                                    onClick={() => {
                                      setVerifyingDomainId(record.id);
                                      verifyDnsRecordMutation.mutate(record.id);
                                    }}
                                  >
                                    {verifyingDomainId === record.id ? (
                                      <Loader2 className="w-4 h-4 animate-spin" />
                                    ) : (
                                      <RefreshCw className="w-4 h-4" />
                                    )}
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Verificar registro DNS</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>

                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="text-blue-500 hover:text-blue-700 hover:bg-blue-100"
                                    onClick={() => {
                                      setSelectedDnsRecord(record);
                                      setIsTraefikConfigOpen(true);
                                    }}
                                  >
                                    <Network className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Configurar Traefik</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>

                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="text-red-500 hover:text-red-700 hover:bg-red-100"
                                    onClick={() => {
                                      if (confirm(`Tem certeza que deseja remover o domínio ${record.domain}?`)) {
                                        deleteDnsRecordMutation.mutate(record.id);
                                      }
                                    }}
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Remover domínio</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>

                            {record.status === "verified" && (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="text-primary"
                                      onClick={() => {
                                        window.open(`https://${record.domain}`, "_blank");
                                      }}
                                    >
                                      <ExternalLink className="w-4 h-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Visitar site</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10">
                <p className="text-muted-foreground text-center">
                  Nenhum domínio configurado para este site.<br />
                  Clique em "Adicionar Domínio" para começar.
                </p>
              </div>
            )}
          </CardContent>
          {dnsRecords && dnsRecords.length > 0 && (
            <CardFooter>
              <div className="text-sm text-muted-foreground">
                <p>
                  <strong>Instruções de Configuração:</strong>
                </p>
                <p>
                  Para registros A: Configure seu domínio para apontar para o IP 64.27.18.219<br />
                  Para registros CNAME: Configure seu domínio para apontar para platform-example.com
                </p>
              </div>
            </CardFooter>
          )}
        </Card>
      </div>

      {/* Dialog de configuração Traefik */}
      <Dialog open={isTraefikConfigOpen} onOpenChange={setIsTraefikConfigOpen}>
        <DialogContent className="sm:max-w-[900px]">
          <DialogHeader>
            <DialogTitle>Configuração Traefik</DialogTitle>
            <DialogDescription>
              Configure as opções de integração Traefik para este domínio
            </DialogDescription>
          </DialogHeader>
          
          {selectedDnsRecord && (
            <TraefikConfig 
              dnsRecord={selectedDnsRecord} 
              onSave={(config) => {
                updateTraefikConfigMutation.mutate({
                  id: selectedDnsRecord.id,
                  config
                });
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}