import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Activity, Website } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

export default function Deployments() {
  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ['/api/activities'],
  });
  
  const { data: websites, isLoading: websitesLoading } = useQuery({
    queryKey: ['/api/websites'],
  });

  const deployments = activities?.filter((activity: Activity) => 
    activity.type === "deploy"
  ) || [];

  const isLoading = activitiesLoading || websitesLoading;

  return (
    <>
      <Header 
        title="Implantações" 
        actions={
          <Button 
            size="sm"
            className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
          >
            <i className="ri-rocket-line mr-1.5"></i>
            Implantar
          </Button>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Histórico de Implantações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                  <tr>
                    <th scope="col" className="px-6 py-3">Site</th>
                    <th scope="col" className="px-6 py-3">Status</th>
                    <th scope="col" className="px-6 py-3">Implantado</th>
                    <th scope="col" className="px-6 py-3">Ambiente</th>
                    <th scope="col" className="px-6 py-3">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    Array(5).fill(0).map((_, i) => (
                      <tr key={i} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
                        <td className="px-6 py-4"><Skeleton className="h-4 w-16" /></td>
                        <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
                        <td className="px-6 py-4"><Skeleton className="h-4 w-16" /></td>
                        <td className="px-6 py-4"><Skeleton className="h-8 w-20" /></td>
                      </tr>
                    ))
                  ) : deployments.length === 0 ? (
                    <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                      <td colSpan={5} className="px-6 py-8 text-center">
                        <p className="text-gray-500 dark:text-gray-400">Nenhuma implantação encontrada</p>
                      </td>
                    </tr>
                  ) : (
                    deployments.map((deployment: Activity) => {
                      const website = websites?.find((site: Website) => site.id === deployment.entityId);
                      return (
                        <tr key={deployment.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                          <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                            {website?.name || 'Site Desconhecido'}
                          </td>
                          <td className="px-6 py-4">
                            <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                              Sucesso
                            </Badge>
                          </td>
                          <td className="px-6 py-4">
                            {formatDistanceToNow(new Date(deployment.timestamp), { addSuffix: true })}
                          </td>
                          <td className="px-6 py-4">Produção</td>
                          <td className="px-6 py-4">
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                Logs
                              </Button>
                              <Button variant="outline" size="sm">
                                Reverter
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Implantação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">Implantação Automática</div>
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    Ativado
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">Destino da Implantação</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Produção</div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">Cache de Build</div>
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    Ativado
                  </Badge>
                </div>
                <div className="mt-4">
                  <Button variant="outline" className="w-full">
                    Configurar Ajustes
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Ambientes Ativos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 rounded-lg border border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-900/20">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium text-gray-900 dark:text-white">Produção</div>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      Ativo
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                    <span className="flex items-center">
                      <i className="ri-global-line mr-2"></i>
                      <a href="https://example.com" className="hover:underline" target="_blank" rel="noopener noreferrer">https://example.com</a>
                    </span>
                  </div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white mb-1">Última Implantação</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Página Inicial da Empresa, 2 horas atrás
                  </div>
                </div>
                
                <div className="p-4 rounded-lg border border-amber-200 dark:border-amber-900 bg-amber-50 dark:bg-amber-900/20">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium text-gray-900 dark:text-white">Homologação</div>
                    <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                      Teste
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                    <span className="flex items-center">
                      <i className="ri-global-line mr-2"></i>
                      <a href="https://staging.example.com" className="hover:underline" target="_blank" rel="noopener noreferrer">https://staging.example.com</a>
                    </span>
                  </div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white mb-1">Última Implantação</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Loja E-commerce, 1 dia atrás
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}
