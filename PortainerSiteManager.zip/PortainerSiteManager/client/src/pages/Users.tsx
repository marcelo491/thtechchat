import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { PlusIcon } from "lucide-react";

export default function Users() {
  const users = [
    { id: 1, name: "Admin User", email: "admin@example.com", role: "Admin", status: "Active" },
    { id: 2, name: "John Smith", email: "john@example.com", role: "Editor", status: "Active" },
    { id: 3, name: "Jane Doe", email: "jane@example.com", role: "Viewer", status: "Inactive" }
  ];

  return (
    <>
      <Header 
        title="Users" 
        actions={
          <Button 
            size="sm"
            className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
          >
            <PlusIcon className="h-4 w-4 mr-1.5" />
            Add User
          </Button>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>User Management</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                  <tr>
                    <th scope="col" className="px-6 py-3">Name</th>
                    <th scope="col" className="px-6 py-3">Email</th>
                    <th scope="col" className="px-6 py-3">Role</th>
                    <th scope="col" className="px-6 py-3">Status</th>
                    <th scope="col" className="px-6 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                      <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                        <div className="flex items-center">
                          <Avatar className="h-8 w-8 mr-3">
                            <AvatarFallback className="bg-primary-700 text-white text-sm">
                              {user.name.split(" ").map(n => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          {user.name}
                        </div>
                      </td>
                      <td className="px-6 py-4">{user.email}</td>
                      <td className="px-6 py-4">
                        <Badge variant="outline" className={
                          user.role === "Admin" ? "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" :
                          user.role === "Editor" ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" :
                          "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                        }>
                          {user.role}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <Badge className={
                          user.status === "Active" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" :
                          "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                        }>
                          {user.status}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                          {user.id !== 1 && (
                            <Button variant="outline" size="sm" className="text-red-500 hover:text-red-600 border-red-200 hover:border-red-300 dark:border-red-800 dark:hover:border-red-700">
                              Delete
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Roles & Permissions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 rounded-lg border border-purple-200 dark:border-purple-900 bg-purple-50 dark:bg-purple-900/20">
                  <div className="font-medium text-gray-900 dark:text-white mb-2">Admin</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Full access to all features, can manage users and settings.
                  </div>
                </div>
                
                <div className="p-4 rounded-lg border border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-900/20">
                  <div className="font-medium text-gray-900 dark:text-white mb-2">Editor</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Can create and edit websites, templates, and components.
                  </div>
                </div>
                
                <div className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/20">
                  <div className="font-medium text-gray-900 dark:text-white mb-2">Viewer</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Read-only access to websites and analytics.
                  </div>
                </div>
                
                <div className="mt-4">
                  <Button variant="outline" className="w-full">
                    Manage Roles
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Avatar className="h-8 w-8 mr-3 mt-1">
                    <AvatarFallback className="bg-primary-700 text-white text-sm">
                      A
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900 dark:text-white">Admin User</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">updated website settings</span>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">2 hours ago</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Avatar className="h-8 w-8 mr-3 mt-1">
                    <AvatarFallback className="bg-blue-700 text-white text-sm">
                      JS
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900 dark:text-white">John Smith</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">created a new website</span>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">1 day ago</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Avatar className="h-8 w-8 mr-3 mt-1">
                    <AvatarFallback className="bg-green-700 text-white text-sm">
                      A
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900 dark:text-white">Admin User</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">added John Smith as Editor</span>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">2 days ago</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Avatar className="h-8 w-8 mr-3 mt-1">
                    <AvatarFallback className="bg-primary-700 text-white text-sm">
                      A
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900 dark:text-white">Admin User</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">deployed Company Homepage to production</span>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">3 days ago</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}
