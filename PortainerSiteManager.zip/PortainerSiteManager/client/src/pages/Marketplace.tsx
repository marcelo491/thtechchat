import { useState } from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';

interface MarketplaceItem {
  id: string;
  name: string;
  description: string;
  type: 'template' | 'plugin' | 'theme';
  author: string;
  rating: number;
  downloads: number;
  price: number | 'free';
  tags: string[];
  imageUrl: string;
  version: string;
  lastUpdated: string;
}

export default function Marketplace() {
  const [isLoading, setIsLoading] = useState(false);
  const [marketplaceItems, setMarketplaceItems] = useState<MarketplaceItem[]>([
    {
      id: 'item1',
      name: 'Modern Business',
      description: 'Template completo para negócios com múltiplas páginas e elementos interativos',
      type: 'template',
      author: 'SiteBuilder Team',
      rating: 4.8,
      downloads: 3240,
      price: 'free',
      tags: ['negócios', 'responsivo', 'moderno'],
      imageUrl: 'https://placehold.co/600x400/2a52be/white?text=Modern+Business',
      version: '1.2.1',
      lastUpdated: '2023-01-04'
    },
    {
      id: 'item2',
      name: 'E-commerce Pro',
      description: 'Template completo para lojas online com funcionalidades avançadas de e-commerce',
      type: 'template',
      author: 'Commerce Solutions',
      rating: 4.7,
      downloads: 1850,
      price: 49.99,
      tags: ['e-commerce', 'loja', 'responsivo'],
      imageUrl: 'https://placehold.co/600x400/831843/white?text=E-commerce+Pro',
      version: '2.0.5',
      lastUpdated: '2023-01-10'
    },
    {
      id: 'item3',
      name: 'Blog Studio',
      description: 'Template elegante para blogs com várias opções de layout e estilos',
      type: 'template',
      author: 'Creative Publishing',
      rating: 4.5,
      downloads: 2120,
      price: 'free',
      tags: ['blog', 'publicação', 'minimalista'],
      imageUrl: 'https://placehold.co/600x400/10b981/white?text=Blog+Studio',
      version: '1.1.2',
      lastUpdated: '2022-12-18'
    },
    {
      id: 'item4',
      name: 'SEO Booster',
      description: 'Plugin para otimização de SEO com análise em tempo real e sugestões',
      type: 'plugin',
      author: 'SearchPro',
      rating: 4.6,
      downloads: 5670,
      price: 29.99,
      tags: ['seo', 'performance', 'análise'],
      imageUrl: 'https://placehold.co/600x400/f59e0b/white?text=SEO+Booster',
      version: '3.2.1',
      lastUpdated: '2023-01-15'
    },
    {
      id: 'item5',
      name: 'Contact Form Pro',
      description: 'Sistema avançado de formulários de contato com integrações diversas',
      type: 'plugin',
      author: 'FormWorks',
      rating: 4.9,
      downloads: 7890,
      price: 'free',
      tags: ['formulário', 'contato', 'integração'],
      imageUrl: 'https://placehold.co/600x400/6366f1/white?text=Contact+Form+Pro',
      version: '2.4.3',
      lastUpdated: '2023-01-12'
    },
    {
      id: 'item6',
      name: 'Dark Mode Pro',
      description: 'Theme switcher avançado com personalização detalhada de cores e estilos',
      type: 'theme',
      author: 'UI Masters',
      rating: 4.7,
      downloads: 3450,
      price: 19.99,
      tags: ['ui', 'dark mode', 'acessibilidade'],
      imageUrl: 'https://placehold.co/600x400/1e293b/white?text=Dark+Mode+Pro',
      version: '1.5.0',
      lastUpdated: '2023-01-08'
    },
    {
      id: 'item7',
      name: 'Analytics Dashboard',
      description: 'Plugin para dashboard de analytics com visualizações avançadas e relatórios',
      type: 'plugin',
      author: 'DataViz Solutions',
      rating: 4.8,
      downloads: 2130,
      price: 39.99,
      tags: ['análise', 'dashboard', 'relatórios'],
      imageUrl: 'https://placehold.co/600x400/8b5cf6/white?text=Analytics+Dashboard',
      version: '2.1.0',
      lastUpdated: '2023-01-05'
    },
    {
      id: 'item8',
      name: 'Portfolio Minimalista',
      description: 'Template elegante para portfólios com design minimalista e foco em imagens',
      type: 'template',
      author: 'Design Studio X',
      rating: 4.6,
      downloads: 1970,
      price: 'free',
      tags: ['portfólio', 'minimalista', 'criativo'],
      imageUrl: 'https://placehold.co/600x400/0f172a/white?text=Portfolio+Minimalista',
      version: '1.3.2',
      lastUpdated: '2022-12-22'
    }
  ]);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [selectedItem, setSelectedItem] = useState<MarketplaceItem | null>(null);
  const [itemDetailsOpen, setItemDetailsOpen] = useState(false);
  const [installProgress, setInstallProgress] = useState(0);
  const [installing, setInstalling] = useState(false);
  
  const filteredItems = marketplaceItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesFilter = activeFilter === 'all' || 
                         (activeFilter === 'free' && item.price === 'free') ||
                         (activeFilter === 'paid' && item.price !== 'free') ||
                         (activeFilter === item.type);
    
    return matchesSearch && matchesFilter;
  });
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };
  
  const handleInstall = (item: MarketplaceItem) => {
    setInstalling(true);
    setInstallProgress(0);
    
    // Simulação da instalação com progresso
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setInstallProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setInstalling(false);
          setItemDetailsOpen(false);
        }, 500);
      }
    }, 300);
  };

  return (
    <>
      <Header 
        title="Marketplace" 
        actions={
          <div className="flex space-x-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Buscar templates, plugins..."
                className="w-[300px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <i className="ri-search-line text-gray-400"></i>
              </div>
            </div>
            <Button 
              size="sm"
              variant="outline"
            >
              <i className="ri-upload-line mr-1.5"></i>
              Publicar
            </Button>
          </div>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="all" className="space-y-8" onValueChange={setActiveFilter}>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <TabsList className="grid grid-cols-3 sm:grid-cols-7">
              <TabsTrigger value="all">Todos</TabsTrigger>
              <TabsTrigger value="template">Templates</TabsTrigger>
              <TabsTrigger value="plugin">Plugins</TabsTrigger>
              <TabsTrigger value="theme">Temas</TabsTrigger>
              <TabsTrigger value="free">Gratuitos</TabsTrigger>
              <TabsTrigger value="paid">Premium</TabsTrigger>
              <TabsTrigger value="installed">Instalados</TabsTrigger>
            </TabsList>
            
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm" className="text-sm">
                <i className="ri-award-line mr-1.5"></i>
                Populares
              </Button>
              <Button variant="ghost" size="sm" className="text-sm">
                <i className="ri-calendar-line mr-1.5"></i>
                Mais Recentes
              </Button>
              <Button variant="ghost" size="sm" className="text-sm">
                <i className="ri-star-line mr-1.5"></i>
                Melhor Avaliados
              </Button>
            </div>
          </div>
          
          <TabsContent value="all" className="m-0">
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {Array(8).fill(0).map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <Skeleton className="h-48 w-full" />
                    <CardHeader className="p-4 pb-0">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3 mt-1" />
                    </CardHeader>
                    <CardFooter className="p-4 pt-2">
                      <Skeleton className="h-9 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : filteredItems.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-4">😢</div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Nenhum resultado encontrado</h3>
                <p className="text-gray-500 dark:text-gray-400">Tente mudar seus termos de busca ou filtros</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredItems.map((item) => (
                  <Card key={item.id} className="overflow-hidden">
                    <div className="relative h-48 w-full overflow-hidden bg-gray-100 dark:bg-gray-800">
                      <img 
                        src={item.imageUrl} 
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                      />
                      <div className="absolute top-3 right-3">
                        {item.price === 'free' ? (
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            Gratuito
                          </Badge>
                        ) : (
                          <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                            R$ {typeof item.price === 'number' ? item.price.toFixed(2) : '0,00'}
                          </Badge>
                        )}
                      </div>
                      <div className="absolute top-3 left-3">
                        <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200 capitalize">
                          {item.type === 'template' ? 'Template' : 
                           item.type === 'plugin' ? 'Plugin' : 'Tema'}
                        </Badge>
                      </div>
                    </div>
                    <CardHeader className="p-4 pb-0">
                      <CardTitle className="text-lg">{item.name}</CardTitle>
                      <CardDescription className="line-clamp-2">{item.description}</CardDescription>
                      <div className="flex items-center mt-2 space-x-1 text-sm">
                        <i className="ri-star-fill text-amber-500"></i>
                        <span className="font-medium">{item.rating.toFixed(1)}</span>
                        <span className="text-gray-400 dark:text-gray-500">•</span>
                        <span className="text-gray-500 dark:text-gray-400">{item.downloads.toLocaleString()} downloads</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {item.tags.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs font-normal capitalize">
                            {tag}
                          </Badge>
                        ))}
                        {item.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs font-normal">
                            +{item.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardFooter className="p-4 pt-3 flex justify-between items-center">
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        v{item.version} • {formatDate(item.lastUpdated)}
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => {
                          setSelectedItem(item);
                          setItemDetailsOpen(true);
                        }}
                      >
                        Ver Detalhes
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          {/* Repetimos o mesmo conteúdo para as outras tabs, apenas mantendo activeFilter diferente */}
          <TabsContent value="template" className="m-0">
            {/* Mesmo conteúdo do value="all" */}
            {filteredItems.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-4">😢</div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Nenhum resultado encontrado</h3>
                <p className="text-gray-500 dark:text-gray-400">Tente mudar seus termos de busca ou filtros</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Mesmo mapeamento de filteredItems */}
                {filteredItems.map((item) => (
                  <Card key={item.id} className="overflow-hidden">
                    {/* Conteúdo do card (mesmo do value="all") */}
                    <div className="relative h-48 w-full overflow-hidden bg-gray-100 dark:bg-gray-800">
                      <img 
                        src={item.imageUrl} 
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                      />
                      <div className="absolute top-3 right-3">
                        {item.price === 'free' ? (
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            Gratuito
                          </Badge>
                        ) : (
                          <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                            R$ {typeof item.price === 'number' ? item.price.toFixed(2) : '0,00'}
                          </Badge>
                        )}
                      </div>
                      <div className="absolute top-3 left-3">
                        <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200 capitalize">
                          {item.type === 'template' ? 'Template' : 
                           item.type === 'plugin' ? 'Plugin' : 'Tema'}
                        </Badge>
                      </div>
                    </div>
                    <CardHeader className="p-4 pb-0">
                      <CardTitle className="text-lg">{item.name}</CardTitle>
                      <CardDescription className="line-clamp-2">{item.description}</CardDescription>
                      <div className="flex items-center mt-2 space-x-1 text-sm">
                        <i className="ri-star-fill text-amber-500"></i>
                        <span className="font-medium">{item.rating.toFixed(1)}</span>
                        <span className="text-gray-400 dark:text-gray-500">•</span>
                        <span className="text-gray-500 dark:text-gray-400">{item.downloads.toLocaleString()} downloads</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {item.tags.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs font-normal capitalize">
                            {tag}
                          </Badge>
                        ))}
                        {item.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs font-normal">
                            +{item.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardFooter className="p-4 pt-3 flex justify-between items-center">
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        v{item.version} • {formatDate(item.lastUpdated)}
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => {
                          setSelectedItem(item);
                          setItemDetailsOpen(true);
                        }}
                      >
                        Ver Detalhes
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          {/* O mesmo padrão se repete para as outras abas */}
          <TabsContent value="plugin" className="m-0">
            {/* Conteúdo igual aos anteriores */}
          </TabsContent>
          
          <TabsContent value="theme" className="m-0">
            {/* Conteúdo igual aos anteriores */}
          </TabsContent>
          
          <TabsContent value="free" className="m-0">
            {/* Conteúdo igual aos anteriores */}
          </TabsContent>
          
          <TabsContent value="paid" className="m-0">
            {/* Conteúdo igual aos anteriores */}
          </TabsContent>
          
          <TabsContent value="installed" className="m-0">
            {/* Este exibiria itens instalados, mas para simplificar, mostramos uma mensagem */}
            <div className="text-center py-12">
              <div className="text-5xl mb-4">📦</div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Nenhum item instalado</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Comece a explorar o marketplace para instalar templates, plugins e temas</p>
              <Button onClick={() => setActiveFilter('all')}>Explorar Marketplace</Button>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      
      <Dialog open={itemDetailsOpen} onOpenChange={setItemDetailsOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>{selectedItem?.name}</DialogTitle>
            <DialogDescription>
              {selectedItem?.type === 'template' ? 'Template' : 
               selectedItem?.type === 'plugin' ? 'Plugin' : 'Tema'} por {selectedItem?.author}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="rounded-lg overflow-hidden">
                <img 
                  src={selectedItem?.imageUrl} 
                  alt={selectedItem?.name}
                  className="w-full h-auto object-cover"
                />
              </div>
              
              <div className="mt-4 flex flex-wrap gap-2">
                {selectedItem?.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="capitalize">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Descrição</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  {selectedItem?.description}
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Versão:</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">v{selectedItem?.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Última atualização:</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">{selectedItem && formatDate(selectedItem.lastUpdated)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Downloads:</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">{selectedItem?.downloads.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Avaliação:</span>
                  <span className="text-sm flex items-center">
                    <i className="ri-star-fill text-amber-500 mr-1"></i>
                    {selectedItem?.rating.toFixed(1)}/5.0
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Preço:</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {selectedItem?.price === 'free' ? 'Gratuito' : `R$ ${typeof selectedItem?.price === 'number' ? selectedItem?.price.toFixed(2) : '0,00'}`}
                  </span>
                </div>
              </div>
              
              <div className="pt-4 space-y-4">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">Avaliações dos Usuários</h3>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="text-xs font-medium">JC</span>
                    </div>
                    <div>
                      <div className="flex items-center mb-1">
                        <h4 className="text-sm font-medium text-gray-900 dark:text-white mr-2">João Carlos</h4>
                        <div className="flex items-center text-amber-500">
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Excelente template, muito fácil de personalizar e com ótima documentação.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="text-xs font-medium">MA</span>
                    </div>
                    <div>
                      <div className="flex items-center mb-1">
                        <h4 className="text-sm font-medium text-gray-900 dark:text-white mr-2">Maria Almeida</h4>
                        <div className="flex items-center text-amber-500">
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-fill text-xs"></i>
                          <i className="ri-star-line text-xs"></i>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Muito bom, mas poderia ter mais opções de personalização de cores.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {installing ? (
            <div className="space-y-4 py-4">
              <p className="text-sm text-gray-700 dark:text-gray-300">Instalando {selectedItem?.name}...</p>
              <Progress value={installProgress} className="w-full" />
              <p className="text-xs text-gray-500 dark:text-gray-400">{installProgress}% concluído</p>
            </div>
          ) : (
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setItemDetailsOpen(false)}
              >
                Cancelar
              </Button>
              <Button 
                onClick={() => selectedItem && handleInstall(selectedItem)}
              >
                {selectedItem?.price === 'free' ? 'Instalar' : 'Comprar e Instalar'}
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}