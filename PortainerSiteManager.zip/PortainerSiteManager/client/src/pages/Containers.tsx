import { useState } from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

interface Container {
  id: string;
  name: string;
  image: string;
  status: 'running' | 'stopped' | 'paused';
  cpu: number;
  memory: number;
  created: string;
  ports: string[];
}

export default function Containers() {
  const [isLoading, setIsLoading] = useState(false);
  const [containers, setContainers] = useState<Container[]>([
    {
      id: 'c1',
      name: 'site-builder-app',
      image: 'node:16',
      status: 'running',
      cpu: 2.4,
      memory: 35,
      created: '2023-10-15T14:48:00',
      ports: ['5000:5000']
    },
    {
      id: 'c2',
      name: 'site-builder-postgres',
      image: 'postgres:14',
      status: 'running',
      cpu: 0.8,
      memory: 22,
      created: '2023-10-15T14:48:00',
      ports: ['5432:5432']
    },
    {
      id: 'c3',
      name: 'site-builder-redis',
      image: 'redis:alpine',
      status: 'running',
      cpu: 0.3,
      memory: 12,
      created: '2023-10-15T14:48:00',
      ports: ['6379:6379']
    },
    {
      id: 'c4',
      name: 'site-builder-nginx',
      image: 'nginx:latest',
      status: 'stopped',
      cpu: 0,
      memory: 0,
      created: '2023-10-15T14:48:00',
      ports: ['80:80', '443:443']
    }
  ]);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'running':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Em Execução</Badge>;
      case 'stopped':
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Parado</Badge>;
      case 'paused':
        return <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">Pausado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200">Desconhecido</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleContainerAction = (id: string, action: 'start' | 'stop' | 'restart' | 'remove') => {
    // Na implementação real, aqui seria feita uma chamada API para o backend
    console.log(`Container ${id}: ${action}`);
    
    // Simulação de atualização do estado
    if (action === 'stop') {
      setContainers(containers.map(c => 
        c.id === id ? {...c, status: 'stopped', cpu: 0, memory: 0} : c
      ));
    } else if (action === 'start') {
      setContainers(containers.map(c => 
        c.id === id ? {...c, status: 'running', cpu: Math.random() * 3, memory: Math.random() * 40 + 10} : c
      ));
    }
  };

  return (
    <>
      <Header 
        title="Contêineres" 
        actions={
          <Button 
            size="sm"
            className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
          >
            <i className="ri-add-line mr-1.5"></i>
            Novo Contêiner
          </Button>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="containers" className="space-y-8">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="containers">Contêineres</TabsTrigger>
            <TabsTrigger value="images">Imagens</TabsTrigger>
            <TabsTrigger value="volumes">Volumes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="containers">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Contêineres Docker</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Nome</th>
                        <th scope="col" className="px-6 py-3">Imagem</th>
                        <th scope="col" className="px-6 py-3">Status</th>
                        <th scope="col" className="px-6 py-3">CPU</th>
                        <th scope="col" className="px-6 py-3">Memória</th>
                        <th scope="col" className="px-6 py-3">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoading ? (
                        Array(4).fill(0).map((_, i) => (
                          <tr key={i} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
                            <td className="px-6 py-4"><Skeleton className="h-4 w-16" /></td>
                            <td className="px-6 py-4"><Skeleton className="h-4 w-16" /></td>
                            <td className="px-6 py-4"><Skeleton className="h-4 w-12" /></td>
                            <td className="px-6 py-4"><Skeleton className="h-4 w-12" /></td>
                            <td className="px-6 py-4"><Skeleton className="h-8 w-20" /></td>
                          </tr>
                        ))
                      ) : (
                        containers.map((container) => (
                          <tr key={container.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                              {container.name}
                            </td>
                            <td className="px-6 py-4">
                              {container.image}
                            </td>
                            <td className="px-6 py-4">
                              {getStatusBadge(container.status)}
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center space-x-2">
                                <Progress value={container.cpu * 10} className="w-16" />
                                <span>{container.cpu.toFixed(1)}%</span>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center space-x-2">
                                <Progress value={container.memory} className="w-16" />
                                <span>{container.memory.toFixed(0)}%</span>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex space-x-2">
                                {container.status === 'running' ? (
                                  <Button variant="outline" size="sm" onClick={() => handleContainerAction(container.id, 'stop')}>
                                    Parar
                                  </Button>
                                ) : (
                                  <Button variant="outline" size="sm" onClick={() => handleContainerAction(container.id, 'start')}>
                                    Iniciar
                                  </Button>
                                )}
                                <Button variant="outline" size="sm" onClick={() => handleContainerAction(container.id, 'restart')}>
                                  Reiniciar
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Detalhes do Contêiner</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">ID do Contêiner</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">c1298alskd9812l3k4n5lk345n</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Criado em</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">15/10/2023 14:48</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Imagem</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">node:16 (sha256:a918b9d)</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Portas</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">5000:5000</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Volumes</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">/app:/data</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Redes</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">site-builder-network</p>
                    </div>
                    <div className="mt-4">
                      <Button variant="outline" className="w-full">
                        Ver Logs
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Recursos do Sistema</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">CPU</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">3.5%</p>
                      </div>
                      <Progress value={3.5} className="w-full" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Memória</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">68% (1.7GB / 2.5GB)</p>
                      </div>
                      <Progress value={68} className="w-full" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Disco</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">35% (17.5GB / 50GB)</p>
                      </div>
                      <Progress value={35} className="w-full" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Rede</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">1.2MB/s ↓ 256KB/s ↑</p>
                      </div>
                      <Progress value={25} className="w-full" />
                    </div>
                    
                    <div className="mt-4">
                      <Button variant="outline" className="w-full">
                        Ver Estatísticas Detalhadas
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="images">
            <Card>
              <CardHeader>
                <CardTitle>Imagens Docker</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Repositório</th>
                        <th scope="col" className="px-6 py-3">Tag</th>
                        <th scope="col" className="px-6 py-3">ID da Imagem</th>
                        <th scope="col" className="px-6 py-3">Criado</th>
                        <th scope="col" className="px-6 py-3">Tamanho</th>
                        <th scope="col" className="px-6 py-3">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          node
                        </td>
                        <td className="px-6 py-4">16</td>
                        <td className="px-6 py-4">a918b9d123ab</td>
                        <td className="px-6 py-4">2 semanas atrás</td>
                        <td className="px-6 py-4">942MB</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          postgres
                        </td>
                        <td className="px-6 py-4">14</td>
                        <td className="px-6 py-4">5432abde9871</td>
                        <td className="px-6 py-4">2 semanas atrás</td>
                        <td className="px-6 py-4">376MB</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          redis
                        </td>
                        <td className="px-6 py-4">alpine</td>
                        <td className="px-6 py-4">c6379ebf56de</td>
                        <td className="px-6 py-4">3 semanas atrás</td>
                        <td className="px-6 py-4">32MB</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          nginx
                        </td>
                        <td className="px-6 py-4">latest</td>
                        <td className="px-6 py-4">8080aecfe210</td>
                        <td className="px-6 py-4">1 mês atrás</td>
                        <td className="px-6 py-4">142MB</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="volumes">
            <Card>
              <CardHeader>
                <CardTitle>Volumes Docker</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Nome</th>
                        <th scope="col" className="px-6 py-3">Tipo</th>
                        <th scope="col" className="px-6 py-3">Driver</th>
                        <th scope="col" className="px-6 py-3">Montagens</th>
                        <th scope="col" className="px-6 py-3">Criado</th>
                        <th scope="col" className="px-6 py-3">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          site-builder-data
                        </td>
                        <td className="px-6 py-4">local</td>
                        <td className="px-6 py-4">local</td>
                        <td className="px-6 py-4">site-builder-app:/data</td>
                        <td className="px-6 py-4">2 semanas atrás</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Backup
                            </Button>
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          postgres-data
                        </td>
                        <td className="px-6 py-4">local</td>
                        <td className="px-6 py-4">local</td>
                        <td className="px-6 py-4">site-builder-postgres:/var/lib/postgresql/data</td>
                        <td className="px-6 py-4">2 semanas atrás</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Backup
                            </Button>
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                          redis-data
                        </td>
                        <td className="px-6 py-4">local</td>
                        <td className="px-6 py-4">local</td>
                        <td className="px-6 py-4">site-builder-redis:/data</td>
                        <td className="px-6 py-4">2 semanas atrás</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              Backup
                            </Button>
                            <Button variant="outline" size="sm">
                              Remover
                            </Button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </>
  );
}