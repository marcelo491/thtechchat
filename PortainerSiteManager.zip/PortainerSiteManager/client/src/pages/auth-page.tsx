import { useState, useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { THLogo } from "@/assets/logo.tsx";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Loader2 } from "lucide-react";

// Definição dos schemas de validação
const loginSchema = z.object({
  username: z.string().min(3, "Nome de usuário deve ter pelo menos 3 caracteres"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Nome de usuário deve ter pelo menos 3 caracteres"),
  email: z.string().email("E-mail inválido"),
  fullName: z.string().min(2, "Nome completo é obrigatório"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  confirmPassword: z.string().min(6, "Confirme sua senha"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function AuthPage() {
  const { user, loginMutation } = useAuth();
  
  // Redirecionar se já estiver autenticado
  useEffect(() => {
    if (user) {
      window.location.href = "/";
    }
  }, [user]);

  // Formulário de login
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Manipulador de submit
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  return (
    <div className="flex h-screen">
      {/* Formulário - Lado Esquerdo */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-gray-50 dark:bg-gray-900">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center p-1 shadow-md">
                <THLogo width={56} height={56} />
              </div>
            </div>
            <h1 className="text-2xl font-bold mb-1 text-gray-900 dark:text-white">THTech Web Studio</h1>
            <p className="text-gray-600 dark:text-gray-400">Entre para gerenciar seus sites e contêineres</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Login</CardTitle>
              <CardDescription>
                Entre com suas credenciais para acessar sua conta.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome de usuário</FormLabel>
                        <FormControl>
                          <Input placeholder="Seu nome de usuário" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Senha</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Sua senha" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
                    {loginMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Entrando...
                      </>
                    ) : (
                      "Entrar"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-gray-500">
                Novos usuários só podem ser criados por um administrador.
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>

      {/* Seção Hero - Lado Direito */}
      <div className="hidden lg:block lg:w-1/2 bg-primary-600 text-white p-12">
        <div className="h-full flex flex-col items-center justify-center">
          <div className="max-w-md text-center">
            <h2 className="text-3xl font-bold mb-6">Gerencie seus sites com facilidade</h2>
            <p className="text-xl mb-8">
              Plataforma completa para administração e infraestrutura web com integração Docker e Portainer.
            </p>
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="p-4 rounded-lg bg-primary-700 bg-opacity-50">
                <i className="ri-global-line text-3xl mb-2"></i>
                <h3 className="text-lg font-semibold mb-1">Gestão de Sites</h3>
                <p className="text-sm">Controle múltiplos websites e domínios em uma única interface.</p>
              </div>
              <div className="p-4 rounded-lg bg-primary-700 bg-opacity-50">
                <i className="ri-server-line text-3xl mb-2"></i>
                <h3 className="text-lg font-semibold mb-1">Infraestrutura</h3>
                <p className="text-sm">Gerencie contêineres Docker com integração Portainer nativa.</p>
              </div>
              <div className="p-4 rounded-lg bg-primary-700 bg-opacity-50">
                <i className="ri-database-2-line text-3xl mb-2"></i>
                <h3 className="text-lg font-semibold mb-1">Backups</h3>
                <p className="text-sm">Backup automático de seus sites e dados, com restauração fácil.</p>
              </div>
              <div className="p-4 rounded-lg bg-primary-700 bg-opacity-50">
                <i className="ri-global-fill text-3xl mb-2"></i>
                <h3 className="text-lg font-semibold mb-1">Gestão DNS</h3>
                <p className="text-sm">Configure e gerencie domínios, SSL e DNS em um único lugar.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}