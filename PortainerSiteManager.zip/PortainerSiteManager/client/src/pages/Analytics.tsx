import { useState } from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, BarChart, AreaChart, ResponsiveContainer, XAxis, YAxis, Line, Bar, Area, Tooltip, Legend, CartesianGrid } from 'recharts';

const data = [
  { name: '1 Jan', pageViews: 400, uniqueVisitors: 200, bounceRate: 40 },
  { name: '2 Jan', pageViews: 300, uniqueVisitors: 150, bounceRate: 45 },
  { name: '3 Jan', pageViews: 500, uniqueVisitors: 250, bounceRate: 35 },
  { name: '4 Jan', pageViews: 450, uniqueVisitors: 230, bounceRate: 38 },
  { name: '5 Jan', pageViews: 600, uniqueVisitors: 320, bounceRate: 30 },
  { name: '6 Jan', pageViews: 550, uniqueVisitors: 280, bounceRate: 34 },
  { name: '7 Jan', pageViews: 650, uniqueVisitors: 350, bounceRate: 28 },
  { name: '8 Jan', pageViews: 700, uniqueVisitors: 380, bounceRate: 25 },
  { name: '9 Jan', pageViews: 720, uniqueVisitors: 400, bounceRate: 22 },
  { name: '10 Jan', pageViews: 800, uniqueVisitors: 450, bounceRate: 20 },
  { name: '11 Jan', pageViews: 850, uniqueVisitors: 480, bounceRate: 18 },
  { name: '12 Jan', pageViews: 900, uniqueVisitors: 520, bounceRate: 15 },
  { name: '13 Jan', pageViews: 950, uniqueVisitors: 550, bounceRate: 14 },
  { name: '14 Jan', pageViews: 1000, uniqueVisitors: 600, bounceRate: 12 },
];

const deviceData = [
  { name: 'Desktop', value: 45 },
  { name: 'Mobile', value: 40 },
  { name: 'Tablet', value: 15 },
];

const browserData = [
  { name: 'Chrome', value: 60 },
  { name: 'Safari', value: 20 },
  { name: 'Firefox', value: 10 },
  { name: 'Edge', value: 8 },
  { name: 'Outros', value: 2 },
];

const countryData = [
  { name: 'Brasil', value: 65 },
  { name: 'EUA', value: 15 },
  { name: 'Portugal', value: 10 },
  { name: 'Espanha', value: 5 },
  { name: 'Outros', value: 5 },
];

const performanceData = [
  { name: 'company-homepage', loadTime: 1.2, firstContentfulPaint: 0.8, largestContentfulPaint: 2.3 },
  { name: 'e-commerce-store', loadTime: 2.1, firstContentfulPaint: 1.1, largestContentfulPaint: 3.5 },
  { name: 'blog-site', loadTime: 1.5, firstContentfulPaint: 0.9, largestContentfulPaint: 2.8 },
  { name: 'landing-page', loadTime: 0.9, firstContentfulPaint: 0.6, largestContentfulPaint: 1.9 },
];

export default function Analytics() {
  const [dateRange, setDateRange] = useState('14d');
  const [website, setWebsite] = useState('all');

  return (
    <>
      <Header 
        title="Análises" 
        actions={
          <div className="flex space-x-2">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Período de Tempo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Últimas 24 horas</SelectItem>
                <SelectItem value="7d">Últimos 7 dias</SelectItem>
                <SelectItem value="14d">Últimos 14 dias</SelectItem>
                <SelectItem value="30d">Últimos 30 dias</SelectItem>
                <SelectItem value="90d">Últimos 90 dias</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={website} onValueChange={setWebsite}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Selecionar Website" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os websites</SelectItem>
                <SelectItem value="company-homepage">Página da Empresa</SelectItem>
                <SelectItem value="e-commerce-store">Loja E-commerce</SelectItem>
                <SelectItem value="blog-site">Blog</SelectItem>
                <SelectItem value="landing-page">Landing Page</SelectItem>
              </SelectContent>
            </Select>
            
            <Button size="sm">Exportar Relatório</Button>
          </div>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Visualizações de Página</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">13,467</div>
              <p className="text-xs text-green-500 flex items-center mt-1">
                <i className="ri-arrow-up-line mr-1"></i>
                24% em relação ao período anterior
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Visitantes Únicos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5,832</div>
              <p className="text-xs text-green-500 flex items-center mt-1">
                <i className="ri-arrow-up-line mr-1"></i>
                18% em relação ao período anterior
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Rejeição</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">28.5%</div>
              <p className="text-xs text-red-500 flex items-center mt-1">
                <i className="ri-arrow-up-line mr-1"></i>
                3% em relação ao período anterior
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Tempo Médio no Site</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3m 42s</div>
              <p className="text-xs text-green-500 flex items-center mt-1">
                <i className="ri-arrow-up-line mr-1"></i>
                12% em relação ao período anterior
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="audience">Audiência</TabsTrigger>
            <TabsTrigger value="performance">Desempenho</TabsTrigger>
            <TabsTrigger value="behavior">Comportamento</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Visualizações de Página vs. Visitantes Únicos</CardTitle>
                <CardDescription>Tendência de visitantes e visualizações ao longo do tempo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={data}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="pageViews" stroke="#8884d8" name="Visualizações de Página" />
                      <Line type="monotone" dataKey="uniqueVisitors" stroke="#82ca9d" name="Visitantes Únicos" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Taxa de Rejeição</CardTitle>
                  <CardDescription>Porcentagem de sessões de uma única página</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={data}
                        margin={{
                          top: 10,
                          right: 30,
                          left: 0,
                          bottom: 0,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Area type="monotone" dataKey="bounceRate" stroke="#ffc658" fill="#ffc658" name="Taxa de Rejeição (%)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Dispositivos</CardTitle>
                  <CardDescription>Distribuição de visitas por tipo de dispositivo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={deviceData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="#8884d8" name="Porcentagem (%)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Principais Páginas</CardTitle>
                  <CardDescription>Páginas mais visitadas no período</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">3,245</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/produtos</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">2,890</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/blog</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">1,932</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/sobre</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">1,250</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/contato</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">943</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/produtos/categoria/eletronicos</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">856</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/blog/2023/novo-produto</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">721</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="audience">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Navegadores</CardTitle>
                  <CardDescription>Distribuição de visitas por navegador</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={browserData}
                        layout="vertical"
                        margin={{
                          top: 20,
                          right: 30,
                          left: 40,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" />
                        <Tooltip />
                        <Bar dataKey="value" fill="#82ca9d" name="Porcentagem (%)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Países</CardTitle>
                  <CardDescription>Distribuição de visitas por país</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={countryData}
                        layout="vertical"
                        margin={{
                          top: 20,
                          right: 30,
                          left: 40,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" />
                        <Tooltip />
                        <Bar dataKey="value" fill="#8884d8" name="Porcentagem (%)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Demografia dos Usuários</CardTitle>
                <CardDescription>Informações demográficas dos visitantes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-base font-medium mb-4">Idade</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">18-24</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">22%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '22%' }}></div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">25-34</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">38%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '38%' }}></div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">35-44</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">25%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '25%' }}></div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">45-54</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">10%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '10%' }}></div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">55+</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">5%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '5%' }}></div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-base font-medium mb-4">Gênero</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Masculino</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">54%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '54%' }}></div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Feminino</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">45%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '45%' }}></div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Não especificado</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">1%</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '1%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="performance">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Métricas de Desempenho</CardTitle>
                <CardDescription>Tempos de carregamento e métricas de web vitals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={performanceData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis label={{ value: 'Segundos', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="loadTime" fill="#8884d8" name="Tempo de Carregamento" />
                      <Bar dataKey="firstContentfulPaint" fill="#82ca9d" name="First Contentful Paint" />
                      <Bar dataKey="largestContentfulPaint" fill="#ffc658" name="Largest Contentful Paint" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Tempo de Resposta do Servidor</CardTitle>
                  <CardDescription>Latência do servidor ao longo do tempo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={[
                          { time: '00:00', ttfb: 122 },
                          { time: '04:00', ttfb: 125 },
                          { time: '08:00', ttfb: 175 },
                          { time: '12:00', ttfb: 210 },
                          { time: '16:00', ttfb: 198 },
                          { time: '20:00', ttfb: 145 },
                          { time: '24:00', ttfb: 120 },
                        ]}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis label={{ value: 'ms', angle: -90, position: 'insideLeft' }} />
                        <Tooltip />
                        <Line type="monotone" dataKey="ttfb" stroke="#82ca9d" name="TTFB (ms)" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Otimização de Recursos</CardTitle>
                  <CardDescription>Tamanho dos arquivos e requisições</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">HTML (42 KB)</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">Bom</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '100%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">CSS (156 KB)</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">Bom</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '100%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">JavaScript (872 KB)</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">Atenção</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: '70%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Imagens (1.8 MB)</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">Precisa melhorar</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '40%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Fontes (125 KB)</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">Bom</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '90%' }}></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="behavior">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Fluxo de Usuários</CardTitle>
                  <CardDescription>Como os usuários navegam pelo site</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="p-4 border rounded-lg dark:border-gray-700">
                    <div className="flex flex-col items-center justify-center gap-4">
                      <div className="bg-primary-100 dark:bg-primary-900 p-3 rounded-lg text-center min-w-[200px]">
                        <div className="font-medium">Página Inicial</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">3,245 entradas</div>
                      </div>
                      
                      <div className="flex items-center">
                        <div className="h-8 w-0.5 bg-gray-300 dark:bg-gray-700"></div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4">
                        <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                          <div className="font-medium">Produtos</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">1,450 usuários</div>
                        </div>
                        <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                          <div className="font-medium">Blog</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">950 usuários</div>
                        </div>
                        <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                          <div className="font-medium">Sobre</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">450 usuários</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <div className="h-8 w-0.5 bg-gray-300 dark:bg-gray-700"></div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                          <div className="font-medium">Produto Específico</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">980 usuários</div>
                        </div>
                        <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                          <div className="font-medium">Artigo do Blog</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">580 usuários</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <div className="h-8 w-0.5 bg-gray-300 dark:bg-gray-700"></div>
                      </div>
                      
                      <div className="bg-green-100 dark:bg-green-900 p-3 rounded-lg text-center min-w-[200px]">
                        <div className="font-medium">Checkout</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">520 conversões</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Eventos</CardTitle>
                  <CardDescription>Ações realizadas pelos usuários</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Clique em Botão "Comprar"</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">1,245</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Adição ao Carrinho</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">820</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Início de Checkout</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">645</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Compra Finalizada</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">520</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Download de PDF</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">350</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Inscrição em Newsletter</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">280</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Compartilhamento em Redes Sociais</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">175</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Tempo por Página</CardTitle>
                  <CardDescription>Tempo médio gasto em cada página</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/blog/post/guia-completo</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">5m 32s</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/produtos/smartphone-x</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">4m 18s</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/sobre/nossa-historia</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">3m 45s</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/produtos</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">2m 56s</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/blog</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">2m 24s</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">1m 42s</div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300">/contato</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">1m 12s</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </>
  );
}