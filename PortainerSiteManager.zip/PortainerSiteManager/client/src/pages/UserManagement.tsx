import { useState } from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'editor' | 'viewer';
  status: 'active' | 'inactive' | 'pending';
  avatar?: string;
  lastLogin?: string;
  permissions: {
    [key: string]: boolean;
  };
  websites: string[];
}

interface UserGroup {
  id: string;
  name: string;
  description: string;
  members: number;
  permissions: {
    [key: string]: boolean;
  };
}

export default function UserManagement() {
  const [users, setUsers] = useState<User[]>([
    {
      id: 'u1',
      name: 'Administrador',
      email: 'admin@example.com',
      role: 'admin',
      status: 'active',
      lastLogin: '2023-01-16T14:22:00',
      permissions: {
        'view_dashboard': true,
        'edit_website': true,
        'publish_website': true,
        'manage_users': true,
        'view_analytics': true,
        'manage_templates': true,
        'access_admin': true,
        'manage_billing': true,
      },
      websites: ['all']
    },
    {
      id: 'u2',
      name: 'João Editor',
      email: 'joao@example.com',
      role: 'editor',
      status: 'active',
      avatar: 'https://i.pravatar.cc/150?u=joao',
      lastLogin: '2023-01-16T10:15:00',
      permissions: {
        'view_dashboard': true,
        'edit_website': true,
        'publish_website': true,
        'manage_users': false,
        'view_analytics': true,
        'manage_templates': false,
        'access_admin': false,
        'manage_billing': false,
      },
      websites: ['company-homepage', 'landing-page']
    },
    {
      id: 'u3',
      name: 'Maria Visualizadora',
      email: 'maria@example.com',
      role: 'viewer',
      status: 'active',
      avatar: 'https://i.pravatar.cc/150?u=maria',
      lastLogin: '2023-01-15T16:45:00',
      permissions: {
        'view_dashboard': true,
        'edit_website': false,
        'publish_website': false,
        'manage_users': false,
        'view_analytics': true,
        'manage_templates': false,
        'access_admin': false,
        'manage_billing': false,
      },
      websites: ['e-commerce-store', 'blog-site']
    },
    {
      id: 'u4',
      name: 'Carlos Editor',
      email: 'carlos@example.com',
      role: 'editor',
      status: 'inactive',
      avatar: 'https://i.pravatar.cc/150?u=carlos',
      lastLogin: '2023-01-10T09:30:00',
      permissions: {
        'view_dashboard': true,
        'edit_website': true,
        'publish_website': false,
        'manage_users': false,
        'view_analytics': true,
        'manage_templates': true,
        'access_admin': false,
        'manage_billing': false,
      },
      websites: ['e-commerce-store']
    },
    {
      id: 'u5',
      name: 'Ana Editora',
      email: 'ana@example.com',
      role: 'editor',
      status: 'pending',
      permissions: {
        'view_dashboard': true,
        'edit_website': true,
        'publish_website': false,
        'manage_users': false,
        'view_analytics': false,
        'manage_templates': false,
        'access_admin': false,
        'manage_billing': false,
      },
      websites: ['blog-site']
    }
  ]);
  
  const [userGroups, setUserGroups] = useState<UserGroup[]>([
    {
      id: 'g1',
      name: 'Administradores',
      description: 'Acesso completo ao sistema',
      members: 1,
      permissions: {
        'view_dashboard': true,
        'edit_website': true,
        'publish_website': true,
        'manage_users': true,
        'view_analytics': true,
        'manage_templates': true,
        'access_admin': true,
        'manage_billing': true,
      }
    },
    {
      id: 'g2',
      name: 'Editores',
      description: 'Podem editar e publicar conteúdo',
      members: 3,
      permissions: {
        'view_dashboard': true,
        'edit_website': true,
        'publish_website': true,
        'manage_users': false,
        'view_analytics': true,
        'manage_templates': false,
        'access_admin': false,
        'manage_billing': false,
      }
    },
    {
      id: 'g3',
      name: 'Visualizadores',
      description: 'Podem apenas visualizar, sem edição',
      members: 1,
      permissions: {
        'view_dashboard': true,
        'edit_website': false,
        'publish_website': false,
        'manage_users': false,
        'view_analytics': true,
        'manage_templates': false,
        'access_admin': false,
        'manage_billing': false,
      }
    }
  ]);
  
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<UserGroup | null>(null);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [groupDialogOpen, setGroupDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [userSearchTerm, setUserSearchTerm] = useState('');
  
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Nunca';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const getInitials = (name: string) => {
    return name.split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  const getRoleBadge = (role: string) => {
    switch(role) {
      case 'admin':
        return <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">Administrador</Badge>;
      case 'editor':
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Editor</Badge>;
      case 'viewer':
        return <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200">Visualizador</Badge>;
      default:
        return <Badge>Desconhecido</Badge>;
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Ativo</Badge>;
      case 'inactive':
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Inativo</Badge>;
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">Pendente</Badge>;
      default:
        return <Badge>Desconhecido</Badge>;
    }
  };
  
  const handleOpenUserDialog = (user?: User) => {
    if (user) {
      setSelectedUser(user);
      setIsEditMode(true);
    } else {
      setSelectedUser({
        id: `u${users.length + 1}`,
        name: '',
        email: '',
        role: 'viewer',
        status: 'pending',
        permissions: {
          'view_dashboard': true,
          'edit_website': false,
          'publish_website': false,
          'manage_users': false,
          'view_analytics': false,
          'manage_templates': false,
          'access_admin': false,
          'manage_billing': false,
        },
        websites: []
      });
      setIsEditMode(false);
    }
    setUserDialogOpen(true);
  };
  
  const handleOpenGroupDialog = (group?: UserGroup) => {
    if (group) {
      setSelectedGroup(group);
      setIsEditMode(true);
    } else {
      setSelectedGroup({
        id: `g${userGroups.length + 1}`,
        name: '',
        description: '',
        members: 0,
        permissions: {
          'view_dashboard': true,
          'edit_website': false,
          'publish_website': false,
          'manage_users': false,
          'view_analytics': false,
          'manage_templates': false,
          'access_admin': false,
          'manage_billing': false,
        }
      });
      setIsEditMode(false);
    }
    setGroupDialogOpen(true);
  };
  
  const handleSaveUser = () => {
    if (!selectedUser) return;
    
    if (isEditMode) {
      // Update existing user
      setUsers(users.map(u => u.id === selectedUser.id ? selectedUser : u));
    } else {
      // Add new user
      setUsers([...users, selectedUser]);
    }
    
    setUserDialogOpen(false);
  };
  
  const handleSaveGroup = () => {
    if (!selectedGroup) return;
    
    if (isEditMode) {
      // Update existing group
      setUserGroups(userGroups.map(g => g.id === selectedGroup.id ? selectedGroup : g));
    } else {
      // Add new group
      setUserGroups([...userGroups, selectedGroup]);
    }
    
    setGroupDialogOpen(false);
  };
  
  const handleStatusChange = (userId: string, newStatus: 'active' | 'inactive' | 'pending') => {
    setUsers(users.map(user => {
      if (user.id === userId) {
        return { ...user, status: newStatus };
      }
      return user;
    }));
  };
  
  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Tem certeza que deseja remover este usuário?')) {
      setUsers(users.filter(user => user.id !== userId));
    }
  };
  
  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  return (
    <>
      <Header 
        title="Gestão de Usuários" 
        actions={
          <div className="flex space-x-2">
            <Button 
              size="sm"
              className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
              onClick={() => handleOpenUserDialog()}
            >
              <i className="ri-user-add-line mr-1.5"></i>
              Novo Usuário
            </Button>
            <Button 
              size="sm"
              variant="outline"
              onClick={() => handleOpenGroupDialog()}
            >
              <i className="ri-group-line mr-1.5"></i>
              Novo Grupo
            </Button>
          </div>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="users" className="space-y-8">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="groups">Grupos</TabsTrigger>
          </TabsList>
          
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <CardTitle>Usuários</CardTitle>
                    <CardDescription>Gerencie usuários e suas permissões</CardDescription>
                  </div>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Buscar usuários..."
                      className="w-full sm:w-[300px]"
                      value={userSearchTerm}
                      onChange={(e) => setUserSearchTerm(e.target.value)}
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <i className="ri-search-line text-gray-400"></i>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Usuário</th>
                        <th scope="col" className="px-6 py-3">Função</th>
                        <th scope="col" className="px-6 py-3">Status</th>
                        <th scope="col" className="px-6 py-3">Último Acesso</th>
                        <th scope="col" className="px-6 py-3">Sites Atribuídos</th>
                        <th scope="col" className="px-6 py-3">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                          <td className="px-6 py-4 flex items-center space-x-3">
                            <Avatar>
                              <AvatarImage src={user.avatar} />
                              <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium text-gray-900 dark:text-white">{user.name}</div>
                              <div className="text-xs text-gray-500">{user.email}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            {getRoleBadge(user.role)}
                          </td>
                          <td className="px-6 py-4">
                            {getStatusBadge(user.status)}
                          </td>
                          <td className="px-6 py-4">
                            {formatDate(user.lastLogin)}
                          </td>
                          <td className="px-6 py-4">
                            {user.websites.includes('all') ? (
                              <span className="text-sm">Todos os sites</span>
                            ) : (
                              <div className="flex flex-wrap gap-1">
                                {user.websites.map((site, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {site === 'company-homepage' ? 'Página da Empresa' :
                                     site === 'e-commerce-store' ? 'Loja E-commerce' :
                                     site === 'blog-site' ? 'Blog' :
                                     site === 'landing-page' ? 'Landing Page' : site}
                                  </Badge>
                                ))}
                                {user.websites.length === 0 && (
                                  <span className="text-sm text-gray-500">Nenhum site</span>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleOpenUserDialog(user)}
                              >
                                <i className="ri-edit-line"></i>
                              </Button>
                              {user.status === 'active' ? (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleStatusChange(user.id, 'inactive')}
                                >
                                  <i className="ri-user-unfollow-line"></i>
                                </Button>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleStatusChange(user.id, 'active')}
                                >
                                  <i className="ri-user-follow-line"></i>
                                </Button>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteUser(user.id)}
                              >
                                <i className="ri-delete-bin-line"></i>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Logs de Atividade</CardTitle>
                <CardDescription>Atividades recentes de usuários no sistema</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-4">
                    <Avatar className="mt-1">
                      <AvatarFallback>AD</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-white">Administrador</div>
                        <div className="text-xs text-gray-500">16/01/2023 14:30</div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Alterou as permissões do usuário <span className="font-medium">João Editor</span>
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Avatar className="mt-1">
                      <AvatarImage src="https://i.pravatar.cc/150?u=joao" />
                      <AvatarFallback>JE</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-white">João Editor</div>
                        <div className="text-xs text-gray-500">16/01/2023 10:15</div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Fez login no sistema
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Avatar className="mt-1">
                      <AvatarImage src="https://i.pravatar.cc/150?u=maria" />
                      <AvatarFallback>MV</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-white">Maria Visualizadora</div>
                        <div className="text-xs text-gray-500">15/01/2023 16:45</div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Visualizou relatórios de analytics
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Avatar className="mt-1">
                      <AvatarFallback>AD</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-white">Administrador</div>
                        <div className="text-xs text-gray-500">15/01/2023 11:20</div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Criou o usuário <span className="font-medium">Ana Editora</span>
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Avatar className="mt-1">
                      <AvatarImage src="https://i.pravatar.cc/150?u=carlos" />
                      <AvatarFallback>CE</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-white">Carlos Editor</div>
                        <div className="text-xs text-gray-500">10/01/2023 09:30</div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Alterou conteúdo do site <span className="font-medium">Loja E-commerce</span>
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="groups" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Grupos de Usuários</CardTitle>
                <CardDescription>Gerencie grupos e suas permissões</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {userGroups.map((group) => (
                    <Card key={group.id}>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          {group.name}
                          <span className="text-sm font-normal text-gray-500 dark:text-gray-400">{group.members} usuários</span>
                        </CardTitle>
                        <CardDescription>{group.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="font-medium text-gray-700 dark:text-gray-300">Ver Dashboard</span>
                            <span>{group.permissions.view_dashboard ? '✓' : '✗'}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="font-medium text-gray-700 dark:text-gray-300">Editar Website</span>
                            <span>{group.permissions.edit_website ? '✓' : '✗'}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="font-medium text-gray-700 dark:text-gray-300">Publicar Website</span>
                            <span>{group.permissions.publish_website ? '✓' : '✗'}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="font-medium text-gray-700 dark:text-gray-300">Gerenciar Usuários</span>
                            <span>{group.permissions.manage_users ? '✓' : '✗'}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="font-medium text-gray-700 dark:text-gray-300">Ver Analytics</span>
                            <span>{group.permissions.view_analytics ? '✓' : '✗'}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleOpenGroupDialog(group)}>
                          Editar
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Matriz de Permissões</CardTitle>
                <CardDescription>Visão geral de permissões por grupo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
                      <tr>
                        <th scope="col" className="px-6 py-3">Permissão</th>
                        {userGroups.map(group => (
                          <th key={group.id} scope="col" className="px-6 py-3">{group.name}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Ver Dashboard</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.view_dashboard ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Editar Website</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.edit_website ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Publicar Website</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.publish_website ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Gerenciar Usuários</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.manage_users ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Ver Analytics</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.view_analytics ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Gerenciar Templates</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.manage_templates ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Acesso Administrativo</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.access_admin ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                      <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td className="px-6 py-4 font-medium">Gerenciar Faturamento</td>
                        {userGroups.map(group => (
                          <td key={group.id} className="px-6 py-4">
                            {group.permissions.manage_billing ? 
                              <i className="ri-check-line text-green-500"></i> : 
                              <i className="ri-close-line text-red-500"></i>}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      {/* User Dialog */}
      <Dialog open={userDialogOpen} onOpenChange={setUserDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Editar Usuário' : 'Novo Usuário'}</DialogTitle>
            <DialogDescription>
              {isEditMode ? 'Atualize os dados e permissões do usuário.' : 'Crie um novo usuário no sistema.'}
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div className="grid grid-cols-1 gap-6 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="user-name">Nome</Label>
                  <Input 
                    id="user-name" 
                    value={selectedUser.name}
                    onChange={(e) => setSelectedUser({...selectedUser, name: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="user-email">E-mail</Label>
                  <Input 
                    id="user-email" 
                    type="email"
                    value={selectedUser.email}
                    onChange={(e) => setSelectedUser({...selectedUser, email: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="user-role">Função</Label>
                  <Select 
                    value={selectedUser.role}
                    onValueChange={(value: 'admin' | 'editor' | 'viewer') => setSelectedUser({...selectedUser, role: value})}
                  >
                    <SelectTrigger id="user-role">
                      <SelectValue placeholder="Selecione uma função" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Administrador</SelectItem>
                      <SelectItem value="editor">Editor</SelectItem>
                      <SelectItem value="viewer">Visualizador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="user-status">Status</Label>
                  <Select 
                    value={selectedUser.status}
                    onValueChange={(value: 'active' | 'inactive' | 'pending') => setSelectedUser({...selectedUser, status: value})}
                  >
                    <SelectTrigger id="user-status">
                      <SelectValue placeholder="Selecione um status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Ativo</SelectItem>
                      <SelectItem value="inactive">Inativo</SelectItem>
                      <SelectItem value="pending">Pendente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Sites Atribuídos</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="site-all" 
                      checked={selectedUser.websites.includes('all')}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedUser({...selectedUser, websites: ['all']});
                        } else {
                          setSelectedUser({...selectedUser, websites: []});
                        }
                      }}
                    />
                    <Label htmlFor="site-all" className="text-sm font-normal">Todos os sites</Label>
                  </div>
                  
                  {!selectedUser.websites.includes('all') && (
                    <>
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="site-company" 
                          checked={selectedUser.websites.includes('company-homepage')}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedUser({...selectedUser, websites: [...selectedUser.websites, 'company-homepage']});
                            } else {
                              setSelectedUser({...selectedUser, websites: selectedUser.websites.filter(w => w !== 'company-homepage')});
                            }
                          }}
                        />
                        <Label htmlFor="site-company" className="text-sm font-normal">Página da Empresa</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="site-ecommerce" 
                          checked={selectedUser.websites.includes('e-commerce-store')}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedUser({...selectedUser, websites: [...selectedUser.websites, 'e-commerce-store']});
                            } else {
                              setSelectedUser({...selectedUser, websites: selectedUser.websites.filter(w => w !== 'e-commerce-store')});
                            }
                          }}
                        />
                        <Label htmlFor="site-ecommerce" className="text-sm font-normal">Loja E-commerce</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="site-blog" 
                          checked={selectedUser.websites.includes('blog-site')}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedUser({...selectedUser, websites: [...selectedUser.websites, 'blog-site']});
                            } else {
                              setSelectedUser({...selectedUser, websites: selectedUser.websites.filter(w => w !== 'blog-site')});
                            }
                          }}
                        />
                        <Label htmlFor="site-blog" className="text-sm font-normal">Blog</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="site-landing" 
                          checked={selectedUser.websites.includes('landing-page')}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedUser({...selectedUser, websites: [...selectedUser.websites, 'landing-page']});
                            } else {
                              setSelectedUser({...selectedUser, websites: selectedUser.websites.filter(w => w !== 'landing-page')});
                            }
                          }}
                        />
                        <Label htmlFor="site-landing" className="text-sm font-normal">Landing Page</Label>
                      </div>
                    </>
                  )}
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <Label>Permissões</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-dashboard" 
                      checked={selectedUser.permissions.view_dashboard}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, view_dashboard: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-dashboard" className="text-sm font-normal">Ver Dashboard</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-edit-website" 
                      checked={selectedUser.permissions.edit_website}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, edit_website: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-edit-website" className="text-sm font-normal">Editar Website</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-publish-website" 
                      checked={selectedUser.permissions.publish_website}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, publish_website: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-publish-website" className="text-sm font-normal">Publicar Website</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-manage-users" 
                      checked={selectedUser.permissions.manage_users}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, manage_users: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-manage-users" className="text-sm font-normal">Gerenciar Usuários</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-view-analytics" 
                      checked={selectedUser.permissions.view_analytics}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, view_analytics: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-view-analytics" className="text-sm font-normal">Ver Analytics</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-manage-templates" 
                      checked={selectedUser.permissions.manage_templates}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, manage_templates: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-manage-templates" className="text-sm font-normal">Gerenciar Templates</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-access-admin" 
                      checked={selectedUser.permissions.access_admin}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, access_admin: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-access-admin" className="text-sm font-normal">Acesso Administrativo</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="perm-manage-billing" 
                      checked={selectedUser.permissions.manage_billing}
                      onCheckedChange={(checked) => {
                        setSelectedUser({
                          ...selectedUser, 
                          permissions: {...selectedUser.permissions, manage_billing: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="perm-manage-billing" className="text-sm font-normal">Gerenciar Faturamento</Label>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setUserDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button onClick={handleSaveUser}>
              {isEditMode ? 'Salvar Alterações' : 'Criar Usuário'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Group Dialog */}
      <Dialog open={groupDialogOpen} onOpenChange={setGroupDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Editar Grupo' : 'Novo Grupo'}</DialogTitle>
            <DialogDescription>
              {isEditMode ? 'Atualize os dados e permissões do grupo.' : 'Crie um novo grupo de usuários.'}
            </DialogDescription>
          </DialogHeader>
          
          {selectedGroup && (
            <div className="grid grid-cols-1 gap-6 py-4">
              <div className="space-y-2">
                <Label htmlFor="group-name">Nome do Grupo</Label>
                <Input 
                  id="group-name" 
                  value={selectedGroup.name}
                  onChange={(e) => setSelectedGroup({...selectedGroup, name: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="group-description">Descrição</Label>
                <Input 
                  id="group-description" 
                  value={selectedGroup.description}
                  onChange={(e) => setSelectedGroup({...selectedGroup, description: e.target.value})}
                />
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <Label>Permissões do Grupo</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-dashboard" 
                      checked={selectedGroup.permissions.view_dashboard}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, view_dashboard: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-dashboard" className="text-sm font-normal">Ver Dashboard</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-edit-website" 
                      checked={selectedGroup.permissions.edit_website}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, edit_website: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-edit-website" className="text-sm font-normal">Editar Website</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-publish-website" 
                      checked={selectedGroup.permissions.publish_website}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, publish_website: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-publish-website" className="text-sm font-normal">Publicar Website</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-manage-users" 
                      checked={selectedGroup.permissions.manage_users}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, manage_users: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-manage-users" className="text-sm font-normal">Gerenciar Usuários</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-view-analytics" 
                      checked={selectedGroup.permissions.view_analytics}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, view_analytics: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-view-analytics" className="text-sm font-normal">Ver Analytics</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-manage-templates" 
                      checked={selectedGroup.permissions.manage_templates}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, manage_templates: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-manage-templates" className="text-sm font-normal">Gerenciar Templates</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-access-admin" 
                      checked={selectedGroup.permissions.access_admin}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, access_admin: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-access-admin" className="text-sm font-normal">Acesso Administrativo</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="group-perm-manage-billing" 
                      checked={selectedGroup.permissions.manage_billing}
                      onCheckedChange={(checked) => {
                        setSelectedGroup({
                          ...selectedGroup, 
                          permissions: {...selectedGroup.permissions, manage_billing: !!checked}
                        });
                      }}
                    />
                    <Label htmlFor="group-perm-manage-billing" className="text-sm font-normal">Gerenciar Faturamento</Label>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setGroupDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button onClick={handleSaveGroup}>
              {isEditMode ? 'Salvar Alterações' : 'Criar Grupo'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}