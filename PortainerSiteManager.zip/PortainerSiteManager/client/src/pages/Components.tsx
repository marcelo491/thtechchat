import Header from "@/components/Header";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Component } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export default function Components() {
  const { data: components, isLoading } = useQuery({
    queryKey: ['/api/components'],
  });

  // Mantemos as categorias em inglês para compatibilidade com backend, mas traduzimos na UI
  const basicComponents = components?.filter((c: Component) => c.category === "basic") || [];
  const layoutComponents = components?.filter((c: Component) => c.category === "layout") || [];
  const advancedComponents = components?.filter((c: Component) => c.category === "components") || [];

  return (
    <>
      <Header title="Componentes" />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-8">
            <TabsTrigger value="all">Todos Componentes</TabsTrigger>
            <TabsTrigger value="basic">Básicos</TabsTrigger>
            <TabsTrigger value="layout">Layout</TabsTrigger>
            <TabsTrigger value="advanced">Avançados</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <div className="space-y-8">
              <ComponentCategory title="Componentes Básicos" components={basicComponents} isLoading={isLoading} />
              <ComponentCategory title="Componentes de Layout" components={layoutComponents} isLoading={isLoading} />
              <ComponentCategory title="Componentes Avançados" components={advancedComponents} isLoading={isLoading} />
            </div>
          </TabsContent>
          
          <TabsContent value="basic">
            <ComponentCategory title="Componentes Básicos" components={basicComponents} isLoading={isLoading} />
          </TabsContent>
          
          <TabsContent value="layout">
            <ComponentCategory title="Componentes de Layout" components={layoutComponents} isLoading={isLoading} />
          </TabsContent>
          
          <TabsContent value="advanced">
            <ComponentCategory title="Componentes Avançados" components={advancedComponents} isLoading={isLoading} />
          </TabsContent>
        </Tabs>
      </main>
    </>
  );
}

function ComponentCategory({ title, components, isLoading }: { title: string, components: Component[], isLoading: boolean }) {
  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {isLoading ? (
          Array(4).fill(0).map((_, i) => (
            <Card key={i} className="h-32">
              <CardContent className="p-4 flex items-center justify-center">
                <Skeleton className="h-10 w-10 rounded-full mb-2" />
                <div className="ml-4">
                  <Skeleton className="h-4 w-20 mb-2" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          components.map((component) => (
            <Card key={component.id} className="hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors cursor-pointer">
              <CardContent className="p-4 flex items-center">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center mr-3",
                  component.category === "basic" && "bg-blue-100 dark:bg-blue-900 text-blue-500 dark:text-blue-300",
                  component.category === "layout" && "bg-green-100 dark:bg-green-900 text-green-500 dark:text-green-300",
                  component.category === "components" && "bg-purple-100 dark:bg-purple-900 text-purple-500 dark:text-purple-300"
                )}>
                  <i className={component.icon}></i>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 dark:text-white">{component.name}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{component.type}</p>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
