import Header from "@/components/Header";
import SiteCard from "@/components/SiteCard";
import { useSites } from "@/hooks/useSites";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import SiteEditor from "@/components/SiteEditor";
import { Website } from "@shared/schema";
import { PlusIcon } from "lucide-react";

export default function Websites() {
  const { sites, isLoading, refetch } = useSites();
  const [editorOpen, setEditorOpen] = useState(false);
  const [selectedSite, setSelectedSite] = useState<Website | null>(null);

  const handleCreateNewSite = () => {
    setSelectedSite(null);
    setEditorOpen(true);
  };

  const handleEditSite = (site: Website) => {
    setSelectedSite(site);
    setEditorOpen(true);
  };

  const handleCloseEditor = () => {
    setEditorOpen(false);
    refetch();
  };

  return (
    <>
      <Header 
        title="Sites" 
        actions={
          <Button 
            onClick={handleCreateNewSite}
            size="sm"
            className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
          >
            <PlusIcon className="h-4 w-4 mr-1.5" />
            Novo Site
          </Button>
        }
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <div className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-5 w-12" />
                  </div>
                  <Skeleton className="h-4 w-48 mb-4" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                </div>
              </div>
            ))
          ) : sites?.length === 0 ? (
            <div className="col-span-full flex flex-col items-center justify-center p-12 text-center">
              <div className="h-20 w-20 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-400 mb-4">
                <i className="ri-global-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">Nenhum site ainda</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md">
                Crie seu primeiro site para começar. Você pode começar do zero ou usar um de nossos modelos.
              </p>
              <Button 
                onClick={handleCreateNewSite}
                className="flex items-center"
              >
                <PlusIcon className="h-4 w-4 mr-1.5" />
                Criar Novo Site
              </Button>
            </div>
          ) : (
            sites?.map((site) => (
              <SiteCard 
                key={site.id}
                site={site} 
                onEdit={() => handleEditSite(site)}
              />
            ))
          )}
        </div>
      </main>

      {editorOpen && (
        <SiteEditor
          isOpen={editorOpen}
          onClose={handleCloseEditor}
          site={selectedSite}
        />
      )}
    </>
  );
}
