import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

interface FileNode {
  name: string;
  type: 'file' | 'directory';
  path: string;
  language?: string;
  children?: FileNode[];
}

export default function CodeEditor() {
  const [fileStructure, setFileStructure] = useState<FileNode[]>([
    {
      name: 'projeto-site',
      type: 'directory',
      path: '/projeto-site',
      children: [
        {
          name: 'public',
          type: 'directory',
          path: '/projeto-site/public',
          children: [
            {
              name: 'index.html',
              type: 'file',
              path: '/projeto-site/public/index.html',
              language: 'html'
            },
            {
              name: 'assets',
              type: 'directory',
              path: '/projeto-site/public/assets',
              children: [
                {
                  name: 'style.css',
                  type: 'file',
                  path: '/projeto-site/public/assets/style.css',
                  language: 'css'
                },
                {
                  name: 'main.js',
                  type: 'file',
                  path: '/projeto-site/public/assets/main.js',
                  language: 'javascript'
                },
                {
                  name: 'logo.svg',
                  type: 'file',
                  path: '/projeto-site/public/assets/logo.svg',
                  language: 'svg'
                }
              ]
            }
          ]
        },
        {
          name: 'src',
          type: 'directory',
          path: '/projeto-site/src',
          children: [
            {
              name: 'components',
              type: 'directory',
              path: '/projeto-site/src/components',
              children: [
                {
                  name: 'Header.jsx',
                  type: 'file',
                  path: '/projeto-site/src/components/Header.jsx',
                  language: 'jsx'
                },
                {
                  name: 'Footer.jsx',
                  type: 'file',
                  path: '/projeto-site/src/components/Footer.jsx',
                  language: 'jsx'
                },
                {
                  name: 'Navigation.jsx',
                  type: 'file',
                  path: '/projeto-site/src/components/Navigation.jsx',
                  language: 'jsx'
                }
              ]
            },
            {
              name: 'pages',
              type: 'directory',
              path: '/projeto-site/src/pages',
              children: [
                {
                  name: 'Home.jsx',
                  type: 'file',
                  path: '/projeto-site/src/pages/Home.jsx',
                  language: 'jsx'
                },
                {
                  name: 'About.jsx',
                  type: 'file',
                  path: '/projeto-site/src/pages/About.jsx',
                  language: 'jsx'
                },
                {
                  name: 'Contact.jsx',
                  type: 'file',
                  path: '/projeto-site/src/pages/Contact.jsx',
                  language: 'jsx'
                }
              ]
            },
            {
              name: 'App.jsx',
              type: 'file',
              path: '/projeto-site/src/App.jsx',
              language: 'jsx'
            },
            {
              name: 'index.js',
              type: 'file',
              path: '/projeto-site/src/index.js',
              language: 'javascript'
            }
          ]
        },
        {
          name: 'package.json',
          type: 'file',
          path: '/projeto-site/package.json',
          language: 'json'
        },
        {
          name: 'README.md',
          type: 'file',
          path: '/projeto-site/README.md',
          language: 'markdown'
        }
      ]
    }
  ]);
  
  const [activeFile, setActiveFile] = useState<string | null>(null);
  const [openFiles, setOpenFiles] = useState<string[]>([]);
  const [fileContents, setFileContents] = useState<Record<string, string>>({
    '/projeto-site/public/index.html': `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meu Site</title>
  <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
  <div id="root"></div>
  <script src="./assets/main.js"></script>
</body>
</html>`,
    '/projeto-site/public/assets/style.css': `body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
    Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #eaeaea;
}

.nav {
  display: flex;
  gap: 20px;
}

.nav a {
  text-decoration: none;
  color: #333;
  font-weight: 500;
}

.nav a:hover {
  color: #0070f3;
}

.footer {
  margin-top: 40px;
  padding: 20px 0;
  border-top: 1px solid #eaeaea;
  text-align: center;
}`,
    '/projeto-site/src/App.jsx': `import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <main className="container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;`,
    '/projeto-site/src/components/Header.jsx': `import React from 'react';
import Navigation from './Navigation';

function Header() {
  return (
    <header className="header container">
      <div className="logo">
        <h1>Meu Site</h1>
      </div>
      <Navigation />
    </header>
  );
}

export default Header;`,
    '/projeto-site/src/components/Footer.jsx': `import React from 'react';

function Footer() {
  return (
    <footer className="footer container">
      <p>&copy; {new Date().getFullYear()} Meu Site. Todos os direitos reservados.</p>
    </footer>
  );
}

export default Footer;`,
    '/projeto-site/src/components/Navigation.jsx': `import React from 'react';
import { Link } from 'react-router-dom';

function Navigation() {
  return (
    <nav className="nav">
      <Link to="/">Home</Link>
      <Link to="/about">Sobre</Link>
      <Link to="/contact">Contato</Link>
    </nav>
  );
}

export default Navigation;`,
    '/projeto-site/src/pages/Home.jsx': `import React from 'react';

function Home() {
  return (
    <div className="home-page">
      <h2>Bem-vindo ao nosso site</h2>
      <p>
        Esta é a página inicial do nosso site. Aqui você encontrará as principais 
        informações sobre nossos serviços e produtos.
      </p>
      <div className="featured-section">
        <h3>Destaques</h3>
        <div className="featured-items">
          <div className="item">
            <h4>Serviço 1</h4>
            <p>Descrição do serviço 1</p>
          </div>
          <div className="item">
            <h4>Serviço 2</h4>
            <p>Descrição do serviço 2</p>
          </div>
          <div className="item">
            <h4>Serviço 3</h4>
            <p>Descrição do serviço 3</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;`,
    '/projeto-site/src/pages/About.jsx': `import React from 'react';

function About() {
  return (
    <div className="about-page">
      <h2>Sobre Nós</h2>
      <p>
        Somos uma empresa dedicada a fornecer soluções de alta qualidade para nossos clientes.
        Fundada em 2020, nossa missão é simplificar a vida digital das pessoas e empresas.
      </p>
      <h3>Nossa História</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, 
        nisl eget ultricies lacinia, nisl nisl aliquam nisl, eget ultricies nisl 
        nisl eget nisl. Nullam auctor, nisl eget ultricies lacinia, nisl nisl 
        aliquam nisl, eget ultricies nisl nisl eget nisl.
      </p>
      <h3>Nossa Equipe</h3>
      <div className="team-members">
        <div className="member">
          <h4>João Silva</h4>
          <p>CEO & Fundador</p>
        </div>
        <div className="member">
          <h4>Maria Oliveira</h4>
          <p>CTO</p>
        </div>
        <div className="member">
          <h4>Carlos Santos</h4>
          <p>Diretor de Marketing</p>
        </div>
      </div>
    </div>
  );
}

export default About;`,
    '/projeto-site/src/pages/Contact.jsx': `import React, { useState } from 'react';

function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aqui você adicionaria a lógica para enviar o formulário
    console.log('Formulário enviado:', formData);
    alert('Mensagem enviada com sucesso!');
    // Resetar o formulário
    setFormData({
      name: '',
      email: '',
      message: ''
    });
  };

  return (
    <div className="contact-page">
      <h2>Entre em Contato</h2>
      <p>
        Preencha o formulário abaixo para entrar em contato conosco. 
        Responderemos o mais breve possível.
      </p>
      
      <form onSubmit={handleSubmit} className="contact-form">
        <div className="form-group">
          <label htmlFor="name">Nome</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="email">E-mail</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="message">Mensagem</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            rows={5}
            required
          ></textarea>
        </div>
        
        <button type="submit" className="submit-btn">Enviar Mensagem</button>
      </form>
      
      <div className="contact-info">
        <h3>Informações de Contato</h3>
        <p>
          <strong>Endereço:</strong> Rua Exemplo, 123 - Cidade - Estado<br />
          <strong>E-mail:</strong> contato@meusite.com<br />
          <strong>Telefone:</strong> (11) 1234-5678
        </p>
      </div>
    </div>
  );
}

export default Contact;`,
    '/projeto-site/src/index.js': `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,
    '/projeto-site/package.json': `{
  "name": "projeto-site",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.4.3"
  },
  "scripts": {
    "start": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^2.2.0",
    "vite": "^3.2.3"
  }
}`,
    '/projeto-site/README.md': `# Projeto Site

Este é um projeto de exemplo para demonstração do editor de código integrado.

## Como iniciar

1. Clone o repositório
2. Instale as dependências com \`npm install\`
3. Inicie o servidor de desenvolvimento com \`npm start\`

## Estrutura do projeto

- \`public/\`: Arquivos estáticos
- \`src/\`: Código fonte
  - \`components/\`: Componentes React reutilizáveis
  - \`pages/\`: Páginas da aplicação

## Tecnologias utilizadas

- React
- React Router
- CSS puro (sem frameworks)
`
  });
  
  const [currentContent, setCurrentContent] = useState<string>('');
  const [currentLanguage, setCurrentLanguage] = useState<string>('');
  const [fileSearchTerm, setFileSearchTerm] = useState('');
  const [showNewFileDialog, setShowNewFileDialog] = useState(false);
  const [newFileData, setNewFileData] = useState({ name: '', content: '', parentDir: '/projeto-site' });
  
  useEffect(() => {
    if (activeFile) {
      setCurrentContent(fileContents[activeFile] || '');
      
      // Set the language based on file extension
      const extension = activeFile.split('.').pop() || '';
      setCurrentLanguage(extension);
    }
  }, [activeFile, fileContents]);
  
  const handleFileClick = (filePath: string, language?: string) => {
    setActiveFile(filePath);
    if (!openFiles.includes(filePath)) {
      setOpenFiles([...openFiles, filePath]);
    }
  };
  
  const handleTabClick = (filePath: string) => {
    setActiveFile(filePath);
  };
  
  const handleTabClose = (filePath: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newOpenFiles = openFiles.filter(f => f !== filePath);
    setOpenFiles(newOpenFiles);
    
    if (activeFile === filePath) {
      setActiveFile(newOpenFiles.length > 0 ? newOpenFiles[newOpenFiles.length - 1] : null);
    }
  };
  
  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (activeFile) {
      const newContent = e.target.value;
      setCurrentContent(newContent);
      setFileContents(prev => ({
        ...prev,
        [activeFile]: newContent
      }));
    }
  };
  
  const getLanguageClassForSyntaxHighlighting = () => {
    switch(currentLanguage) {
      case 'html': return 'language-html';
      case 'css': return 'language-css';
      case 'js': case 'javascript': return 'language-javascript';
      case 'jsx': return 'language-jsx';
      case 'json': return 'language-json';
      case 'md': case 'markdown': return 'language-markdown';
      default: return 'language-plaintext';
    }
  };
  
  const getFileIcon = (fileName: string, type: 'file' | 'directory') => {
    if (type === 'directory') return 'ri-folder-line';
    
    const extension = fileName.split('.').pop() || '';
    switch(extension) {
      case 'html': return 'ri-html5-line';
      case 'css': return 'ri-css3-line';
      case 'js': case 'jsx': return 'ri-javascript-line';
      case 'json': return 'ri-file-code-line';
      case 'md': return 'ri-markdown-line';
      case 'svg': return 'ri-image-line';
      default: return 'ri-file-line';
    }
  };
  
  const getFileLanguageBadge = (language?: string) => {
    if (!language) return null;
    
    const languageColors: Record<string, string> = {
      html: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
      css: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      javascript: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      jsx: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      json: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      markdown: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      svg: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200'
    };
    
    return (
      <Badge className={`ml-1 text-xs ${languageColors[language] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'}`}>
        {language}
      </Badge>
    );
  };
  
  const renderFileStructure = (nodes: FileNode[], level = 0) => {
    const filteredNodes = nodes.filter(node => 
      node.name.toLowerCase().includes(fileSearchTerm.toLowerCase()) ||
      (node.children && node.children.some(child => 
        child.name.toLowerCase().includes(fileSearchTerm.toLowerCase())
      ))
    );
    
    return (
      <ul className={`pl-${level > 0 ? 4 : 0} space-y-1`}>
        {filteredNodes.map(node => (
          <li key={node.path}>
            <div 
              className={`flex items-center space-x-2 p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer ${activeFile === node.path ? 'bg-gray-100 dark:bg-gray-800' : ''}`}
              onClick={() => node.type === 'file' ? handleFileClick(node.path, node.language) : undefined}
            >
              <i className={`${getFileIcon(node.name, node.type)} text-gray-500 dark:text-gray-400`}></i>
              <span className="text-sm">{node.name}</span>
              {node.type === 'file' && getFileLanguageBadge(node.language)}
            </div>
            {node.children && node.children.length > 0 && renderFileStructure(node.children, level + 1)}
          </li>
        ))}
      </ul>
    );
  };
  
  const handleCreateNewFile = () => {
    // Validate file name
    if (!newFileData.name.trim()) {
      alert("O nome do arquivo não pode estar vazio");
      return;
    }
    
    // Create new file path
    const newFilePath = `${newFileData.parentDir}/${newFileData.name}`;
    
    // Add file to structure
    const extension = newFileData.name.split('.').pop() || '';
    const language = extension === 'js' ? 'javascript' : extension;
    
    // Update file structure (simplified - in real app would be more complex)
    // This is just a basic implementation
    const addFileToStructure = (nodes: FileNode[], parentPath: string): FileNode[] => {
      return nodes.map(node => {
        if (node.path === parentPath) {
          return {
            ...node,
            children: [
              ...(node.children || []),
              {
                name: newFileData.name,
                type: 'file',
                path: newFilePath,
                language
              }
            ]
          };
        } else if (node.children) {
          return {
            ...node,
            children: addFileToStructure(node.children, parentPath)
          };
        }
        return node;
      });
    };
    
    setFileStructure(addFileToStructure(fileStructure, newFileData.parentDir));
    
    // Add file content
    setFileContents(prev => ({
      ...prev,
      [newFilePath]: newFileData.content
    }));
    
    // Open the new file
    handleFileClick(newFilePath, language);
    
    // Close dialog and reset form
    setShowNewFileDialog(false);
    setNewFileData({ name: '', content: '', parentDir: '/projeto-site' });
  };

  return (
    <>
      <Header 
        title="Editor de Código" 
        actions={
          <div className="flex space-x-2">
            <Button 
              size="sm"
              onClick={() => setShowNewFileDialog(true)}
              className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
            >
              <i className="ri-add-line mr-1.5"></i>
              Novo Arquivo
            </Button>
            <Button 
              size="sm"
              variant="outline"
            >
              <i className="ri-git-branch-line mr-1.5"></i>
              Git
            </Button>
            <Button 
              size="sm"
              variant="outline"
            >
              <i className="ri-terminal-line mr-1.5"></i>
              Terminal
            </Button>
          </div>
        }
      />

      <main className="max-w-full mx-auto px-4 sm:px-6 lg:px-8 py-4 h-[calc(100vh-64px-2rem)]">
        <div className="grid grid-cols-[300px_1fr] gap-4 h-full">
          {/* Sidebar */}
          <div className="h-full overflow-auto">
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Explorador de Arquivos</CardTitle>
                <div className="mt-2 relative">
                  <Input
                    type="text"
                    placeholder="Buscar arquivos..."
                    value={fileSearchTerm}
                    onChange={(e) => setFileSearchTerm(e.target.value)}
                    className="w-full"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <i className="ri-search-line text-gray-400"></i>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-2 h-[calc(100%-80px)] overflow-auto">
                {renderFileStructure(fileStructure)}
              </CardContent>
            </Card>
          </div>
          
          {/* Editor */}
          <div className="h-full overflow-hidden flex flex-col">
            <Card className="h-full">
              <CardHeader className="pb-0 flex-none">
                <Tabs defaultValue={activeFile || 'welcome'} className="w-full overflow-x-auto">
                  <TabsList className="flex w-full justify-start h-10">
                    {openFiles.length === 0 ? (
                      <TabsTrigger value="welcome" className="flex items-center">
                        <i className="ri-home-line mr-1.5"></i>
                        Início
                      </TabsTrigger>
                    ) : (
                      openFiles.map(filePath => {
                        const fileName = filePath.split('/').pop() || '';
                        const fileIcon = getFileIcon(fileName, 'file');
                        
                        return (
                          <TabsTrigger 
                            key={filePath}
                            value={filePath}
                            className="flex items-center relative pr-8"
                            onClick={() => handleTabClick(filePath)}
                          >
                            <i className={`${fileIcon} mr-1.5`}></i>
                            {fileName}
                            <button
                              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                              onClick={(e) => handleTabClose(filePath, e)}
                            >
                              <i className="ri-close-line"></i>
                            </button>
                          </TabsTrigger>
                        );
                      })
                    )}
                  </TabsList>
                  
                  {openFiles.map(filePath => (
                    <TabsContent 
                      key={filePath} 
                      value={filePath}
                      className="pt-0 h-[calc(100%-50px)] overflow-hidden flex flex-col data-[state=active]:flex"
                    >
                      <div className="p-2 bg-gray-100 dark:bg-gray-800 text-xs flex items-center">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">Caminho:</span>
                          <span className="text-gray-600 dark:text-gray-400">{filePath}</span>
                        </div>
                        <div className="ml-auto flex items-center space-x-2">
                          <button className="px-2 py-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700">
                            <i className="ri-save-line mr-1"></i>
                            Salvar
                          </button>
                          <button className="px-2 py-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700">
                            <i className="ri-format-line mr-1"></i>
                            Formatar
                          </button>
                        </div>
                      </div>
                      <div className="flex-grow relative overflow-hidden">
                        <div className="absolute inset-0">
                          <textarea
                            value={fileContents[filePath] || ''}
                            onChange={handleContentChange}
                            className="w-full h-full p-4 font-mono text-sm resize-none outline-none border-none bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100"
                            spellCheck="false"
                          ></textarea>
                        </div>
                      </div>
                    </TabsContent>
                  ))}
                  
                  {openFiles.length === 0 && (
                    <TabsContent 
                      value="welcome"
                      className="flex flex-col items-center justify-center h-[calc(100%-50px)]"
                    >
                      <div className="text-center max-w-md">
                        <div className="text-6xl mb-4">👋</div>
                        <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">
                          Bem-vindo ao Editor de Código
                        </h3>
                        <p className="text-gray-500 dark:text-gray-400 mb-6">
                          Selecione um arquivo no explorador à esquerda para começar a editar,
                          ou crie um novo arquivo clicando no botão "Novo Arquivo".
                        </p>
                        <Button onClick={() => setShowNewFileDialog(true)}>
                          <i className="ri-add-line mr-1.5"></i>
                          Criar Novo Arquivo
                        </Button>
                      </div>
                    </TabsContent>
                  )}
                </Tabs>
              </CardHeader>
            </Card>
          </div>
        </div>
      </main>
      
      {/* New File Dialog */}
      <Dialog open={showNewFileDialog} onOpenChange={setShowNewFileDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Criar Novo Arquivo</DialogTitle>
            <DialogDescription>
              Crie um novo arquivo no projeto. Certifique-se de incluir a extensão apropriada.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="file-name">Nome do Arquivo</Label>
              <Input 
                id="file-name" 
                placeholder="exemplo.js" 
                value={newFileData.name}
                onChange={(e) => setNewFileData({...newFileData, name: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="file-content">Conteúdo Inicial</Label>
              <textarea
                id="file-content"
                placeholder="// Seu código aqui"
                rows={5}
                className="w-full p-2 border rounded-md resize-none"
                value={newFileData.content}
                onChange={(e) => setNewFileData({...newFileData, content: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="parent-dir">Diretório</Label>
              <Select 
                value={newFileData.parentDir}
                onValueChange={(value) => setNewFileData({...newFileData, parentDir: value})}
              >
                <SelectTrigger id="parent-dir">
                  <SelectValue placeholder="Selecione um diretório" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="/projeto-site">/ (raiz)</SelectItem>
                  <SelectItem value="/projeto-site/public">/public</SelectItem>
                  <SelectItem value="/projeto-site/public/assets">/public/assets</SelectItem>
                  <SelectItem value="/projeto-site/src">/src</SelectItem>
                  <SelectItem value="/projeto-site/src/components">/src/components</SelectItem>
                  <SelectItem value="/projeto-site/src/pages">/src/pages</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowNewFileDialog(false)}
            >
              Cancelar
            </Button>
            <Button onClick={handleCreateNewFile}>
              Criar Arquivo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}