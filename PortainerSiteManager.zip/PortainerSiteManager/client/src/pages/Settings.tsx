import { useState, useEffect } from "react";
import Header from "@/components/Header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";

export default function Settings() {
  const [monetizzeApiKey, setMonetizzeApiKey] = useState('');
  const [monetizzeConfigured, setMonetizzeConfigured] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  // Carregar configuração atual da Monetizze ao iniciar a página
  useEffect(() => {
    checkMonetizzeConfig();
  }, []);

  // Verificar se a API da Monetizze está configurada
  const checkMonetizzeConfig = async () => {
    try {
      const response = await apiRequest('GET', '/api/monetizze/config/status');
      const data = await response.json();
      setMonetizzeConfigured(data.configured);
    } catch (error) {
      console.error('Erro ao verificar configuração da Monetizze:', error);
    }
  };

  // Salvar a configuração da API da Monetizze
  const saveMonetizzeConfig = async () => {
    if (!monetizzeApiKey.trim()) {
      setMessage({
        type: 'error',
        text: 'Por favor, insira uma chave API válida.'
      });
      return;
    }

    setIsLoading(true);
    setMessage(null);

    try {
      const response = await apiRequest('POST', '/api/monetizze/config', {
        apiKey: monetizzeApiKey
      });
      
      const data = await response.json();
      
      if (data.success) {
        setMessage({
          type: 'success',
          text: 'Configuração da API Monetizze atualizada com sucesso!'
        });
        setMonetizzeConfigured(true);
      } else {
        setMessage({
          type: 'error',
          text: data.error || 'Erro ao salvar a configuração da API.'
        });
      }
    } catch (error) {
      setMessage({
        type: 'error',
        text: 'Erro ao comunicar com o servidor. Tente novamente mais tarde.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Header title="Configurações" />

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="general" className="w-full">
          <TabsList className="mb-8">
            <TabsTrigger value="general">Geral</TabsTrigger>
            <TabsTrigger value="account">Conta</TabsTrigger>
            <TabsTrigger value="appearance">Aparência</TabsTrigger>
            <TabsTrigger value="notifications">Notificações</TabsTrigger>
            <TabsTrigger value="integrations">Integrações</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>Configurações Gerais</CardTitle>
                <CardDescription>Gerencie as configurações e preferências da plataforma</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="company-name">Nome da Empresa</Label>
                  <Input id="company-name" defaultValue="SiteBuilder" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">Isso será exibido na interface e nos e-mails.</p>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label htmlFor="default-domain">Domínio Padrão</Label>
                  <Input id="default-domain" defaultValue="example.com" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">Subdomínios serão criados sob este domínio.</p>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="auto-deploy">Implantação Automática</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Implante sites automaticamente quando as alterações forem salvas.</p>
                  </div>
                  <Switch id="auto-deploy" defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="cache">Cache de Templates</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Armazene templates em cache para melhorar o tempo de carregamento.</p>
                  </div>
                  <Switch id="cache" defaultChecked />
                </div>
                
                <Separator />
                
                <Button>Salvar Alterações</Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Configurações da Conta</CardTitle>
                <CardDescription>Gerencie suas informações de conta</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="username">Nome de Usuário</Label>
                  <Input id="username" defaultValue="admin" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input id="email" defaultValue="admin@example.com" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Senha</Label>
                  <Input id="password" type="password" defaultValue="********" />
                </div>
                
                <Separator />
                
                <Button>Atualizar Conta</Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="appearance">
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Aparência</CardTitle>
                <CardDescription>Personalize a aparência da aplicação</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Tema</Label>
                  <div className="flex space-x-4">
                    <Button variant="outline" className="bg-white text-black border-gray-200">Claro</Button>
                    <Button variant="outline" className="bg-gray-900 text-white border-gray-700">Escuro</Button>
                    <Button variant="outline" className="bg-gradient-to-r from-gray-100 to-gray-900 text-black border-gray-200">Automático</Button>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label>Cor de Destaque</Label>
                  <div className="flex space-x-4">
                    <div className="w-8 h-8 rounded-full bg-blue-500 cursor-pointer"></div>
                    <div className="w-8 h-8 rounded-full bg-green-500 cursor-pointer"></div>
                    <div className="w-8 h-8 rounded-full bg-purple-500 cursor-pointer"></div>
                    <div className="w-8 h-8 rounded-full bg-red-500 cursor-pointer"></div>
                    <div className="w-8 h-8 rounded-full bg-amber-500 cursor-pointer"></div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="animations">Animações de Interface</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Ativar animações na interface do usuário.</p>
                  </div>
                  <Switch id="animations" defaultChecked />
                </div>
                
                <Separator />
                
                <Button>Salvar Aparência</Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Notificações</CardTitle>
                <CardDescription>Controle como você recebe notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="deploy-notifications">Notificações de Implantação</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Receba notificações para implantações de sites.</p>
                  </div>
                  <Switch id="deploy-notifications" defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="update-notifications">Notificações de Atualização</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Receba notificações para atualizações de conteúdo.</p>
                  </div>
                  <Switch id="update-notifications" defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications">Notificações por E-mail</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Envie notificações para seu e-mail.</p>
                  </div>
                  <Switch id="email-notifications" defaultChecked />
                </div>
                
                <Separator />
                
                <Button>Salvar Configurações de Notificações</Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="integrations">
            <Card>
              <CardHeader>
                <CardTitle>Integrações com Plataformas</CardTitle>
                <CardDescription>Configure integrações com plataformas de pagamento e serviços</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {message && (
                  <Alert variant={message.type === 'success' ? 'default' : 'destructive'} className="mb-6">
                    <AlertTitle>{message.type === 'success' ? 'Sucesso' : 'Erro'}</AlertTitle>
                    <AlertDescription>{message.text}</AlertDescription>
                  </Alert>
                )}
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">Monetizze</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Integração com a plataforma Monetizze para transações no marketplace
                      </p>
                    </div>
                    
                    <Badge 
                      className={monetizzeConfigured 
                        ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" 
                        : "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                      }
                    >
                      {monetizzeConfigured ? 'Configurado' : 'Não Configurado'}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="monetizze-api-key">Chave API da Monetizze</Label>
                    <Input 
                      id="monetizze-api-key" 
                      type="password" 
                      placeholder="Digite sua chave API da Monetizze"
                      value={monetizzeApiKey}
                      onChange={(e) => setMonetizzeApiKey(e.target.value)}
                    />
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      A chave API pode ser obtida no painel da Monetizze. Visite a <a href="https://api.monetizze.com.br/2.1/apidoc/" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:underline">documentação da API</a> para mais informações.
                    </p>
                  </div>
                  
                  <Button 
                    onClick={saveMonetizzeConfig} 
                    disabled={isLoading}
                    className="mt-4"
                  >
                    {isLoading ? 'Salvando...' : 'Salvar Configuração'}
                  </Button>
                </div>
                
                <Separator className="my-8" />
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">Outras Plataformas</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Configure integrações adicionais para expandir as funcionalidades
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="border border-gray-200 dark:border-gray-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-md">PayPal</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                          Integração com PayPal para processamento de pagamentos
                        </p>
                        <Button variant="outline" className="w-full">Configurar</Button>
                      </CardContent>
                    </Card>
                    
                    <Card className="border border-gray-200 dark:border-gray-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-md">Google Analytics</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                          Acompanhe estatísticas de tráfego e desempenho
                        </p>
                        <Button variant="outline" className="w-full">Configurar</Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </>
  );
}
