import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { DialogClose } from "@/components/ui/dialog";
import { DnsRecord } from "@shared/schema";
import { AlertTriangle, Code, Copy, ExternalLink, RefreshCw, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TraefikConfigProps {
  dnsRecord: DnsRecord;
  onSave: (config: any) => void;
}

export default function TraefikConfig({ dnsRecord, onSave }: TraefikConfigProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("basic");
  const [useHttps, setUseHttps] = useState(!!dnsRecord.sslEnabled);
  const [redirectToHttps, setRedirectToHttps] = useState(true);
  const [entryPoint, setEntryPoint] = useState("websecure");
  const [customMiddlewares, setCustomMiddlewares] = useState<string[]>([]);
  const [customLabels, setCustomLabels] = useState("");

  // Generate Docker Compose labels
  const generateDockerComposeLabels = () => {
    const domain = dnsRecord.domain;
    const serviceName = domain.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
    
    let labels = [
      `traefik.enable=true`,
      `traefik.http.routers.${serviceName}.rule=Host(\`${domain}\`)`,
    ];
    
    if (useHttps) {
      labels.push(`traefik.http.routers.${serviceName}.entrypoints=${entryPoint}`);
      labels.push(`traefik.http.routers.${serviceName}.tls=true`);
      labels.push(`traefik.http.routers.${serviceName}.tls.certresolver=letsencrypt`);
      
      if (redirectToHttps) {
        const httpServiceName = `${serviceName}Http`;
        labels.push(`traefik.http.routers.${httpServiceName}.rule=Host(\`${domain}\`)`);
        labels.push(`traefik.http.routers.${httpServiceName}.entrypoints=web`);
        labels.push(`traefik.http.middlewares.${serviceName}Https.redirectscheme.scheme=https`);
        labels.push(`traefik.http.middlewares.${serviceName}Https.redirectscheme.permanent=true`);
        labels.push(`traefik.http.routers.${httpServiceName}.middlewares=${serviceName}Https`);
      }
    } else {
      labels.push(`traefik.http.routers.${serviceName}.entrypoints=web`);
    }
    
    // Add custom middlewares if any
    if (customMiddlewares.length > 0) {
      labels.push(`traefik.http.routers.${serviceName}.middlewares=${customMiddlewares.join(',')}`);
    }
    
    // Add port configuration
    labels.push(`traefik.http.services.${serviceName}.loadbalancer.server.port=80`);
    
    return labels;
  };

  // Generate Docker Compose YAML section
  const generateDockerCompose = () => {
    const labels = generateDockerComposeLabels();
    const domain = dnsRecord.domain;
    const serviceName = domain.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
    
    return `
services:
  ${serviceName}:
    image: your-image:latest
    labels:
${labels.map(label => `      - "${label}"`).join('\n')}
    networks:
      - traefik-public
      
networks:
  traefik-public:
    external: true
`;
  };

  // Generate Traefik dynamic config
  const generateTraefikConfig = () => {
    const domain = dnsRecord.domain;
    const serviceName = domain.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
    
    let config: any = {
      http: {
        routers: {
          [serviceName]: {
            rule: `Host(\`${domain}\`)`,
            service: serviceName,
            entrypoints: [useHttps ? entryPoint : "web"]
          }
        },
        services: {
          [serviceName]: {
            loadBalancer: {
              servers: [
                { url: "http://yourcontainer:80/" }
              ]
            }
          }
        }
      }
    };
    
    if (useHttps) {
      if (!config.http.routers[serviceName].tls) {
        config.http.routers[serviceName].tls = {};
      }
      config.http.routers[serviceName].tls.certResolver = "letsencrypt";
      
      if (redirectToHttps) {
        const httpServiceName = `${serviceName}Http`;
        
        config.http.routers[httpServiceName] = {
          rule: `Host(\`${domain}\`)`,
          service: serviceName,
          entrypoints: ["web"]
        };
        
        // Add middlewares property to router
        if (!config.http.routers[httpServiceName].middlewares) {
          config.http.routers[httpServiceName].middlewares = [];
        }
        config.http.routers[httpServiceName].middlewares.push(`${serviceName}Https`);
        
        // Add middlewares section to config
        if (!config.http.middlewares) {
          config.http.middlewares = {};
        }
        
        config.http.middlewares[`${serviceName}Https`] = {
          redirectScheme: {
            scheme: "https",
            permanent: true
          }
        };
      }
    }
    
    return JSON.stringify(config, null, 2);
  };

  const copyToClipboard = (text: string, message: string) => {
    navigator.clipboard.writeText(text).then(
      () => {
        toast({
          title: "Copiado com sucesso",
          description: message,
          variant: "default",
        });
      },
      (err) => {
        toast({
          title: "Erro ao copiar",
          description: "Não foi possível copiar para a área de transferência.",
          variant: "destructive",
        });
      }
    );
  };

  const processCustomLabels = () => {
    if (!customLabels || customLabels.trim() === '') {
      return [];
    }
    
    return customLabels
      .split('\n')
      .filter(line => line.trim() !== '')
      .map(line => line.trim());
  };
  
  const handleSave = () => {
    const processedCustomLabels = processCustomLabels();
    
    const config = {
      useHttps,
      redirectToHttps,
      entryPoint,
      customMiddlewares,
      customLabels: processedCustomLabels,
      traefikConfig: {
        labels: generateDockerComposeLabels(),
        dockerCompose: generateDockerCompose(),
        dynamicConfig: generateTraefikConfig()
      }
    };
    
    onSave(config);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Configuração Traefik para {dnsRecord.domain}</CardTitle>
        <CardDescription>
          Configure as opções de roteamento Traefik para este domínio
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="basic">Configuração Básica</TabsTrigger>
            <TabsTrigger value="advanced">Código Gerado</TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic">
            <div className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="https">Usar HTTPS</Label>
                  <p className="text-sm text-muted-foreground">
                    Habilitar TLS com Let's Encrypt
                  </p>
                </div>
                <Switch
                  id="https"
                  checked={useHttps}
                  onCheckedChange={setUseHttps}
                />
              </div>
              
              {useHttps && (
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="redirect">Redirecionar HTTP para HTTPS</Label>
                    <p className="text-sm text-muted-foreground">
                      Redirecionar automaticamente as requisições HTTP para HTTPS
                    </p>
                  </div>
                  <Switch
                    id="redirect"
                    checked={redirectToHttps}
                    onCheckedChange={setRedirectToHttps}
                  />
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="entrypoint">Entrypoint</Label>
                <Input
                  id="entrypoint"
                  value={entryPoint}
                  onChange={(e) => setEntryPoint(e.target.value)}
                  placeholder="websecure"
                />
                <p className="text-xs text-muted-foreground">
                  Entrypoint do Traefik para HTTPS (padrão: websecure)
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="customLabels">Labels personalizadas</Label>
                <Textarea
                  id="customLabels"
                  value={customLabels}
                  onChange={(e) => setCustomLabels(e.target.value)}
                  placeholder="traefik.http.middlewares.gzip.compress=true"
                  className="min-h-[100px]"
                />
                <p className="text-xs text-muted-foreground">
                  Adicione labels personalizadas para configuração avançada do Traefik (uma por linha)
                </p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="advanced">
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="labels">Labels do Docker Compose</Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(
                      generateDockerComposeLabels().join('\n'), 
                      "Labels do Docker Compose copiadas para a área de transferência"
                    )}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copiar
                  </Button>
                </div>
                <div className="relative">
                  <pre className="font-mono text-xs p-4 rounded-md bg-secondary overflow-auto max-h-[200px]">
                    {generateDockerComposeLabels().join('\n')}
                  </pre>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="docker-compose">Docker Compose</Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(
                      generateDockerCompose(), 
                      "Configuração Docker Compose copiada para a área de transferência"
                    )}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copiar
                  </Button>
                </div>
                <div className="relative">
                  <pre className="font-mono text-xs p-4 rounded-md bg-secondary overflow-auto max-h-[200px]">
                    {generateDockerCompose()}
                  </pre>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="traefik-config">Configuração Dinâmica do Traefik (JSON)</Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(
                      generateTraefikConfig(), 
                      "Configuração dinâmica do Traefik copiada para a área de transferência"
                    )}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copiar
                  </Button>
                </div>
                <div className="relative">
                  <pre className="font-mono text-xs p-4 rounded-md bg-secondary overflow-auto max-h-[200px]">
                    {generateTraefikConfig()}
                  </pre>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <DialogClose asChild>
          <Button variant="outline">Cancelar</Button>
        </DialogClose>
        <Button onClick={handleSave}>
          <CheckCircle2 className="h-4 w-4 mr-2" />
          Salvar Configuração
        </Button>
      </CardFooter>
    </Card>
  );
}