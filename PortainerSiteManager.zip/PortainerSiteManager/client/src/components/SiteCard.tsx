import { useState } from "react";
import { Website } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { Eye, Edit, Settings, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

interface SiteCardProps {
  site: Website;
  onEdit?: () => void;
}

export default function SiteCard({ site, onEdit }: SiteCardProps) {
  const { toast } = useToast();
  const [isHovered, setIsHovered] = useState(false);

  const handlePreview = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(`https://${site.domain}`, '_blank');
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEdit) {
      onEdit();
    } else {
      toast({
        title: "Editar Site",
        description: `Abrindo editor para ${site.name}`,
      });
    }
  };

  const handleSettings = (e: React.MouseEvent) => {
    e.stopPropagation();
    toast({
      title: "Configurações do Site",
      description: `Abrindo configurações para ${site.name}`,
    });
  };

  return (
    <Card 
      className="overflow-hidden group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-40 bg-gray-200 dark:bg-gray-700">
        {site.thumbnail ? (
          <div
            className="w-full h-full bg-cover bg-center"
            style={{ backgroundImage: `url(${site.thumbnail})` }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 dark:text-gray-500">
            <i className="ri-global-line text-4xl"></i>
          </div>
        )}
        <div className={cn(
          "absolute inset-0 bg-black transition-all flex items-center justify-center",
          isHovered ? "bg-opacity-30 opacity-100" : "bg-opacity-0 opacity-0"
        )}>
          <Button variant="secondary" size="icon" className="mr-2" onClick={handlePreview}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="secondary" size="icon" className="mr-2" onClick={handleEdit}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="secondary" size="icon" onClick={handleSettings}>
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-center">
          <h3 className="font-semibold text-gray-900 dark:text-white">{site.name}</h3>
          <Badge className={
            site.status === "published" 
              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" 
              : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
          }>
            {site.status === "published" ? "Ativo" : "Rascunho"}
          </Badge>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{site.domain}</p>
        <div className="mt-4 flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            <i className="ri-eye-line mr-1.5"></i>
            <span>{site.views ? `${site.views.toLocaleString()} visualizações` : 'N/A'}</span>
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Atualizado {formatDistanceToNow(new Date(site.updatedAt), { addSuffix: true, locale: ptBR })}
          </div>
        </div>
      </div>
    </Card>
  );
}
