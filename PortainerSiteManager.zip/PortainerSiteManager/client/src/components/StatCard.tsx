import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number | undefined;
  icon: string;
  iconColor: 'blue' | 'green' | 'amber' | 'purple' | 'red';
  change?: number;
  changeText?: string;
  text?: string;
}

export default function StatCard({ 
  title, 
  value, 
  icon, 
  iconColor, 
  change, 
  changeText,
  text
}: StatCardProps) {
  const colorClasses = {
    blue: {
      bg: 'bg-blue-100 dark:bg-blue-900',
      text: 'text-blue-500 dark:text-blue-300'
    },
    green: {
      bg: 'bg-green-100 dark:bg-green-900',
      text: 'text-green-500 dark:text-green-300'
    },
    amber: {
      bg: 'bg-amber-100 dark:bg-amber-900',
      text: 'text-amber-500 dark:text-amber-300'
    },
    purple: {
      bg: 'bg-purple-100 dark:bg-purple-900',
      text: 'text-purple-500 dark:text-purple-300'
    },
    red: {
      bg: 'bg-red-100 dark:bg-red-900',
      text: 'text-red-500 dark:text-red-300'
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div className="flex items-center">
        <div className={cn(
          "p-3 rounded-full mr-4",
          colorClasses[iconColor].bg,
          colorClasses[iconColor].text
        )}>
          <i className={cn(icon, "text-xl")}></i>
        </div>
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-semibold text-gray-900 dark:text-white">{value}</p>
        </div>
      </div>
      <div className="mt-4">
        {change !== undefined ? (
          <div className="flex items-center">
            <span className="text-green-500 text-sm font-medium flex items-center">
              <i className="ri-arrow-up-line mr-1"></i> {change}%
            </span>
            {changeText && (
              <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">{changeText}</span>
            )}
          </div>
        ) : text ? (
          <div className="text-gray-500 dark:text-gray-400 text-sm">{text}</div>
        ) : null}
      </div>
    </div>
  );
}
