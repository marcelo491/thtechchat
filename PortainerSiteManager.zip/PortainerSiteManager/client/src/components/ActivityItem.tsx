import { Activity } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface ActivityItemProps {
  activity: Activity;
}

export default function ActivityItem({ activity }: ActivityItemProps) {
  const iconColorClasses = {
    deploy: "bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-300",
    update: "bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300",
    create: activity.entityType === "template" 
      ? "bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300" 
      : "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300",
    delete: "bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-300"
  };

  return (
    <div className="flex">
      <div className={cn(
        "flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center",
        iconColorClasses[activity.type as keyof typeof iconColorClasses] || "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
      )}>
        <i className={activity.icon || "ri-question-line"}></i>
      </div>
      <div className="ml-4 flex-1">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-900 dark:text-white">
            {activity.type === "deploy" && "Site Implantado"}
            {activity.type === "update" && "Conteúdo Atualizado"}
            {activity.type === "create" && activity.entityType === "template" && "Modelo Criado"}
            {activity.type === "create" && activity.entityType === "website" && "Site Criado"}
            {activity.type === "delete" && "Item Excluído"}
          </h3>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true, locale: ptBR })}
          </span>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          {activity.description}
        </p>
      </div>
    </div>
  );
}
