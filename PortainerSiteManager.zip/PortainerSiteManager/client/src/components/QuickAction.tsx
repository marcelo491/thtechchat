import { cn } from "@/lib/utils";
import { Link } from "wouter";

interface QuickActionProps {
  title: string;
  description: string;
  icon: string;
  iconColor: 'primary' | 'green' | 'purple' | 'amber' | 'red';
  href: string;
}

export default function QuickAction({ 
  title, 
  description, 
  icon, 
  iconColor, 
  href 
}: QuickActionProps) {
  const colorClasses = {
    primary: {
      bg: 'bg-primary-100 dark:bg-primary-900',
      text: 'text-primary-600 dark:text-primary-300'
    },
    green: {
      bg: 'bg-green-100 dark:bg-green-900',
      text: 'text-green-600 dark:text-green-300'
    },
    purple: {
      bg: 'bg-purple-100 dark:bg-purple-900',
      text: 'text-purple-600 dark:text-purple-300'
    },
    amber: {
      bg: 'bg-amber-100 dark:bg-amber-900',
      text: 'text-amber-600 dark:text-amber-300'
    },
    red: {
      bg: 'bg-red-100 dark:bg-red-900',
      text: 'text-red-600 dark:text-red-300'
    }
  };

  return (
    <Link href={href}>
      <div className="block p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 transition-all cursor-pointer">
        <div className="flex items-center">
          <div className={cn(
            "flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center mr-4",
            colorClasses[iconColor].bg,
            colorClasses[iconColor].text
          )}>
            <i className={cn(icon, "text-xl")}></i>
          </div>
          <div>
            <h3 className="text-base font-medium text-gray-900 dark:text-white">{title}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{description}</p>
          </div>
        </div>
      </div>
    </Link>
  );
}
