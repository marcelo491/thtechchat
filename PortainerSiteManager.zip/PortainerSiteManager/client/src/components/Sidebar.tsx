import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { MenuIcon, X, LogOut } from "lucide-react";
import { THLogo } from "@/assets/logo.tsx";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

interface NavItem {
  name: string;
  href: string;
  icon: string;
}

export default function Sidebar({ mobileMenuOpen, setMobileMenuOpen }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const mainNavItems: NavItem[] = [
    { name: 'Painel', href: '/dashboard', icon: 'ri-dashboard-line' },
    { name: 'Sites', href: '/websites', icon: 'ri-global-line' },
    { name: 'Modelos', href: '/templates', icon: 'ri-file-list-3-line' },
    { name: 'Componentes', href: '/components', icon: 'ri-puzzle-piece-line' },
    { name: 'Marketplace', href: '/marketplace', icon: 'ri-store-2-line' },
    { name: 'Editor de Código', href: '/code-editor', icon: 'ri-code-box-line' },
  ];

  const infraNavItems: NavItem[] = [
    { name: 'Contêineres', href: '/containers', icon: 'ri-server-line' },
    { name: 'Backups', href: '/backups', icon: 'ri-database-2-line' },
    { name: 'DNS', href: '/dns', icon: 'ri-global-fill' },
    { name: 'Análises', href: '/analytics', icon: 'ri-line-chart-line' },
  ];

  const settingsNavItems: NavItem[] = [
    { name: 'Configurações', href: '/settings', icon: 'ri-settings-line' },
    { name: 'Implantações', href: '/deployments', icon: 'ri-rocket-line' },
    { name: 'Gestão de Usuários', href: '/user-management', icon: 'ri-user-settings-line' },
  ];

  return (
    <div 
      className={cn(
        "bg-gray-800 dark:bg-gray-850 text-white md:w-64 w-full md:min-h-screen overflow-y-auto transition-all duration-300 ease-in-out",
        mobileMenuOpen ? "block" : "hidden md:block"
      )}
    >
      <div className="p-4 flex items-center justify-between border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <div className="h-8 w-8 bg-white rounded-md flex items-center justify-center p-0.5">
                <THLogo width={28} height={28} />
              </div>
            </div>
          </Link>
          <h1 className="text-xl font-bold text-white hidden sm:block">THTech Web Studio</h1>
          <h1 className="text-xl font-bold text-white sm:hidden">THTech</h1>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          className="md:hidden text-gray-400 hover:text-white"
          onClick={() => setMobileMenuOpen(false)}
        >
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      <nav className="py-4">
        <div className="px-4 py-2 text-xs uppercase text-gray-400 font-semibold">Principal</div>
        
        {mainNavItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div 
              className={cn(
                "flex items-center px-4 py-2.5 text-sm mb-1 cursor-pointer",
                location === item.href || (item.href === '/dashboard' && location === '/') 
                  ? "text-white bg-primary-600" 
                  : "text-gray-300 hover:bg-gray-700"
              )}
            >
              <i className={cn(item.icon, "text-lg mr-3")}></i>
              <span>{item.name}</span>
            </div>
          </Link>
        ))}
        
        <div className="px-4 py-2 mt-6 text-xs uppercase text-gray-400 font-semibold">Infraestrutura</div>
        
        {infraNavItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div 
              className={cn(
                "flex items-center px-4 py-2.5 text-sm mb-1 cursor-pointer",
                location === item.href
                  ? "text-white bg-primary-600" 
                  : "text-gray-300 hover:bg-gray-700"
              )}
            >
              <i className={cn(item.icon, "text-lg mr-3")}></i>
              <span>{item.name}</span>
            </div>
          </Link>
        ))}
        
        <div className="px-4 py-2 mt-6 text-xs uppercase text-gray-400 font-semibold">Configurações</div>
        
        {settingsNavItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div 
              className={cn(
                "flex items-center px-4 py-2.5 text-sm mb-1 cursor-pointer",
                location === item.href 
                  ? "text-white bg-primary-600" 
                  : "text-gray-300 hover:bg-gray-700"
              )}
            >
              <i className={cn(item.icon, "text-lg mr-3")}></i>
              <span>{item.name}</span>
            </div>
          </Link>
        ))}
      </nav>
      
      <div className="mt-auto p-4 border-t border-gray-700">
        <div className="flex items-center">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-primary-700 text-white text-sm">
              {user?.username?.charAt(0).toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="ml-3">
            <p className="text-sm font-medium text-white">{user?.fullName || user?.username}</p>
            <p className="text-xs text-gray-400">{user?.email}</p>
          </div>
          <div className="ml-auto">
            <Button 
              variant="ghost" 
              size="sm"
              className="text-gray-400 hover:text-white"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              {logoutMutation.isPending ? (
                <span className="animate-pulse">...</span>
              ) : (
                <LogOut size={18} />
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
