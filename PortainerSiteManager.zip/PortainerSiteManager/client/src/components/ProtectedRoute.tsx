import { ReactNode } from "react";
import { Route, Redirect, useRoute } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  path: string;
  component: React.ComponentType<any>;
  roles?: string[];
}

export default function ProtectedRoute({ 
  path, 
  component: Component,
  roles = [] 
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  
  const hasRequiredRole = roles.length === 0 || (user && roles.includes(user.role));

  // Componente para renderizar quando o usuário está autenticado
  const AuthenticatedComponent = () => {
    return <Component />;
  };

  // Componente para renderizar durante o carregamento
  const LoadingComponent = () => {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  };

  // Componente para redirecionamento quando não autorizado
  const RedirectComponent = () => {
    return <Redirect to="/auth" />;
  };

  if (isLoading) {
    return <Route path={path} component={LoadingComponent} />;
  }

  if (!user || !hasRequiredRole) {
    return <Route path={path} component={RedirectComponent} />;
  }

  return <Route path={path} component={AuthenticatedComponent} />;
}