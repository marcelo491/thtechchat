import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { X, Eye, ArrowLeft, ArrowRight, RotateCcw, Computer, Tablet, Smartphone, Code } from "lucide-react";
import { useEditor } from "@/hooks/useEditor";
import { Website, insertWebsiteSchema } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface SiteEditorProps {
  isOpen: boolean;
  onClose: () => void;
  site?: Website | null;
}

const FormSchema = insertWebsiteSchema.extend({
  name: z.string().min(3, "O nome deve ter pelo menos 3 caracteres"),
  domain: z.string().optional(),
  status: z.enum(["draft", "published", "archived"]),
  content: z.any().optional(),
});

type FormValues = z.infer<typeof FormSchema>;

export default function SiteEditor({ isOpen, onClose, site }: SiteEditorProps) {
  const { toast } = useToast();
  const { components, isLoading } = useEditor();
  const [previewMode, setPreviewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isCodeView, setIsCodeView] = useState(false);
  const [selectedComponentType, setSelectedComponentType] = useState<string | null>(null);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      name: site?.name || "",
      domain: site?.domain || "",
      status: (site?.status as "draft" | "published" | "archived") || "draft",
      content: site?.content || {},
      userId: site?.userId || 1,
    },
  });

  useEffect(() => {
    if (site) {
      form.reset({
        name: site.name,
        domain: site.domain || "",
        status: (site.status as "draft" | "published" | "archived"),
        content: site.content || {},
        userId: site.userId,
      });
    }
  }, [site, form]);

  const onSubmit = async (data: FormValues) => {
    try {
      if (site) {
        // Update existing site
        await apiRequest("PUT", `/api/websites/${site.id}`, data);
        toast({
          title: "Site atualizado",
          description: "Seu site foi atualizado com sucesso.",
        });
      } else {
        // Create new site
        await apiRequest("POST", "/api/websites", data);
        toast({
          title: "Site criado",
          description: "Seu novo site foi criado com sucesso.",
        });
      }
      
      // Invalidate the websites query to fetch updated data
      queryClient.invalidateQueries({ queryKey: ['/api/websites'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      
      onClose();
    } catch (error) {
      console.error("Falha ao salvar o site:", error);
      toast({
        title: "Erro",
        description: "Falha ao salvar o site. Por favor, tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-6xl h-[85vh] p-0 flex flex-col">
        <div className="border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {site ? `Editando: ${site.name}` : "Criar Novo Site"}
            </h3>
            {site && (
              <div className="ml-4 flex">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  site.status === "published" 
                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" 
                    : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                }`}>
                  {site.status === "published" ? "Publicado" : "Rascunho"}
                </span>
              </div>
            )}
          </div>
          <div className="flex items-center">
            <Button variant="outline" size="sm" className="mr-2">
              <Eye className="h-4 w-4 mr-1.5" />
              Visualizar
            </Button>
            <Button size="sm" onClick={form.handleSubmit(onSubmit)}>
              Salvar
            </Button>
            <Button variant="ghost" size="sm" className="ml-2" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="editor" className="flex-1 overflow-hidden">
          <TabsList className="px-6 py-2 border-b border-gray-200 dark:border-gray-700">
            <TabsTrigger value="editor">Editor</TabsTrigger>
            <TabsTrigger value="settings">Configurações</TabsTrigger>
            <TabsTrigger value="seo">SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="editor" className="flex-1 overflow-hidden flex">
            {/* Left sidebar (components) */}
            <div className="w-64 border-r border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-850 overflow-y-auto flex flex-col">
              <div className="p-4">
                <div className="relative">
                  <Input 
                    type="text" 
                    placeholder="Buscar componentes..." 
                    className="w-full px-3 py-2 text-sm"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <i className="ri-search-line text-gray-400"></i>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto">
                {isLoading ? (
                  <div className="px-4 space-y-4">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-10 w-full mb-2" />
                    <Skeleton className="h-10 w-full mb-2" />
                    <Skeleton className="h-10 w-full mb-2" />
                    <Skeleton className="h-4 w-24 mt-4 mb-2" />
                    <Skeleton className="h-10 w-full mb-2" />
                    <Skeleton className="h-10 w-full mb-2" />
                  </div>
                ) : (
                  <>
                    <div className="px-4 py-2 text-xs uppercase text-gray-500 dark:text-gray-400 font-semibold">Básico</div>
                    <div className="px-2">
                      {components?.filter(c => c.category === "basic").map(component => (
                        <button 
                          key={component.id}
                          onClick={() => setSelectedComponentType(component.type)}
                          className="w-full text-left p-2 rounded-md flex items-center text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 mb-1"
                        >
                          <i className={`${component.icon} text-lg mr-3`}></i>
                          <span>{component.name}</span>
                        </button>
                      ))}
                    </div>
                    
                    <div className="px-4 py-2 text-xs uppercase text-gray-500 dark:text-gray-400 font-semibold mt-4">Layout</div>
                    <div className="px-2">
                      {components?.filter(c => c.category === "layout").map(component => (
                        <button 
                          key={component.id}
                          onClick={() => setSelectedComponentType(component.type)}
                          className="w-full text-left p-2 rounded-md flex items-center text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 mb-1"
                        >
                          <i className={`${component.icon} text-lg mr-3`}></i>
                          <span>{component.name}</span>
                        </button>
                      ))}
                    </div>
                    
                    <div className="px-4 py-2 text-xs uppercase text-gray-500 dark:text-gray-400 font-semibold mt-4">Componentes</div>
                    <div className="px-2">
                      {components?.filter(c => c.category === "components").map(component => (
                        <button 
                          key={component.id}
                          onClick={() => setSelectedComponentType(component.type)}
                          className="w-full text-left p-2 rounded-md flex items-center text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 mb-1"
                        >
                          <i className={`${component.icon} text-lg mr-3`}></i>
                          <span>{component.name}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
            
            {/* Main content area (canvas) */}
            <div className="flex-1 overflow-auto bg-gray-100 dark:bg-gray-900 flex flex-col">
              <div className="p-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center space-x-3">
                  <Button 
                    variant={previewMode === 'desktop' ? 'secondary' : 'outline'} 
                    size="sm"
                    onClick={() => setPreviewMode('desktop')}
                  >
                    <Computer className="h-4 w-4 mr-1.5" />
                    Desktop
                  </Button>
                  <Button 
                    variant={previewMode === 'tablet' ? 'secondary' : 'outline'} 
                    size="sm"
                    onClick={() => setPreviewMode('tablet')}
                  >
                    <Tablet className="h-4 w-4 mr-1.5" />
                    Tablet
                  </Button>
                  <Button 
                    variant={previewMode === 'mobile' ? 'secondary' : 'outline'} 
                    size="sm"
                    onClick={() => setPreviewMode('mobile')}
                  >
                    <Smartphone className="h-4 w-4 mr-1.5" />
                    Celular
                  </Button>
                </div>
                <div className="flex items-center space-x-3">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setIsCodeView(!isCodeView)}
                  >
                    {isCodeView ? <Eye className="h-4 w-4" /> : <Code className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              
              <div className="flex-1 p-8 overflow-auto">
                <div 
                  className={`bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm
                    ${previewMode === 'desktop' ? 'max-w-full' : previewMode === 'tablet' ? 'max-w-[768px] mx-auto' : 'max-w-[375px] mx-auto'}`}
                  style={{ minHeight: 'calc(100% - 2rem)' }}
                >
                  {isCodeView ? (
                    <div className="p-6 font-mono text-sm">
                      <pre className="p-4 bg-gray-50 dark:bg-gray-900 rounded overflow-auto">
                        {JSON.stringify(form.getValues().content || {}, null, 2)}
                      </pre>
                    </div>
                  ) : site?.content && Object.keys(site.content).length > 0 ? (
                    <div className="p-6">
                      <p className="text-gray-500 dark:text-gray-400">
                        O conteúdo do site será renderizado aqui
                      </p>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 flex flex-col items-center justify-center text-center m-6">
                      <div className="h-16 w-16 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-400 mb-4">
                        <i className="ri-drag-move-line text-2xl"></i>
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Arraste componentes aqui</h3>
                      <p className="text-gray-500 dark:text-gray-400 mb-4 max-w-md">
                        Comece a construir seu site arrastando componentes da barra lateral para esta área.
                      </p>
                      <Button>
                        <i className="ri-layout-top-line mr-1.5"></i>
                        Adicionar Seção Hero
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Right sidebar (properties) */}
            <div className="w-72 border-l border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex flex-col">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <h3 className="font-medium text-gray-900 dark:text-white">Propriedades</h3>
                <div className="flex">
                  <Button variant="ghost" size="icon" className="mr-1">
                    <i className="ri-settings-line text-lg"></i>
                  </Button>
                  <Button variant="ghost" size="icon">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="p-4 overflow-y-auto flex-1">
                {selectedComponentType ? (
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm">Editar Componente</h4>
                    <div className="space-y-2">
                      <Label htmlFor="component-title">Título</Label>
                      <Input id="component-title" placeholder="Título do Componente" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="component-content">Conteúdo</Label>
                      <Input id="component-content" placeholder="Conteúdo" />
                    </div>
                    <div className="space-y-2">
                      <Label>Estilo</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm">Claro</Button>
                        <Button variant="outline" size="sm">Escuro</Button>
                      </div>
                    </div>
                    <Button className="w-full" size="sm">Aplicar Alterações</Button>
                  </div>
                ) : (
                  <>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                      Selecione um elemento para editar suas propriedades.
                    </p>
                    
                    <div className="mt-2 border border-gray-200 dark:border-gray-700 rounded-md p-4 flex flex-col items-center justify-center text-center">
                      <div className="h-12 w-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-400 mb-3">
                        <i className="ri-cursor-line text-xl"></i>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Clique em qualquer elemento para editar suas propriedades e conteúdo.
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="settings" className="p-6 overflow-auto">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome do Site</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Meu Site" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="domain"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Domínio</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="meusite.exemplo.com.br" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="draft">Rascunho</SelectItem>
                          <SelectItem value="published">Publicado</SelectItem>
                          <SelectItem value="archived">Arquivado</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit">Salvar Configurações</Button>
              </form>
            </Form>
          </TabsContent>
          
          <TabsContent value="seo" className="p-6 overflow-auto">
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="meta-title">Título Meta</Label>
                <Input id="meta-title" placeholder="Título da Página" />
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  O título que aparece nos resultados dos motores de busca (recomendado: 50-60 caracteres)
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="meta-description">Descrição Meta</Label>
                <Input id="meta-description" placeholder="Descrição da página" />
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Uma breve descrição que aparece nos resultados de busca (recomendado: 150-160 caracteres)
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="og-image">Imagem Social</Label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                    Arraste uma imagem aqui ou clique para fazer upload
                  </p>
                  <Button variant="outline" size="sm">
                    <i className="ri-upload-line mr-1.5"></i>
                    Fazer Upload
                  </Button>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Imagem que aparece quando compartilhada nas redes sociais (recomendado: 1200x630 pixels)
                </p>
              </div>
              
              <Button>Salvar Configurações SEO</Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
