import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ReactNode } from "react";
import { MenuIcon, BellIcon, SettingsIcon, PlusIcon } from "lucide-react";

interface HeaderProps {
  title: string;
  actions?: ReactNode;
}

export default function Header({ title, actions }: HeaderProps) {
  const [location] = useLocation();

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white">{title}</h2>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-gray-500 hover:text-gray-700 dark:text-gray-300 dark:hover:text-white"
            >
              <BellIcon className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              className="text-gray-500 hover:text-gray-700 dark:text-gray-300 dark:hover:text-white"
            >
              <SettingsIcon className="h-5 w-5" />
            </Button>
            
            {actions || (
              location === '/dashboard' || location === '/' ? (
                <Button 
                  size="sm"
                  className="flex items-center bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-800"
                >
                  <PlusIcon className="h-4 w-4 mr-1.5" />
                  New Site
                </Button>
              ) : null
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
