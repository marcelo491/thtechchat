import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/Sidebar";
import Dashboard from "@/pages/Dashboard";
import Websites from "@/pages/Websites";
import Templates from "@/pages/Templates";
import Components from "@/pages/Components";
import Settings from "@/pages/Settings";
import Deployments from "@/pages/Deployments";
import Users from "@/pages/Users";
import Containers from "@/pages/Containers";
import Analytics from "@/pages/Analytics";
import Backups from "@/pages/Backups";
import Marketplace from "@/pages/Marketplace";
import CodeEditor from "@/pages/CodeEditor";
import UserManagement from "@/pages/UserManagement";
import DNS from "@/pages/DNS";
import AuthPage from "@/pages/auth-page";
import { useState } from "react";
import { AuthProvider } from "@/hooks/use-auth";
import ProtectedRoute from "@/components/ProtectedRoute";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/dashboard" component={Dashboard} />
      <ProtectedRoute path="/websites" component={Websites} />
      <ProtectedRoute path="/templates" component={Templates} />
      <ProtectedRoute path="/components" component={Components} />
      <ProtectedRoute path="/settings" component={Settings} />
      <ProtectedRoute path="/deployments" component={Deployments} />
      <ProtectedRoute path="/users" component={Users} />
      <ProtectedRoute path="/containers" component={Containers} />
      <ProtectedRoute path="/analytics" component={Analytics} />
      <ProtectedRoute path="/backups" component={Backups} />
      <ProtectedRoute path="/marketplace" component={Marketplace} />
      <ProtectedRoute path="/code-editor" component={CodeEditor} />
      <ProtectedRoute path="/user-management" component={UserManagement} roles={["admin"]} />
      <ProtectedRoute path="/dns" component={DNS} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const isAuthPage = location === '/auth';

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        {isAuthPage ? (
          <AuthPage />
        ) : (
          <div className="min-h-screen flex flex-col md:flex-row bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-100">
            <Sidebar 
              mobileMenuOpen={mobileMenuOpen} 
              setMobileMenuOpen={setMobileMenuOpen} 
            />
            <div className="flex-1 overflow-auto">
              <Router />
            </div>
          </div>
        )}
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
