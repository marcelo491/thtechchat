import { useQuery } from "@tanstack/react-query";

interface Stats {
  activeSites: number;
  totalViews: number;
  deployments: number;
  totalTemplates: number;
  customTemplates: number;
}

export function useStats() {
  const { 
    data: stats, 
    isLoading, 
    error, 
    refetch 
  } = useQuery<Stats>({
    queryKey: ['/api/stats'],
    queryFn: async () => {
      const response = await fetch('/api/stats', {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Error fetching stats: ${response.statusText}`);
      }
      
      return response.json();
    }
  });

  return {
    stats,
    isLoading,
    error,
    refetch
  };
}
