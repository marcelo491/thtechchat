import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Website, InsertWebsite } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useSites() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sites, isLoading, error, refetch } = useQuery<Website[]>({
    queryKey: ['/api/websites'],
  });

  const createSiteMutation = useMutation({
    mutationFn: (newSite: InsertWebsite) => {
      return apiRequest("POST", "/api/websites", newSite);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/websites'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Success",
        description: "Website created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create website: ${error}`,
        variant: "destructive",
      });
    }
  });

  const updateSiteMutation = useMutation({
    mutationFn: ({ id, site }: { id: number; site: Partial<InsertWebsite> }) => {
      return apiRequest("PUT", `/api/websites/${id}`, site);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/websites'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Success",
        description: "Website updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update website: ${error}`,
        variant: "destructive",
      });
    }
  });

  const deleteSiteMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/websites/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/websites'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Success",
        description: "Website deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete website: ${error}`,
        variant: "destructive",
      });
    }
  });

  return {
    sites,
    isLoading,
    error,
    refetch,
    createSite: createSiteMutation.mutate,
    updateSite: updateSiteMutation.mutate,
    deleteSite: deleteSiteMutation.mutate,
    isCreating: createSiteMutation.isPending,
    isUpdating: updateSiteMutation.isPending,
    isDeleting: deleteSiteMutation.isPending,
  };
}
