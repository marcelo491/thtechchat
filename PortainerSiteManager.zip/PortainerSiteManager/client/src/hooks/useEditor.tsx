import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Component } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all components
  const { 
    data: components, 
    isLoading: isComponentsLoading, 
    error: componentsError 
  } = useQuery<Component[]>({
    queryKey: ['/api/components'],
  });

  // Fetch components by category
  const fetchComponentsByCategory = (category: string) => {
    return useQuery<Component[]>({
      queryKey: ['/api/components', { category }],
      queryFn: async () => {
        const response = await fetch(`/api/components?category=${category}`, {
          credentials: "include",
        });
        
        if (!response.ok) {
          throw new Error(`Error fetching components: ${response.statusText}`);
        }
        
        return response.json();
      }
    });
  };

  const basicComponents = components?.filter(c => c.category === 'basic') || [];
  const layoutComponents = components?.filter(c => c.category === 'layout') || [];
  const advancedComponents = components?.filter(c => c.category === 'components') || [];

  // Save page content mutation
  const saveContentMutation = useMutation({
    mutationFn: ({ siteId, content }: { siteId: number; content: any }) => {
      return apiRequest("PUT", `/api/websites/${siteId}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/websites'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Success",
        description: "Content saved successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save content: ${error}`,
        variant: "destructive",
      });
    }
  });

  return {
    components,
    basicComponents,
    layoutComponents,
    advancedComponents,
    fetchComponentsByCategory,
    saveContent: saveContentMutation.mutate,
    isSaving: saveContentMutation.isPending,
    isLoading: isComponentsLoading,
    error: componentsError,
  };
}
