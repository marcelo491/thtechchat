import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";

export function useActivities(limit?: number) {
  const queryKey = limit 
    ? ['/api/activities', { limit }] 
    : ['/api/activities'];
  
  const queryUrl = limit 
    ? `/api/activities?limit=${limit}` 
    : '/api/activities';

  const { 
    data: activities, 
    isLoading, 
    error, 
    refetch 
  } = useQuery<Activity[]>({
    queryKey,
    queryFn: async () => {
      const response = await fetch(queryUrl, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Error fetching activities: ${response.statusText}`);
      }
      
      return response.json();
    }
  });

  return {
    activities,
    isLoading,
    error,
    refetch
  };
}
