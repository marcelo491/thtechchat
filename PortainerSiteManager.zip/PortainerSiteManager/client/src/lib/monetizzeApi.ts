/**
 * Cliente de API para integração com a plataforma Monetizze
 * API docs: https://api.monetizze.com.br/2.1/apidoc/
 */

import { apiRequest } from "@/lib/queryClient";

// Endpoints da Monetizze
const API_BASE_URL = 'https://api.monetizze.com.br/2.1';

// Interface para transações de compra
export interface MonetizzeTransaction {
  product_id: string;
  full_name: string;
  email: string;
  price: number;
  payment_method?: 'credit_card' | 'pix' | 'bank_slip';
  installments?: number;
}

// Interface para respostas da API
export interface MonetizzeResponse {
  success: boolean;
  data?: any;
  error?: string;
}

/**
 * Obtém produtos da Monetizze para o marketplace
 */
export const fetchMonetizzeProducts = async (): Promise<MonetizzeResponse> => {
  try {
    // Usa o backend como proxy para a chamada à API da Monetizze para não expor a chave
    const response = await apiRequest('GET', '/api/monetizze/products');
    return await response.json();
  } catch (error) {
    console.error('Erro ao buscar produtos da Monetizze:', error);
    return {
      success: false,
      error: 'Falha ao carregar produtos. Tente novamente mais tarde.'
    };
  }
};

/**
 * Processa uma compra através da Monetizze
 */
export const processMonetizzeTransaction = async (transaction: MonetizzeTransaction): Promise<MonetizzeResponse> => {
  try {
    const response = await apiRequest('POST', '/api/monetizze/transaction', transaction);
    return await response.json();
  } catch (error) {
    console.error('Erro ao processar transação Monetizze:', error);
    return {
      success: false,
      error: 'Falha ao processar a transação. Tente novamente mais tarde.'
    };
  }
};

/**
 * Verifica o status de uma transação da Monetizze
 */
export const checkTransactionStatus = async (transactionId: string): Promise<MonetizzeResponse> => {
  try {
    const response = await apiRequest('GET', `/api/monetizze/transaction/${transactionId}`);
    return await response.json();
  } catch (error) {
    console.error('Erro ao verificar status da transação:', error);
    return {
      success: false,
      error: 'Falha ao verificar o status da transação.'
    };
  }
};