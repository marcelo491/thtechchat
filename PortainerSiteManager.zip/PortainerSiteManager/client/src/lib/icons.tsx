import React from 'react';

/**
 * This file provides utility functions for working with Remix icons
 * in a consistent way across the application.
 */

type IconCategory = 
  'basic' | 
  'layout' | 
  'components' | 
  'status' | 
  'action' | 
  'navigation';

type IconSize = 'sm' | 'md' | 'lg' | 'xl';

interface IconProps {
  name: string;
  size?: IconSize;
  className?: string;
}

// Map icon sizes to CSS classes
const iconSizes = {
  sm: 'text-base',
  md: 'text-lg',
  lg: 'text-xl',
  xl: 'text-2xl'
};

// Common icon collections by category for easy reference
export const icons = {
  basic: {
    text: 'ri-text',
    image: 'ri-image-line',
    button: 'ri-link',
    divider: 'ri-layout-row-line',
    list: 'ri-list-check'
  },
  layout: {
    container: 'ri-layout-grid-line',
    rowColumn: 'ri-layout-column-line',
    grid: 'ri-layout-masonry-line',
    sidebar: 'ri-layout-right-line'
  },
  components: {
    navigation: 'ri-navigation-line',
    hero: 'ri-layout-top-line',
    gallery: 'ri-gallery-line',
    testimonial: 'ri-user-line',
    contactForm: 'ri-mail-line',
    card: 'ri-article-line',
    footer: 'ri-layout-bottom-line'
  },
  status: {
    published: 'ri-check-line',
    draft: 'ri-draft-line',
    archived: 'ri-archive-line'
  },
  action: {
    add: 'ri-add-line',
    edit: 'ri-edit-line',
    delete: 'ri-delete-bin-line',
    preview: 'ri-eye-line',
    settings: 'ri-settings-line',
    deploy: 'ri-rocket-line',
    upload: 'ri-upload-cloud-line',
    download: 'ri-download-cloud-line',
    save: 'ri-save-line'
  },
  navigation: {
    dashboard: 'ri-dashboard-line',
    websites: 'ri-global-line',
    templates: 'ri-file-list-3-line',
    components: 'ri-puzzle-piece-line',
    settings: 'ri-settings-line',
    deployments: 'ri-rocket-line',
    users: 'ri-user-line',
    logout: 'ri-logout-box-line',
    search: 'ri-search-line',
    menu: 'ri-menu-line',
    close: 'ri-close-line'
  }
};

/**
 * Icon component that renders a Remix icon
 */
export function Icon({ name, size = 'md', className = '' }: IconProps) {
  const sizeClass = iconSizes[size];
  
  return (
    <i className={`${name} ${sizeClass} ${className}`}></i>
  );
}

/**
 * Helper function to get icon class name for a specific category and type
 */
export function getIconClass(category: IconCategory, type: string): string {
  const categoryIcons = icons[category] as Record<string, string>;
  return categoryIcons[type] || 'ri-question-line';
}

/**
 * Function to get appropriate icon for a file type
 */
export function getFileTypeIcon(fileExtension: string): string {
  const fileIcons: Record<string, string> = {
    // Images
    jpg: 'ri-image-line',
    jpeg: 'ri-image-line',
    png: 'ri-image-line',
    gif: 'ri-image-line',
    svg: 'ri-image-line',
    // Documents
    pdf: 'ri-file-pdf-line',
    doc: 'ri-file-word-line',
    docx: 'ri-file-word-line',
    xls: 'ri-file-excel-line',
    xlsx: 'ri-file-excel-line',
    ppt: 'ri-file-ppt-line',
    pptx: 'ri-file-ppt-line',
    // Code
    html: 'ri-html5-line',
    css: 'ri-css3-line',
    js: 'ri-javascript-line',
    ts: 'ri-code-s-slash-line',
    json: 'ri-braces-line',
    // Other
    zip: 'ri-file-zip-line',
    txt: 'ri-file-text-line'
  };

  return fileIcons[fileExtension.toLowerCase()] || 'ri-file-line';
}

export default Icon;
