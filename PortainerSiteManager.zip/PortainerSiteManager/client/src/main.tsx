import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Import Remixicon from CDN
const linkElement = document.createElement("link");
linkElement.rel = "stylesheet";
linkElement.href = "https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css";
document.head.appendChild(linkElement);

// Add Inter font
const fontElement = document.createElement("link");
fontElement.rel = "stylesheet";
fontElement.href = "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap";
document.head.appendChild(fontElement);

// Add page title
const titleElement = document.createElement("title");
titleElement.textContent = "SiteBuilder - Website Management System";
document.head.appendChild(titleElement);

createRoot(document.getElementById("root")!).render(<App />);
